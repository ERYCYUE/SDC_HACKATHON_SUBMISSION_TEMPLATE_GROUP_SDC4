'use client';

import {useEffect,useRef,useState} from 'react';
import {ArrowRight,ArrowUpRight,Cpu,Globe2,MoveUpRight} from 'lucide-react';
import {branches,regions,type Lang} from '@/lib/career';
import './startup.css';

type Props={lang:Lang;onLanguageChange:()=>void;onComplete:()=>void};
type Star={x:number;y:number;size:number;speed:number;phase:number};

function Constellation(){
 const canvas=useRef<HTMLCanvasElement>(null);
 useEffect(()=>{
  const el=canvas.current;if(!el)return;const ctx=el.getContext('2d');if(!ctx)return;
  const media=matchMedia('(prefers-reduced-motion: reduce)');let stars:Star[]=[];let width=0,height=0,frame=0,last=0,disposed=false;
  function draw(time:number){
   if(!ctx)return;ctx.clearRect(0,0,width,height);
   for(let i=0;i<stars.length;i++){
    const a=stars[i];if(!media.matches){a.y-=a.speed;if(a.y < -10)a.y=height+10;}
    const opacity=media.matches ? .38 : .22+(Math.sin(time/2500+a.phase)+1)*.17;
    ctx.fillStyle=`rgba(139,220,210,${opacity})`;ctx.beginPath();ctx.arc(a.x,a.y,a.size,0,Math.PI*2);ctx.fill();
    for(let j=i+1;j<stars.length;j++){const b=stars[j],distance=Math.hypot(a.x-b.x,a.y-b.y);if(distance<105){ctx.strokeStyle=`rgba(75,173,164,${(1-distance/105)*.13})`;ctx.lineWidth=.6;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();}}
   }
  }
  function resize(){
   if(!el||!ctx)return;width=el.clientWidth;height=el.clientHeight;const scale=Math.min(devicePixelRatio||1,1.5);el.width=Math.round(width*scale);el.height=Math.round(height*scale);ctx.setTransform(scale,0,0,scale,0,0);
   stars=Array.from({length:Math.min(56,Math.max(20,Math.floor(width*height/23000)))},()=>({x:Math.random()*width,y:Math.random()*height,size:.6+Math.random()*.8,speed:.08+Math.random()*.14,phase:Math.random()*8}));draw(0);
  }
  function tick(time:number){if(disposed||media.matches||document.hidden)return;if(time-last>32){draw(time);last=time;}frame=requestAnimationFrame(tick);}
  function restart(){cancelAnimationFrame(frame);last=0;if(!media.matches&&!document.hidden)frame=requestAnimationFrame(tick);else draw(0);}
  const observer=new ResizeObserver(resize);observer.observe(el);resize();restart();document.addEventListener('visibilitychange',restart);media.addEventListener('change',restart);
  return()=>{disposed=true;cancelAnimationFrame(frame);observer.disconnect();document.removeEventListener('visibilitychange',restart);media.removeEventListener('change',restart);};
 },[]);
 return <canvas ref={canvas} className="boot-constellation" aria-hidden="true"/>;
}

function ChipSculpture(){
 const lines=[
  'M270 235V180L210 120V65','M300 235V160L270 130V40','M330 235V130L365 95V25','M360 235V190L425 125V60',
  'M400 270H460L520 210H580','M400 300H500L550 250H620','M400 330H500L550 380H610','M400 360H450L510 420H575',
  'M360 400V450L425 515V580','M330 400V500L370 540V610','M300 400V500L265 535V610','M270 400V450L210 510V575',
  'M235 360H180L115 425H55','M235 330H140L90 380H20','M235 300H140L90 250H25','M235 270H180L120 210H55'
 ];
 return <div className="boot-sculpture" aria-hidden="true"><div className="boot-halo"/>
  <div className="boot-orbit boot-orbit-one"><span/><i/></div><div className="boot-orbit boot-orbit-two"><span/></div><div className="boot-orbit boot-orbit-three"/>
  <svg className="boot-circuit" viewBox="0 0 640 640" fill="none"><defs><linearGradient id="boot-trace" x1="100" y1="100" x2="560" y2="560"><stop stopColor="#88e6cc"/><stop offset="1" stopColor="#40839c"/></linearGradient><filter id="boot-glow"><feGaussianBlur stdDeviation="3"/></filter></defs>
   <g stroke="#4a827e" strokeWidth="1" opacity=".38">{lines.map((d,i)=><path d={d} key={i}/>)}<rect x="229" y="229" width="178" height="178" rx="24"/><rect x="218" y="218" width="200" height="200" rx="30" strokeDasharray="3 9"/></g>
   <g stroke="url(#boot-trace)" strokeWidth="1.7" className="boot-trace-flow">{lines.map((d,i)=><path d={d} key={i} style={{animationDelay:`${i*-.32}s`}}/>)}</g>
   {[[210,65],[270,40],[365,25],[425,60],[580,210],[620,250],[610,380],[575,420],[425,580],[370,610],[265,610],[210,575],[55,425],[20,380],[25,250],[55,210]].map(([x,y],i)=><g key={i}><circle cx={x} cy={y} r="5" stroke="#537e7d"/><circle cx={x} cy={y} r="1.8" fill="#93dec3" className="boot-node" style={{animationDelay:`${i*-.4}s`}}/></g>)}
  </svg>
  <div className="boot-chip-stack"><div className="boot-chip-under"/><div className="boot-chip-body"><div className="boot-chip-top"><Cpu size={32} strokeWidth={1}/><span>EEE<span>next</span></span><small>YOUR NEXT CHAPTER</small><i/></div></div></div>
  <span className="boot-coordinate coordinate-one">01 / DISCOVER</span><span className="boot-coordinate coordinate-two">02 / CONNECT</span><span className="boot-coordinate coordinate-three">03 / EVOLVE</span>
  <span className="boot-float-label label-one"><i/>{'SKILLS → POSSIBILITIES'}</span><span className="boot-float-label label-two"><span>✦</span> HUMAN-CENTERED FUTURES</span>
 </div>;
}

export default function StartupScreen({lang,onLanguageChange,onComplete}:Props){
 const root=useRef<HTMLElement>(null),enter=useRef<HTMLButtonElement>(null),timeout=useRef<ReturnType<typeof setTimeout>|null>(null);
 const [leaving,setLeaving]=useState(false);const t=(zh:string,en:string)=>lang==='zh'?zh:en;
 const finish=()=>{if(leaving)return;setLeaving(true);const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;timeout.current=setTimeout(onComplete,reduced?0:650);};
 useEffect(()=>{const original=document.body.style.overflow;document.body.style.overflow='hidden';enter.current?.focus({preventScroll:true});return()=>{document.body.style.overflow=original;if(timeout.current)clearTimeout(timeout.current);};},[]);
 return <section ref={root} className={'boot-screen'+(leaving?' boot-leaving':'')} role="dialog" aria-modal="true" aria-labelledby="boot-title" aria-describedby="boot-description" onPointerMove={e=>{if(e.pointerType!=='mouse'||matchMedia('(prefers-reduced-motion: reduce)').matches)return;const bounds=e.currentTarget.getBoundingClientRect();e.currentTarget.style.setProperty('--pointer-x',`${(e.clientX-bounds.width/2)/bounds.width*13}px`);e.currentTarget.style.setProperty('--pointer-y',`${(e.clientY-bounds.height/2)/bounds.height*13}px`);}} onPointerLeave={e=>{e.currentTarget.style.setProperty('--pointer-x','0px');e.currentTarget.style.setProperty('--pointer-y','0px');}} onKeyDown={e=>{
  if(e.key==='Escape'){e.preventDefault();finish();}
  if(e.key==='Tab'){const buttons=root.current?.querySelectorAll<HTMLButtonElement>('button:not(:disabled)');if(!buttons?.length)return;const first=buttons[0],last=buttons[buttons.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}
 }}>
  <Constellation/><div className="boot-grid" aria-hidden="true"/><div className="boot-noise" aria-hidden="true"/><div className="boot-light boot-light-one" aria-hidden="true"/><div className="boot-light boot-light-two" aria-hidden="true"/>
  <div className="boot-layout"><header className="boot-header"><div className="boot-brand"><span className="boot-brand-icon"><Cpu size={22}/></span><span>EEE<span>next</span></span><i/></div><div className="boot-header-actions"><button onClick={onLanguageChange} disabled={leaving} aria-label={t('切换语言','Switch language')}><Globe2 size={14}/>{lang==='zh'?'English':'中文'}</button><span/><button className="boot-skip" onClick={finish} disabled={leaving}>{t('跳过开场','Skip intro')}<ArrowUpRight size={14}/></button></div></header>
   <div className="boot-main"><div className="boot-copy"><div className="boot-kicker"><i/>AIVERSECITY / FUTURE-READY WORKFORCE</div><div className="boot-title-mask"><h1 id="boot-title">{lang==='zh'?<>把下一种可能，<br/><span>连接成未来。</span></>:<>Your potential.<br/><span>Your next chapter.</span></>}</h1></div><p id="boot-description">{t('从你已有的能力出发，探索电子信息工程的未来职业，连接更适合你的成长路径。','Start with your strengths. Explore the future of electronic and information engineering and discover a path that feels like yours.')}</p><div className="boot-cta-row"><button ref={enter} className="boot-enter" onClick={finish} disabled={leaving}>{t('开启我的下一程','Explore my next chapter')}<span><ArrowRight size={18}/></span></button><span className="boot-cta-note">{t('让未来，由你定义。','A future shaped by you.')}</span></div><div className="boot-topics"><span>{t('芯片与系统','CHIPS & SYSTEMS')}</span><i/><span>{t('智能与感知','INTELLIGENCE & SENSING')}</span><i/><span>{t('连接与创新','CONNECTION & INNOVATION')}</span></div></div><div className="boot-art"><ChipSculpture/></div></div>
   <div className="boot-bottom"><div className="boot-bottom-line"><span>DESIGNED FOR WHAT COMES NEXT</span><i/><MoveUpRight size={17}/></div><div className="boot-bottom-meta"><div><span>{String(Object.keys(branches).length).padStart(2,'0')}</span>{t('专业方向','ENGINEERING SPECIALIZATIONS')}</div><div><span>{String(Object.keys(regions).length).padStart(2,'0')}</span>{t('目标地区','TARGET REGIONS')}</div><div className="boot-human"><i/>{t('以人为中心，面向未来','HUMAN-CENTERED. FUTURE-READY.')}</div><small>EEE NEXT · 2026</small></div></div>
  </div><div className="boot-exit-flash" aria-hidden="true"/>
 </section>;
}
