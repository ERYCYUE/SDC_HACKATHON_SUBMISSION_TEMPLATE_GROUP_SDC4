import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "EEE Next | 电子信息职业导航",
  description: "Explore your next role in electronic and information engineering. Bilingual career conversations, evidence and learning pathways.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
