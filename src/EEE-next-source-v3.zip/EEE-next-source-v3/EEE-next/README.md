# EEE next — Electronic Engineering Career Explorer

面向电子信息工程的中英双语职业探索演示。**当前没有训练模型，也没有连接大模型**；对话使用规则引导与关键词识别，分析使用可解释的启发式评分。后端已预留兼容 Chat Completions API 的 AI 解读接口。

Bilingual EEE career exploration prototype. **No trained model or connected LLM.** Chat uses guided rules and keyword extraction. Analysis uses explainable, uncalibrated heuristics. A server-side API-compatible interpretation endpoint is provided.

## Run / 运行

Node.js >= 22.13, npm:

```sh
npm ci
npm run dev
```

Use the URL printed by the dev server. The PDF worker is included in `public/pdf.worker.min.mjs` and must match the installed `pdfjs-dist` version. After updating that package, copy its `build/pdf.worker.min.mjs` into `public/` again. For Node 24+, run core checks with:

```sh
node --experimental-strip-types scripts/test-career.mjs
npx tsc --noEmit
npm run build
```

## Demo flow / 演示流程

The bilingual opening screen uses an animated chip, flowing circuits, a particle constellation and subtle pointer parallax. Enter or Skip intro opens the workspace immediately with a short visual transition; Escape also skips. It appears once per browser-tab session. Use Replay intro in the workspace footer to show it again without resetting the profile or imported data. Reduced-motion preferences disable continuous motion. Animation is decorative, not model loading or AI processing.

新增双语动态开场：发光芯片、流动电路、粒子星图和轻微鼠标视差。可点击进入、跳过，或按 Escape；不强制等待。同一标签页会话只展示一次，可在页脚点击“重播开场”，保留当前画像与导入数据。遵循系统减少动态效果设置。开场是装饰动画，不表示模型已加载或正在进行 AI 分析。

1. Switch 中文 / English in the header. Start with a synthetic profile or type a description.
2. Alternatively upload a synthetic PDF, DOCX or TXT CV (8 MB; PDF <= 30 pages). Files are parsed in the browser, not uploaded. Scanned PDFs without extractable text require external OCR; the UI explains this.
3. Correct extracted skills, branch, region, target direction and weekly hours. Confirm the profile. Keyword extraction can miss or misread complex wording; confirmation is essential.
4. Open the career map. Compare three conditional scenarios and five regions. Select a role, inspect task changes, skill gaps and SDGs.
5. Change weekly hours, mark learning steps complete and export the JSON plan.
6. In Data & evidence, import the supplied JSON template or your own dataset. Refreshing clears profiles, imported data and progress; only language preference persists locally.

## Coverage / 范围

7 branches: IC / semiconductors, embedded / IoT, communications / RF, signal / sensing, control / robotics, hardware / power, optoelectronics. 12 initial role definitions and 24 introductory skills. These are team-set demonstration definitions and estimates, not a validated occupational standard.

Regions: `CN`, `SG`, `MY`, `US`, `EU`. Europe is aggregated; the data owner must define country coverage, observation periods, comparability and normalization. No employment data is automatically collected. The user supplies all job and regional trend data.

All 17 SDGs can be explored. Each role and skill is mapped only to plausible project contributions, with explanations and official UN links. This is not certified impact measurement. Some goals are not used by this initial catalog.

## Data contract / 数据契约

Import UTF-8 JSON, <= 8 MB, 1–5,000 combined rows:

```json
{
  "schema_version": 1,
  "data_kind": "synthetic",
  "jobs": [{
    "job_id": "DEMO-001",
    "title": "SYNTHETIC Embedded Firmware Engineer",
    "role_id": "embedded",
    "region": "CN",
    "skills": ["c", "mcu", "rtos", "test"],
    "source_url": "https://example.com/synthetic-job-001",
    "published_at": "2026-10-01",
    "description": "SYNTHETIC ONLY, not a real vacancy"
  }],
  "signals": []
}
```

Use `data_kind: "user"` for user-supplied real data. The template is synthetic and must not be presented as real. `example.com` sources are always labeled synthetic by the UI. All imported descriptive text stays in its original language; system UI and analysis explanations switch languages.

`jobs[]`: required `job_id`, `title`, `role_id`, `region`, nonempty `skills[]`, `source_url`, `published_at`; optional `description`. Dates: YYYY-MM-DD. IDs must be unique. Skill and role IDs must come from `lib/career.ts`; the Data page lists them. Expand both the catalog and validation when adding new branches or skill IDs. Unknown IDs are rejected, not silently mapped.

`signals[]`: required `role_id`, `region`, `demand_index`, `ai_adoption`, `funding_index`, `policy_index`, `observed_at`, `source_url`. All four indices: finite numbers 0–100. One current row per region + role. Aggregate/de-duplicate raw records upstream, keep raw evidence externally, normalize comparable periods yourself. Missing signals use an empty array; never invent values to complete a row. Future / invalid dates and unsafe URL protocols are rejected. Index updates are imported again through the same interface. Continuous collection, refresh scheduling and market forecasting are not implemented.

### How examples affect results / 实例怎样影响分析

- Retrieve examples by target region, then rank by `85% listed-skill coverage + 15% branch proximity`. No example in the region means an explicit empty state. This is similarity, not market demand or hiring odds.
- For each role, use the **union of skills in same-region, same-role examples** as requirements. This updates role fit, missing skills and learning steps when imported job requirements change. It does not mean every employer requires every listed skill. Without same-role examples, use the labeled demo catalog.
- Role fit: `55% skill coverage + 15% branch proximity + 15% demand + 8% funding + 7% policy`. Same-branch proximity = 100, other branches = 25 (a demo assumption). Absent trend signals use a neutral 50 for the last three terms. Signal freshness is `max(0.25, 1 - ageDays/730)`; the trend contribution blends toward its neutral value with age. Records older than 180 days are flagged.
- Future scenarios adjust demand according to assumed AI task exposure and green relevance. Task-change pressure uses team-set role exposure × scenario intensity × observed AI adoption. These are sensitivity demonstrations, **not ILO index values, learned predictions or extinction probabilities**. See formulas in `rankRoles`.
- Funding and policy indices are user-supplied proxies, not automatically inferred capital flows. This prototype cannot establish causality, vacancies, salaries or employment probabilities.
- Skills carry introductory exercise-hour estimates. Steps are sequential, can share a week if hours remain, and are rescheduled when weekly hours change. Project time is extra. There is no verified proficiency assessment or prerequisite knowledge graph yet.

## AI connection / 后续接入 AI

`GET /api/ai`: returns only `{configured, model}`; never a secret. When unset, `POST /api/ai` returns 503 and rules-based results remain usable.

Set **server runtime** configuration (through Sites runtime secrets for hosted use):

```text
AI_ENDPOINT=https://YOUR-PROVIDER/v1/chat/completions
AI_MODEL=YOUR-MODEL-ID
AI_API_KEY=YOUR-SECRET
```

Never place keys in the frontend, Git or a browser form. `.env.example` documents names only. On local Cloudflare preview, use ignored `.dev.vars` if needed. The provider must support the standard `choices[0].message.content` response shape. Arbitrary local model URLs are not supported by the hosted endpoint; HTTPS is required.

Users explicitly click Generate AI interpretation before structured profile, selected role, matched examples and signal evidence are sent to the configured provider. Raw CV text and CV files are omitted. The prompt confines explanations to supplied evidence, requests source URLs, labels synthetic data and disallows invented jobs, courses, statistics and scores. Outputs remain untrusted text requiring human review. These prompts are not a guarantee against hallucination. No live provider or API key was available; provider integration remains unverified end to end.

## Files / 主要文件

The UI uses plain bilingual terminology: “各地区就业趋势数据 / Employment trends by region”, four explicitly named 0–100 indices, self-reported skills and separately explained career/posting scores. See `docs/COPY_REVIEW.md` for the terminology review. Existing `jobs`, `signals`, role IDs and skill IDs remain compatible with earlier imports. Import-format and connection errors are localized in `lib/ui-messages.ts`.

界面已统一使用“各地区就业趋势数据”等通俗术语，说明四项指数均为 0–100 分、技能属于用户自评，以及职业方向和岗位实例的匹配分采用不同算法。详见 `docs/COPY_REVIEW.md`。已有 JSON 导入字段及岗位、技能编号保持兼容。

- `app/page.tsx`: bilingual dialogue, CV parsing, profile confirmation, interactive views and JSON imports.
- `app/globals.css`: responsive app layout, interaction states, transitions and reduced-motion support.
- `lib/career.ts`: bilingual catalog, schema validation, profile extraction, retrieval, scoring and schedules.
- `worker/index.ts`: server AI status / interpretation; preserves Sites runtime integration.
- `scripts/test-career.mjs`: meaningful checks covering extraction, negative wording, bilingual parity, input validation, data-driven requirements, scoring sensitivity, missing evidence and plans.

## Next development / 后续开发

1. User connects real job examples and dated, comparable trend indices; audit normalization and sampling biases per region.
2. Connect an approved LLM provider, replace keyword intake with structured extraction, retain profile confirmation, evaluate evidence grounding and malformed output handling.
3. Add a real skill prerequisite graph, proficiency levels and curated task-level occupational evidence.
4. Collect expert-labeled role relevance and skills-gap examples before training any ranker. Evaluate retrieval Recall@k / ranking NDCG and gap precision on held-out regions and later time periods. Do not train a job-extinction classifier without valid outcome labels.
5. Add persistence and controlled updates only when needed. Current data imports are session-only, no database or automated collection is enabled.

For competition use, demonstrate synthetic or public profiles. This app supports user decisions; it does not make hiring decisions or issue a verdict on whether a profession will survive.

## Method and resource links / 参考

ILO task-level exposure methodology (2025-05-20): https://www.ilo.org/resource/article/how-might-generative-ai-impact-different-occupations

UN goals: https://sdgs.un.org/goals

Learning links are curated documentation / open educational resources attached to each skill, not invented course titles, certifications or verified employment qualifications. Availability and suitability should be reviewed before formal use.
