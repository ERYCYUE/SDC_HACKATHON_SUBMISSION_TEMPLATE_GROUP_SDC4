// Official anonymous endpoints only. No credentials or personal profile is sent.
import {readFile,writeFile} from 'node:fs/promises';
import {publicFeeds,fetchPublicFeed} from '../lib/international.ts';
const path=new URL('../data/international-employment.json',import.meta.url);
let old=[];try{old=JSON.parse(await readFile(path,'utf8'));}catch{}
const output=[];let failed=0;
for(const feed of publicFeeds){
 try{const snapshot=await fetchPublicFeed(feed);output.push(snapshot);console.log(`${feed.id}: ${snapshot.rows.length} retained observations / ${snapshot.rawCount} raw records`);}
 catch(e){failed++;const previous=old.find(x=>x.id===feed.id);if(previous)output.push({...previous,error:String(e.message),lastAttempt:new Date().toISOString()});console.error(`${feed.id}: ${e.message}${previous?' (previous snapshot retained)':''}`);}
 // Preserve partial successful downloads even if a later endpoint fails.
 await writeFile(path,JSON.stringify([...output,...old.filter(x=>!output.some(y=>y.id===x.id))],null,2)+'\n');
}
if(failed)process.exitCode=1;
