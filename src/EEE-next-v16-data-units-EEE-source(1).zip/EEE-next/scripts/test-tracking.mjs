import assert from 'node:assert/strict';
import {quarterBounds,quarterIndex,parseTotal} from './update-tracking.mjs';
assert.deepEqual(quarterBounds(quarterIndex('2024-Q4')),{period:'2024-Q4',start:'202410010000',end:'202412312359'});
assert.equal(quarterBounds(quarterIndex('2024-Q1')).end,'202403312359');
assert.throws(()=>quarterIndex('2026-Q5'));
assert.equal(parseTotal('<feed><opensearch:totalResults>9</opensearch:totalResults></feed>'),9);
assert.equal(parseTotal('<feed><totalResults>0</totalResults></feed>'),0);
assert.throws(()=>parseTotal('<feed><title>Error</title></feed>'));
console.log('6 tracking checks passed: UTC quarter boundaries, invalid periods, totals, zero totals and invalid responses.');
