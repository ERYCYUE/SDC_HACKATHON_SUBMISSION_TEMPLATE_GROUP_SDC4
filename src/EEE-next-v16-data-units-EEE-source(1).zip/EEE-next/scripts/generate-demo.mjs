import fs from 'node:fs/promises';
import {makeDefaultData} from '../lib/model/catalog.ts';
const output=process.argv[2]||'data/demo-v2.json';await fs.writeFile(output,JSON.stringify(makeDefaultData(),null,2)+'\n');console.log(`Wrote ${output}; synthetic records remain explicitly labeled.`);
