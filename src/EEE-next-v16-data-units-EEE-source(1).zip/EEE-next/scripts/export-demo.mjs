import fs from 'node:fs';
import path from 'node:path';
import {exampleData} from '../lib/career.ts';
const out=process.argv[2];if(!out)throw new Error('Output folder required');fs.mkdirSync(out,{recursive:true});
fs.writeFileSync(path.join(out,'EEE-data-template.json'),JSON.stringify(exampleData,null,2));
const demo={schema_version:1,data_kind:'synthetic',jobs:[{job_id:'QA-001',title:'SYNTHETIC Security-focused Embedded Engineer',role_id:'embedded',region:'CN',skills:['c','security','network'],source_url:'https://example.com/qa-job',published_at:'2026-10-01'}],signals:[{role_id:'embedded',region:'CN',demand_index:95,ai_adoption:60,funding_index:80,policy_index:75,observed_at:'2026-10-01',source_url:'https://example.com/qa-signal'}]};
fs.writeFileSync(path.join(out,'qa-import.json'),JSON.stringify(demo,null,2));
fs.writeFileSync(path.join(out,'qa-invalid.json'),JSON.stringify({...demo,jobs:[{...demo.jobs[0],region:'INVALID'}]},null,2));
console.log('Synthetic templates written.');
