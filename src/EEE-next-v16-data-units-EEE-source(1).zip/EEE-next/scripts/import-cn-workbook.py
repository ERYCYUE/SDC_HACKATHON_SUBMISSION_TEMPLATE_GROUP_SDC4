"""Read-only, reproducible import. Usage: bundled-python scripts/import-cn-workbook.py input.xlsx"""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json, re, sys, math
from openpyxl import load_workbook

source=Path(sys.argv[1]); root=Path(__file__).resolve().parents[1]
wb=load_workbook(source,read_only=True,data_only=True)
values=list(wb['原始数据'].values); raw=[dict(zip(values[0],r)) for r in values[1:] if r[0] is not None]
groups={'嵌入式':'embedded','硬件工程师':'hardware','射频工程师':'rf','FPGA':'fpga','FAE':'fae','物联网':'iot','软件开发':'software','模拟IC设计':'analog-ic','芯片验证':'ic-verification','PCB设计':'pcb-design','信号处理':'signal','算法工程师':'algorithm','驱动开发':'driver','数字IC设计':'ic-design','汽车电子':'automotive','PLC':'plc','电源工程师':'power','电气工程师':'electrical','芯片测试':'chip-test','EMC工程师':'emc','通信工程师':'network','通信算法':'comm-algorithm','光通信':'photonics','IC版图':'ic-layout','硬件测试':'hardware-test'}
degree={'本科':'bachelor','硕士':'master','博士':'doctor','大专':'associate','高中/中专':'secondary','初中及以下':'secondary'}
def clean(x):
    text=str(x or '').strip()
    text=re.sub(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}','[email removed]',text)
    text=re.sub(r'(?<!\d)1[3-9]\d{9}(?!\d)','[phone removed]',text)
    return text
def num(v):
    if v is None or v=='': return None
    assert isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and v>=0, f'Invalid salary: {v}'
    return float(v)
rows=[]; seen=set()
for x in raw:
    url=str(x['岗位链接']);assert url.startswith('https://www.zhipin.com/job_detail/')
    if url in seen: continue
    seen.add(url); tag=x['学历下限'];explicit=x['JD写明不限']=='学历不限'
    edu=degree.get(tag,'none' if explicit else 'unknown')
    exp=str(x['经验要求'] or ''); match=re.match(r'(\d+)\s*[-年]',exp)
    # "经验不限" is not proof that 0-year graduates are accepted.
    years=0 if exp=='在校/应届' else int(match[1]) if match and '以内' not in exp else None
    salary={key:num(x[col]) for key,col in [('monthlyMinK','月薪下限(K)'),('monthlyMaxK','月薪上限(K)'),('monthlyMidK','月薪中值(K)'),('payMonths','年发薪月数'),('annualEstimateWan','估算年薪(万元)'),('dailyMin','日薪下限(元)'),('dailyMax','日薪上限(元)')]}
    salary.update(kind=x['薪资类型'],raw=clean(x['薪资原文']),payMonthsAssumed=not bool(re.search(r'\d+薪',str(x['薪资原文']))))
    if salary['monthlyMidK'] is not None:
        assert abs(salary['monthlyMidK']-(salary['monthlyMinK']+salary['monthlyMaxK'])/2)<1e-8
    rows.append(dict(id='CN-'+sha256(url.encode()).hexdigest()[:20],group=x['方向'],roleId=groups[x['方向']],city=x['城市'],title=clean(x['岗位名称']),company=clean(x['公司']),education=edu,educationRaw=tag,educationPreferred=clean(x['学历优先']),experienceRaw=exp,experienceMin=years,schoolRequired=clean(x['院校门槛']),schoolPreferred=clean(x['院校优先标签']),otherRequirements=clean(x['其他门槛']),explicitUnrestricted=explicit,excerpt=clean(x['JD原文依据'])[:1800],sourceUrl=url,salary=salary))
assert len(rows)==len(raw), 'Duplicate source URLs must be reconciled before publishing'
assert {x['group'] for x in rows}==set(groups), 'Expected all 25 mapped specialties'
batchFiles=[str(r[0]) for r in wb['数据说明'].values if isinstance(r[0],str) and r[0].startswith('boss_jobs_')]
dates=sorted(set(re.search(r'boss_jobs_(\d{8})',s)[1] for s in batchFiles))
assert dates, 'Missing collection batch filenames'
iso=lambda d: f'{d[:4]}-{d[4:6]}-{d[6:]}'
captureStart,captureEnd=iso(dates[0]),iso(dates[-1])
overview=str(wb['总览']['A2'].value)
declared=str(next(r[1] for r in wb['数据说明'].values if r[0]=='抓取日期'))
declaredDates=re.findall(r'\d{4}-\d{2}-\d{2}',declared)
assert len(declaredDates)==2
cityOrder=['北京','上海','深圳','成都','杭州']
cities=[c for c in cityOrder if any(x['city']==c for x in rows)]
assert set(cities)=={x['city'] for x in rows}, 'Add translations for any newly introduced city'
assert f'{len(rows)}' in overview, 'Overview and raw row counts disagree'
meta=dict(id='boss-cn-'+dates[-1]+'-'+sha256(source.read_bytes()).hexdigest()[:12],sourceFile=source.name,sourceSha256=sha256(source.read_bytes()).hexdigest(),sourceSheet='原始数据',snapshotDate=captureEnd,captureStart=captureStart,captureEnd=captureEnd,declaredCaptureEnd=declaredDates[-1],dateDiscrepancy=declaredDates[-1]!=captureEnd,total=len(rows),groupCount=len(groups),cities=cities,source='BOSS直聘，团队提供的搜索抽样',publishedDatesKnown=False,coverage=f'{len(groups)} directions × {len(cities)} cities; first two result pages; not a random or platform-wide sample',unknownEducation=sum(x['education']=='unknown' for x in rows),explicitUnrestricted=sum(x['education']=='none' for x in rows),salaryCounts=dict(Counter(x['salary']['kind'] for x in rows)),rowCountsByGroup=dict(Counter(x['group'] for x in rows)),rowCountsByCity=dict(Counter(x['city'] for x in rows)),originalMasterOrAboveShare=sum(x['education'] in ['master','doctor'] for x in rows)/len(rows)*100,notes=[f'本批采集 {captureStart} 至 {captureEnd}，截止日取批次文件名最晚日，与新版总览一致；数据说明页仍写至 {declaredDates[-1]}，保留该差异。采集日期不是岗位发布日期。','本次增加城市与样本范围，不据样本数量增加推断市场招聘增长。','原表“学历不限/未注明”合并；仅JD写明学历不限者计为不限，其余该组记为未知，保留原标签。','月薪、日薪分别统计；年薪是按标注发薪月数或默认12薪估算，不是实际收入。','没有结构化技能清单、AI采用、投入、政策或多期招聘序列，不伪造这些观测。'])
out=root/'data/cn-employment.json';out.write_text(json.dumps(dict(meta=meta,postings=rows),ensure_ascii=False,separators=(',',':')),'utf-8')
print(json.dumps(meta,ensure_ascii=False,indent=2)); print('Stored',out.name,out.stat().st_size,'bytes')
