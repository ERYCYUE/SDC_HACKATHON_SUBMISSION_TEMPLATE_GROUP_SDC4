'use client';
import {Cpu} from 'lucide-react';
import {sdgColors} from '@/lib/career';
import './orbit.css';

/** Decorative geometry shared by the opening and workspace, not a data chart. */
export default function SDGOrbit({compact=false}:{compact?:boolean}){
 return <div className={'sdg-orbit-scene'+(compact?' compact':'')} aria-hidden="true">
  <div className="orbit-aura"/><div className="orbit-floor"/>
  <div className="orbit-assembly"><div className="orbit-ring outer"/><div className="orbit-ring middle"/><div className="orbit-ring inner"/>
   <svg className="sdg-orbit-wheel" viewBox="0 0 600 600"><defs><radialGradient id={compact?'orb-core-small':'orb-core'}><stop stopColor="#6b5ad4" stopOpacity=".35"/><stop offset="1" stopColor="#6278f8" stopOpacity="0"/></radialGradient></defs><circle cx="300" cy="300" r="195" fill={`url(#${compact?'orb-core-small':'orb-core'})`}/>
    {sdgColors.map((color,i)=>{const a=(i*360/17-90)*Math.PI/180,x=300+211*Math.cos(a),y=300+211*Math.sin(a);return <g key={i}><line x1="300" y1="300" x2={x} y2={y} stroke="#8d85e5" strokeOpacity=".16"/><circle cx={x} cy={y} r="20" fill="#151b3b" stroke={color} strokeWidth="1.8"/><circle cx={x} cy={y} r="15" fill={color} opacity=".13"/><text x={x} y={y+4} textAnchor="middle" fill="#f2f2ff" fontSize="12" fontFamily="system-ui">{i+1}</text></g>;})}
   </svg><div className="orbit-satellite one"/><div className="orbit-satellite two"/>
  </div>
  <div className="orbit-core"><div className="orbit-core-top"><Cpu size={38} strokeWidth={1.2}/><span>EEE<span>next</span></span><small>17 GOALS · YOUR NEXT</small></div></div>
  <div className="orbit-caption"><i/>ENGINEERING × SUSTAINABILITY</div><div className="orbit-coordinate">17 / CONNECTED POSSIBILITIES</div>
 </div>;
}
