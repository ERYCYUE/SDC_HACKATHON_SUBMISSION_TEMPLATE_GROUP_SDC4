CREATE TABLE `employment_batches` (
	`id` text PRIMARY KEY NOT NULL,
	`meta` text NOT NULL,
	`row_count` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `employment_postings` (
	`id` text NOT NULL,
	`batch_id` text NOT NULL,
	`role_id` text NOT NULL,
	`payload` text NOT NULL,
	PRIMARY KEY(`id`, `batch_id`)
);
--> statement-breakpoint
CREATE INDEX `employment_batch_idx` ON `employment_postings` (`batch_id`);--> statement-breakpoint
CREATE INDEX `employment_role_idx` ON `employment_postings` (`role_id`);