CREATE TABLE `public_employment_feeds` (
	`id` text PRIMARY KEY NOT NULL,
	`payload` text NOT NULL,
	`retry_at` integer NOT NULL,
	`last_error` text,
	`last_attempt` text
);
