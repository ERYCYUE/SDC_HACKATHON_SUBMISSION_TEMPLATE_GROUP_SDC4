# SDG 目标与工程项目来源 / SDG sources and project scope

核对日期 / Checked: 2026-10-21

## 范围 / Scope

`data/sdg-impact.json` 包含 17 个官方目标短标题、35 个具体目标（target）的定义或释义、17 个工程学习项目及 106 条目标级关联。关联覆盖岗位、技能、项目三类，其中 7 条为风险，均附双语缓解措施。所有工程项目、关联和强度均为团队编写，标记 `synthetic: true`。它们是可检验的贡献假设，不是联合国认证、已实现影响、技能证明或就业预测。强度 1–3 为演示分级，不是官方计量指标。

The asset contains all 17 official short goal titles, 35 target definitions/paraphrases, 17 engineering learning projects and 106 target-level mappings. All projects and mappings are team-authored and marked `synthetic: true`. Seven risk mappings include mitigation. These are testable contribution hypotheses, not certified outcomes. Official sources define targets and do not endorse this site’s role mappings or project effectiveness.

## 核查状态 / Verification status

- 联合国在中国 17 个中文目标页面均已打开核对，英文目标定义参考 UN DESA。
- `7.3`、`12.2`、`13.1` 的中英文完整原文已逐条核对，标记 `verified: true`、`text_kind: official`。
- 其余目标使用简短释义，始终标记 `verified: false`、`text_kind: paraphrase`。`source_checked: true` 仅代表查看过官方定义，不将释义冒充原文。打开来源可查看完整措辞、原有期限与适用条件。
- The Chinese Goal 5 page repeats “5.1” for the final three targets. The correct code **5.b** was checked against [UN DESA’s English target list](https://sdgs.un.org/goals/goal5). Our display is a labelled paraphrase and does not reproduce that numbering error.
- 部分目标的原始期限为 2020 或 2025。教学项目关联不改写期限，也不意味着这些目标已经实现。
- No employment data were collected for this asset task. It requires no external API at runtime.

## 关联解释与边界 / Mapping interpretation

每个目标至少有一个具体工程项目；单一岗位不会被强行关联全部 17 项目标。项目验收标准描述可检查的学习产出，并限制临床、安全、环境测量等未经验证的用途。

- 13.2 涉及国家政策、战略和规划。电力、储能与 Chiplet 对此仅为低强度赋能或风险：应先提供能源与生命周期证据，不能直接将硬件研发计作国家政策成效。
- 3.d 指健康风险管理能力。穿戴原型是可能的研究入口，不视为已验证医疗器械。
- 14.1 的监测提供污染治理线索；监测本身不直接减少污染，浊度也不能单独确认污染源。
- 7.3 既包含能效机会，也保留总算力增长带来的反弹风险；必须同时看单位服务与系统总能耗。
- 8.5 的自动化风险必须同时展示人类监督、带教、人机协作与再培训措施。
- 17.18 需要真实数据能力建设；仅发布一个开源仓库不等于该 target 已实现。

## 官方定义来源 / Official definition sources

- SDG 1 无贫穷 / No Poverty: [中文](https://china.un.org/zh/sdgs/1) · [English targets](https://sdgs.un.org/goals/goal1)
- SDG 2 零饥饿 / Zero Hunger: [中文](https://china.un.org/zh/sdgs/2) · [English targets](https://sdgs.un.org/goals/goal2)
- SDG 3 良好健康与福祉 / Good Health and Well-being: [中文](https://china.un.org/zh/sdgs/3) · [English targets](https://sdgs.un.org/goals/goal3)
- SDG 4 优质教育 / Quality Education: [中文](https://china.un.org/zh/sdgs/4) · [English targets](https://sdgs.un.org/goals/goal4)
- SDG 5 性别平等 / Gender Equality: [中文](https://china.un.org/zh/sdgs/5) · [English targets](https://sdgs.un.org/goals/goal5)
- SDG 6 清洁饮水和卫生设施 / Clean Water and Sanitation: [中文](https://china.un.org/zh/sdgs/6) · [English targets](https://sdgs.un.org/goals/goal6)
- SDG 7 经济适用的清洁能源 / Affordable and Clean Energy: [中文](https://china.un.org/zh/sdgs/7) · [English targets](https://sdgs.un.org/goals/goal7)
- SDG 8 体面工作和经济增长 / Decent Work and Economic Growth: [中文](https://china.un.org/zh/sdgs/8) · [English targets](https://sdgs.un.org/goals/goal8)
- SDG 9 产业、创新和基础设施 / Industry, Innovation and Infrastructure: [中文](https://china.un.org/zh/sdgs/9) · [English targets](https://sdgs.un.org/goals/goal9)
- SDG 10 减少不平等 / Reduced Inequalities: [中文](https://china.un.org/zh/sdgs/10) · [English targets](https://sdgs.un.org/goals/goal10)
- SDG 11 可持续城市和社区 / Sustainable Cities and Communities: [中文](https://china.un.org/zh/sdgs/11) · [English targets](https://sdgs.un.org/goals/goal11)
- SDG 12 负责任消费和生产 / Responsible Consumption and Production: [中文](https://china.un.org/zh/sdgs/12) · [English targets](https://sdgs.un.org/goals/goal12)
- SDG 13 气候行动 / Climate Action: [中文](https://china.un.org/zh/sdgs/13) · [English targets](https://sdgs.un.org/goals/goal13)
- SDG 14 水下生物 / Life Below Water: [中文](https://china.un.org/zh/sdgs/14) · [English targets](https://sdgs.un.org/goals/goal14)
- SDG 15 陆地生物 / Life on Land: [中文](https://china.un.org/zh/sdgs/15) · [English targets](https://sdgs.un.org/goals/goal15)
- SDG 16 和平、正义与强大机构 / Peace, Justice and Strong Institutions: [中文](https://china.un.org/zh/sdgs/16) · [English targets](https://sdgs.un.org/goals/goal16)
- SDG 17 促进目标实现的伙伴关系 / Partnerships for the Goals: [中文](https://china.un.org/zh/sdgs/17) · [English targets](https://sdgs.un.org/goals/goal17)

## 颜色、图标与归属 / Colours, icons and attribution

本数据提供目标编号、标题及单个目标色，不重绘或改变官方 SDG 图标，不使用联合国徽记，也不宣称联合国支持或认证。若后续下载官方图标，应保留原比例、原色和完整标题，并遵循 [UN SDG communications materials](https://www.un.org/sustainabledevelopment/news/communications-material/) 链接的使用指南。

## 集成结构 / Integration contract

所有双语字段使用 `{zh, en}`。

- `goals[]`: id, name, color, source_id, url, url_zh。
- `sources[]`: id, name, url, url_zh, status, checked_at, scope。verified 状态只针对定义来源。
- `sdg_targets[]`: code, sdg, text, verified, text_kind, source_checked, source_id, url, url_zh。
- `impact_projects[]`: id, title, sdgs, sdg_targets, skills, roles, level, hours, acceptance, rationale, synthetic, status。status 为 project_idea。
- `sdg_links[]`: from_type, from_id, sdg, target, contribution (direct/enabling/risk), strength, rationale, source_id, project_id, synthetic；风险另有 mitigation。
- `platform_contributions[]`: 平台潜在贡献机制与核查指标，未声称已经获得成效。
- `meta`: 日期、项目创意声明及原文/释义说明；顶层 schema_version 为 2。

技能引用沿用现有目录并加入计划技能 llm-hw、bms、safety、chiplet、ai-ran。岗位新增 ai-eda、bms、chiplet、ai-ran。本资产不创建 task ID；任务层应由预测模型的岗位任务图连接。

## 后续证据清单 / Evidence follow-up

1. 若将释义换为完整原文，逐条核对中英文后更新 verified，不可批量标真。
2. 实施前记录基线、对照、测试条件、误差、参与者同意、生命周期及必要的安全隐私条件。
3. 实际贡献须增加测量期间、结果、复核者与来源；在此之前保留项目创意标记。
4. 平台的就业、教育与包容效果需实际用户数据，不能由示例数量推出。

