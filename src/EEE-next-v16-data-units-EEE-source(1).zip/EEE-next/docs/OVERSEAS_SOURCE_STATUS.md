# 海外招聘源接入核对 · 2026-10-24

参考团队《EEE_Next_地区岗位与数据接入可视化指南(1).pdf》。指南描述v8格式；当前系统保留德国DE，其他欧洲EU，不沿用德国全部映射EU的旧限制。

Ashby官方公开岗位API文档：https://developers.ashbyhq.com/docs/public-job-posting-api 。本次匿名请求menlo、serverobotics、skydio、the-exploration-company四个端点均HTTP403，响应含错误1010；网页读取menlo同样失败。没有绕过访问限制，没有把失败记成零岗位或成功入库。其余22板未继续重复请求。国内3258条和既有10个官方统计缓存不受影响。

指南列26板，仅是待接入清单，不是成功采集数据：

- 新加坡方向：openai、menlo、GoVenti、lumilens。
- 马来西亚方向：serverobotics、overview。
- 美国方向：skydio、hinge-health、meter、whoop、picogrid、rivet、oratomic、pano-ai、impulse、persona.ai。
- 德国方向：the-exploration-company、vaeridion、tactiliarobotics、munich-electrification、orbem、krakentech。
- 其他欧洲方向：robin-radar、monumental、fiducial、mistral.ai。

端点格式：`https://api.ashbyhq.com/posting-api/job-board/<board>?includeCompensation=true`。后续只有在能合法读取实际响应后才可导入。公司板面向全球，必须按岗位primary/secondary address的实际国家映射，不能按以上清单的企业归属强行分地区。isListed必须true；保留快照与岗位链接，以jobUrl去重。publishedAt是最近发布，不保证首次发布。远程不等于全球可应聘。

薪资须保留币种、工资周期、基本工资与奖金/股权的区别，不能跨币种混算。缺薪资/学历保持未知。只提取核对所需短片段；不把整篇JD或个人联络资料复制进公共数据库。企业样本数不是国家需求量；岗位目录技能代理也不能标成雇主要求。
