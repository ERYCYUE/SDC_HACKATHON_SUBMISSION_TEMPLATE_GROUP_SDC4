# Edition 04 — Blue-violet visual update

本次是已实施的视觉与 SDG 总览更新，v2 全量预测 / 评分 / 数据模型仍按后续阶段实施。

This release implements the blue-violet interface and SDG overview. The full v2 forecasting engine, revised scoring and expanded data model remain future phases.

- 全站深蓝背景、蓝紫渐变、分层面板，统一对话、岗位、计划、数据页。Full-site dark blue environment, violet accents and layered panels.
- 共享 17 节点轨道、光场、粒子、轻微鼠标视差；850ms 开场与工作台交叉过渡。Shared 17-node orbital sculpture, atmospheric light, particles, pointer parallax and an 850ms intro/workspace crossfade.
- 新增总览与全部 17 项目标选择器，切换项目创意与目录内相关岗位；选岗进入画像或已确认的岗位详情。Interactive overview links all 17 goals to project ideas and existing catalog roles.
- 新版开场会显示一次；可跳过、Escape 或页脚重播。A versioned session key shows the new opening once; skipping, Escape and replay remain supported.
- 小屏幕使用底部五项导航；装饰图形不拦截操作，尊重减少动态效果设置。Small screens use a five-item bottom navigation, and reduced-motion preferences are respected.
- 原有双语、浏览器内 CV、JSON 导入、学习计划与导出继续保留。Existing bilingual intake, local CV parsing, JSON import, planning and export remain available.

SDG 项目仅为创意，岗位关联来自当前演示目录，不是 target 级专家验证或影响认证。SDG project ideas and catalog links are illustrative; they are not verified target-level mappings or certified impact.

The animations are decorative and do not imply that a model is loading or generating forecasts. No new employment data or trained model is included.
