# EEE Next v2 / Edition 05

电子信息工程职业探索演示：AI 技术追踪与情景预测 → 岗位匹配与再培训路径 → 联合国 17 项 SDG 的具体目标与工程项目。保留蓝紫色动态开场和双语操作。

Bilingual EEE career exploration: AI tracking and scenarios → matching and reskilling → target-level SDG connections and engineering projects. The blue-violet animated opening remains.

## Run / 运行

Node 24 recommended (Node >=22.13 for the app):

```sh
npm ci
npm run dev
node --experimental-strip-types scripts/test-career.mjs
node --experimental-strip-types scripts/test-v2.mjs
node scripts/test-tracking.mjs
npx tsc --noEmit
npm run build
```

## What is implemented / 已实现

- Five shared-context pages: Overview, Track & Forecast, Match & Reskill, SDG Impact, Evidence.
- 12 technology fronts, 16 role categories (4 emerging), 30 skills, 96 task definitions, 17 capstone projects, 35 SDG target entries and 106 target-level links, including 7 risks with mitigation. Catalog definitions, weights and task shares are synthetic team assumptions.
- 技术雷达、2024–2030 播放、三情景曲线、季度论文记录、技能发散图和岗位斜率图；已知技能高亮。范围是情景范围，不是统计置信区间。
- Student / worker intake; four synthetic personas; bilingual aspiration/negation handling; manual profile confirmation; goal pinning without score inflation; synchronized selected-role detail.
- Fit uses personal capabilities only. Outlook uses the model and regional evidence. The quadrant and ranked cards expose both scores, components and adjustable recommendation weights.
- 前置依赖拓扑排序，四类学习阶段；免费 / 付费约束、资源偏好、日期和工时；原岗升级 / 转岗和两岗位比较；SDG 终点项目；完成前后匹配度模拟；进度、本机保存和导出。
- Markdown, JSON, ICS downloads; printable pathway for browser Save as PDF. PDF is a browser print flow, not a server-generated PDF.
- 17-goal heatmap with all/current-role/path scopes; target explanations and verification labels; role–skill–SDG links; reverse matching; project filtering and capstone selection.
- Seven-step evidence explanations across technology, tasks, skills, role outlook, personal fit, pathway and SDG contribution. Six-step bilingual demo tour snapshots and restores the original personal state.

## Data and privacy / 数据与隐私

就业数据由团队自行提供。程序没有抓取任何招聘、工资或就业统计。初始岗位与地区指数均明确标合成。研究追踪计数使用 arXiv API，来源和抓取时间逐条保留；剩余未获取的记录使用明确标注的固定种子合成占位。

The team supplies employment data. No vacancies, salaries or employment statistics are collected. Job and regional demo records are synthetic. arXiv research records retain individual provenance and fetch timestamps; unfetched records remain labeled synthetic placeholders.

CV parsing happens in the browser (TXT / DOCX / text-based PDF, 8 MB, PDF <=30 pages). Scanned PDF needs OCR first. The CV file and full raw text are not persisted or uploaded. Structured profile, chat and progress use localStorage; imported datasets use IndexedDB. Store failures fall back to the current session with a notice. No account or server database was added.

“重新开始个人探索”清除画像、对话、兴趣和进度，保留地区数据。“清空记录”清除岗位、地区与技术记录，保留演示目录，并把空记录状态保存到本机。示例画像不是实际人物。

## Import contract / 导入契约

UTF-8 JSON <=8 MB; <=5,000 combined `jobs` and `signals`. Download the complete v2 template from Evidence. v1 files keep `schema_version:1`, `jobs[]`, `signals[]`; optional v2 arrays are adapted from the demo catalog when absent. Existing role/skill IDs remain compatible.

v2 top-level fields:

```text
schema_version: 2
data_kind: synthetic | user | mixed
meta: last_updated, sources[], changelog[]
jobs[], signals[], tech_fronts[], tracking[], roles[], tasks[], skills[]
sdg_targets[], sdg_links[], resources[], impact_projects[]
```

Bi fields accept `[zh,en]` for the legacy catalog or `{zh,en}` for external JSON. The template contains the full fields required when replacing entire catalogs: skill aliases / hours / URL / rationale, role requirements and skill weights, technology scenario parameters, task shares and effects. Unknown references, invalid ranges/URLs/dates, duplicate rows, inconsistent role/task references and prerequisite cycles are rejected. Invalid imports leave existing data unchanged.

岗位实例影响的是相同地区、相同岗位的技能要求合集，不是“每条岗位都要求全部技能”。`signals[]` 四项指标为 0–100 标准分，不是百分比；v2 可省略缺失指标。计算缺失项时的 50/100 是方法假设，不能写成真实统计。

## Tracking / 研究更新

```sh
node scripts/update-tracking.mjs --from 2024-Q4 --to 2026-Q3
node scripts/update-tracking.mjs --from 2026-Q3 --to 2026-Q3 --tech ai_verification
# Compatibility when max_results=0 is rejected by the API:
node scripts/update-tracking.mjs --from 2024-Q4 --to 2026-Q3 --count-only-compat
node scripts/generate-demo.mjs data/demo-v2.json
```

Queries use completed UTC quarters and `submittedDate`. Requests are spaced at least 3.1 seconds apart. The updater first requests `max_results=0`; after repeated failure it falls back to `max_results=1` and reads only `opensearch:totalResults`. That mode is reused for later requests. Only all-success batches replace the snapshot; failed batches preserve existing counts and record `last_attempt` in `data/tracking-meta.json`.

首次实测中，服务端拒绝零条目请求，兼容模式已成功取得数据。该兼容不改变总结果数的含义；精确检索 URL 保存在各记录中，团队仍需检查关键词与样本含义。论文数量只代表研究活跃度，不是产业应用率、市场需求或预测准确率。

See the [official arXiv API manual](https://info.arxiv.org/help/api/user-manual.html). Eight comparable quarters are needed to show a four-quarter versus previous-four-quarter growth rate. Empty or zero baselines show no growth rate, rather than inventing a percentage.

`.github/workflows/update-tracking.yml` is manually triggered by default. The weekly schedule is commented out. No schedule or external account service has been enabled automatically.

## Methods / 方法

Pure functions live under `lib/model/`. `config.ts` centralizes baseline, thresholds, weights, seed and limits. Technology S curves and task effects are assumptions, not measured adoption. Role demand aggregates remaining, augmented and new tasks; skills normalize to the same scenario's 2026 baseline. Personal fit and outlook are separate. Recommendation defaults to 60% fit / 40% outlook. A target is pinned for display without changing its score.

前置关系先拓扑排序，同等可执行条件下按基础 / 核心 / 进阶与“岗位权重×趋势”排序。项目时间纳入总工时。排期使用连续、不重叠的整周块，单独显示 `ceil(total_hours/weekly_hours)` 的理论最短周数；两者可能不同，因为不重复利用零散剩余工时。

Pathway fit improvement assumes reported learning needs have been learned; it is not a tested proficiency improvement. Progress is self-tracked. Resource links are documentation and open learning, not a promise of complete training or certification. Credential preference reports when no verified credential is available.

Confidence labels describe evidence support, not calibrated probability. Synthetic employment inputs stay limited even when research counts are real. Multiple fields from the same source are not independent. High evidence support needs independent source origins/types, freshness and scenario agreement.

## SDG interpretation / 可持续发展关联

`data/sdg-impact.json` and [SDG_SOURCES.md](SDG_SOURCES.md) retain official-definition sources and verification status. Only explicitly verified entries reproduce checked full wording; other entries are labeled paraphrases. All career/project links and strengths are team assumptions, not UN endorsement. Every goal has a project; every role need not support every goal. Risk links do not increase positive contribution scores.

17 个目标均有内容，不代表已经覆盖所有 169 个子目标。当前目录包含 35 个相关子目标；可通过 v2 数据扩展。能耗反弹、电子废弃物和自动化就业风险包含缓解说明。

## AI integration / 模型接口

DeepSeek conversation, career explanation and pathway advice now call the same-origin `/api/ai` endpoint after explicit per-session opt-in. Until a server key and feature flag are configured, the UI clearly uses the existing local rule-based analysis.

```text
ALLOW_EXTERNAL_AI=false
AI_ENDPOINT=https://api.deepseek.com/chat/completions
AI_MODEL=deepseek-flash
AI_API_KEY=
```

Store `AI_API_KEY` as a Sites server Secret. Endpoint and model have server defaults; only key and enabling flag are essential. Re-deploy after configuring runtime values. Uploaded CV files and their parsed full text are excluded; the opt-in discloses current message, structured profile and selected evidence / SDG / pathway summaries. AI cannot alter scores or confirmed skills. The server has bounded payloads, same-origin checks and per-instance best-effort rate limits. See [DeepSeek setup and verification](docs/DEEPSEEK_SETUP.md) for limits and owner steps. Real-provider calls remain unverified until the owner supplies a key. No employment-prediction model has been trained.

## Verification checklist / 团队待核实

1. Employment data sampling, dates, country coverage and normalization, especially Europe.
2. Technology milestones and their primary sources (milestone arrays default empty).
3. SDG paraphrases, project relevance and strength with domain/project experts.
4. Resource availability, fees, suitability and regional training support; no amounts or eligibility claims are invented.
5. Policy and funding evidence; no inferred numerical policy claims.
6. Calibration with real longitudinal employment outcomes before using these rules as forecasts.

本原型支持用户自主探索，不执行招聘决策，不判定某职业必然消失，不提供联合国影响认证。
