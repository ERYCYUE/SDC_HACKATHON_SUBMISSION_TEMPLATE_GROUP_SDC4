# Bilingual terminology review / 中英文文案检查

Reviewed on 2026-10-20: opening screen, navigation, guided chat, profile confirmation, career comparison, job examples, learning plan, data import, trends table, SDG explanations, technical catalog labels, accessibility labels and user-facing error messages.

## Consistent terminology / 统一表达

| Concept | 中文 | English |
| --- | --- | --- |
| Dated regional data | 各地区就业趋势数据 | Employment trends by region |
| Data file structure | 数据导入格式 | Data import format |
| Job records | 岗位实例（招聘信息或模拟岗位） | Job posting examples |
| Specialization | 专业方向 | Engineering specialization |
| User-provided abilities | 已掌握技能（自评） | Skills you report having |
| Career ranking | 职业方向匹配评分 | Career-option match score |
| Posting retrieval | 岗位实例匹配评分 | Job posting match score |
| Missing information | 尚未勾选／尚未匹配 | Not reported yet / not matched yet |
| Simulated records | 模拟数据 | Simulated data |
| Scenario | 未来情景假设 | Future scenario assumptions |
| Task-level demo measure | AI 对工作任务的影响（演示评分） | Potential AI impact on tasks (demo score) |
| SDG relation | 潜在项目贡献 | Potential contributions through projects |

The Chinese word “信号” is retained only for its engineering meaning, such as signal processing. It is not used for employment trend data. “Signals” remains an internal JSON field name for compatibility, and is explained as employment trend data in the import UI.

“信号”只用于信号处理等工程术语。就业数据不再称为“地区信号”。为兼容已有文件，JSON 字段 `signals` 保留，界面将它解释为就业趋势数据。

## Index definitions / 指数含义

- `demand_index`: 招聘需求指数 / Hiring demand index.
- `ai_adoption`: AI 应用指数 / AI adoption index.
- `funding_index`: 资金投入指数 / Funding index.
- `policy_index`: 政策支持指数 / Policy support index.

These are standardized values from 0 to 100 supplied by the data owner, not percentages. Higher values are interpreted as higher levels of the corresponding indicator. Cross-region comparisons require consistent methods and reporting periods. No data is automatically collected or verified by this prototype.

这些数值由数据提供者按统一标准换算为 0–100 分，不是百分比。分数越高，表示对应指标程度越高。跨地区比较需要一致的计算方法和统计时期。本演示不自动采集或验证就业数据。

When regional trend data is absent, the hiring-demand, funding and policy-support components use 50/100 as calculation defaults. The UI states explicitly that these are not actual assessments of the region. Dates describe the corresponding data, not the file import date. Records older than 180 days receive an update recommendation.

缺失地区趋势数据时，招聘需求、资金投入和政策支持三项暂按 50 分计算。界面明确说明这不是该地区的实际评估。数据日期是指标对应的日期，不是导入日期；超过 180 天提示建议更新。

## Interpretation limits / 结果含义

- Skills are self-reported. Confirming an extracted profile is not a proficiency assessment. An unreported skill may be an extraction omission, not a real deficit.
- Career-option scores and job-posting match scores use different stated formulas. Neither measures hiring probability or actual demand by itself.
- Task-impact demo scores do not predict unemployment or occupational disappearance. Scenario changes compare assumptions.
- Learning hours estimate introductory practice. Project time is additional, and completion checkmarks are self-tracked.
- SDG labels describe possible project contributions, not measured outcomes or certification.
- The chat remains rule-based. AI explanations are available only when a separate model service is connected. User-facing connection errors are localized.
- CV files are imported and read in the browser. An optional AI explanation sends only the disclosed structured fields and retrieved data, not the CV file or raw CV text.

岗位标题、描述等用户导入的原始内容保留原文，避免未经确认的自动翻译改变岗位要求。技术缩写、品牌、来源网址和 JSON 字段名保留必要的英文；界面说明提供中英文。

Imported job titles and descriptions retain their original wording to avoid unverified translations changing requirements. Technical abbreviations, brands, source URLs and JSON field names retain necessary English; explanatory UI text is bilingual.
