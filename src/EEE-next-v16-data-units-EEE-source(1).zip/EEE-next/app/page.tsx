import CareerApp from '@/components/v2/CareerApp';
export default function Home(){return <CareerApp/>;}
