import {env} from 'cloudflare:workers';
import {handleMarket} from '@/lib/market-server';
export const dynamic='force-dynamic';
export async function GET(request:Request){return handleMarket(request,env.DB);}
