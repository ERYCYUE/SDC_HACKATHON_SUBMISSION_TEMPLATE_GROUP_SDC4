import {env} from 'cloudflare:workers';
import {handleAI,type AIEnv} from '@/lib/ai-server';
export const dynamic='force-dynamic';
export const GET=(request:Request)=>handleAI(request,env as AIEnv);
export const POST=(request:Request)=>handleAI(request,env as AIEnv);
