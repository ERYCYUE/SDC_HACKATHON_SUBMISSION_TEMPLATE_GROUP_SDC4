import {env} from 'cloudflare:workers';
import {handleInternational} from '@/lib/international-server';
export async function GET(request:Request){return handleInternational(request,(env as Cloudflare.Env).DB);}
