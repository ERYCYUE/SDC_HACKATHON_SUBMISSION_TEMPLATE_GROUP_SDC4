import seed from '../data/international-employment.json';
import {publicFeeds,fetchPublicFeed,type FeedSnapshot} from './international.ts';
import {validObservation} from './statistics.ts';
type CacheRow={id:string;payload:string;retry_at:number;last_error:string|null;last_attempt:string|null};
const DAY=86400000;
export async function handleInternational(request:Request,db:D1Database|undefined,waitUntil?:(p:Promise<unknown>)=>void){
 if(request.method!=='GET')return Response.json({code:'METHOD_NOT_ALLOWED'},{status:405,headers:{Allow:'GET'}});
 if(!db)return Response.json({code:'DATABASE_UNAVAILABLE'},{status:503});
 try{
  // Only trusted packaged seed is accepted; the public API has no write/import parameters.
  const existing=await db.prepare('SELECT id FROM public_employment_feeds').all<{id:string}>();
  const missing=(seed as FeedSnapshot[]).filter(s=>!existing.results.some(r=>r.id===s.id));
  if(missing.length)await db.batch(missing.map(s=>db.prepare('INSERT INTO public_employment_feeds (id,payload,retry_at) VALUES (?,?,?) ON CONFLICT(id) DO NOTHING').bind(s.id,JSON.stringify(s),Date.parse(s.fetchedAt)+DAY)));
  const cache=await db.prepare('SELECT id,payload,retry_at,last_error,last_attempt FROM public_employment_feeds').all<CacheRow>(),now=Date.now();
  const refresh=async(row:CacheRow)=>{
   const feed=publicFeeds.find(f=>f.id===row.id);if(!feed)return;
   // Atomic lease across Worker instances prevents visitor-triggered quota exhaustion.
   const lease=await db.prepare('UPDATE public_employment_feeds SET retry_at=? WHERE id=? AND retry_at<=? RETURNING id').bind(now+DAY,row.id,now).first();if(!lease)return;
   try{const next=await fetchPublicFeed(feed);await db.prepare('UPDATE public_employment_feeds SET payload=?,last_error=NULL,last_attempt=?,retry_at=? WHERE id=?').bind(JSON.stringify(next),next.fetchedAt,Date.now()+DAY,row.id).run();}
   catch(e){await db.prepare('UPDATE public_employment_feeds SET last_error=?,last_attempt=?,retry_at=? WHERE id=?').bind(e instanceof Error?e.message:'Fetch failed',new Date().toISOString(),Date.now()+6*3600000,row.id).run();}
  };
  const due=cache.results.filter(r=>r.retry_at<=now).sort((a,b)=>a.retry_at-b.retry_at).slice(0,2);
  if(due.length){const pending=Promise.all(due.map(refresh));if(waitUntil)waitUntil(pending);else await pending;}
  const snapshots=cache.results.filter(r=>publicFeeds.some(f=>f.id===r.id)).map(r=>{const s=JSON.parse(r.payload) as FeedSnapshot,rows=s.rows.filter(validObservation),rejected=s.rows.length-rows.length;return{...s,rows,error:[r.last_error,rejected?`${rejected} invalid cached observations withheld`:null].filter(Boolean).join('; ')||undefined,lastAttempt:r.last_attempt||undefined};});
  return Response.json({snapshots,refreshMode:'access-triggered-24h',staleAfterHours:48},{headers:{'Cache-Control':'public, max-age=120','X-Data-Source':'D1'}});
 }catch(e){console.error('International feed database error',e instanceof Error?e.message:'unknown');return Response.json({code:'DATABASE_READ_FAILED'},{status:503});}
}
