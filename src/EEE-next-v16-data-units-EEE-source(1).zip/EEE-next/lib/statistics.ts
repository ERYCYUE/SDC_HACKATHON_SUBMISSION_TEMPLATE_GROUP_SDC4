/** Domain checks shared by retrieval, cached responses and display. No clamping. */
export type StatisticalObservation={period:string;dimension:string;metric:string;value:number;unit:string};
const expectedUnits:Record<string,string>={u_rate:'%',p_rate:'%',lf_employed:'thousand persons',lf_unemployed:'thousand persons',wages_median:'MYR/month',wages_mean:'MYR/month',vacancies:'vacancies',registrations:'vacancies',employed:'persons',openings:'thousand vacancies',projected_growth:'%',annual_wage:'USD/year',annual_openings:'thousand vacancies'};
export function validObservation(r:StatisticalObservation):boolean{
 if(!r||typeof r.value!=='number'||!Number.isFinite(r.value)||typeof r.period!=='string'||!r.period||typeof r.dimension!=='string'||!Object.hasOwn(expectedUnits,r.metric)||r.unit!==expectedUnits[r.metric])return false;
 if(r.metric==='projected_growth')return r.value>=-100; // Employment decline is valid.
 if(r.metric==='u_rate'||r.metric==='p_rate')return r.value>=0&&r.value<=100;
 return r.value>=0; // Counts and pay cannot be negative; zero is meaningful.
}
export function observationChange(latest:StatisticalObservation|undefined,previous:StatisticalObservation|undefined,lang:'zh'|'en'){
 if(!latest||!previous||!validObservation(latest)||!validObservation(previous)||latest.metric!==previous.metric||latest.dimension!==previous.dimension||latest.unit!==previous.unit||latest.period<=previous.period)return null;
 const delta=Number((latest.value-previous.value).toPrecision(12));
 if(delta===0)return lang==='zh'?'持平':'Unchanged';
 const units:Record<string,[string,string]>={'%':['个百分点','percentage points'],'thousand persons':['千人','thousand persons'],persons:['人','persons'],vacancies:['个职位','vacancies'],'thousand vacancies':['千个职位','thousand vacancies'],'MYR/month':['MYR/月','MYR/month'],'USD/year':['USD/年','USD/year']};
 const amount=Math.abs(delta).toLocaleString(lang==='zh'?'zh-CN':'en-US',{maximumFractionDigits:6}),unit=units[latest.unit][lang==='zh'?0:1];
 return lang==='zh'?`${delta>0?'上升':'下降'} ${amount} ${unit}`:`${delta>0?'Up':'Down'} ${amount} ${unit}`;
}
