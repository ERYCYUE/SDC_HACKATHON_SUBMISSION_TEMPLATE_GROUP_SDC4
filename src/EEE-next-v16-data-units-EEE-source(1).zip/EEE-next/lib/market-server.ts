import seed from '../data/cn-employment.json';
import type {MarketBundle} from './market.ts';
const bundle=seed as MarketBundle;
let initializing:Promise<void>|null=null;
export async function ensureMarketSeed(db:D1Database){
 const existing=await db.prepare('SELECT row_count FROM employment_batches WHERE id = ?').bind(bundle.meta.id).first<{row_count:number}>();
 if(existing?.row_count===bundle.postings.length)return;
 if(!initializing)initializing=(async()=>{
  const statements:D1PreparedStatement[]=[];
  for(let i=0;i<bundle.postings.length;i+=20){const chunk=bundle.postings.slice(i,i+20);statements.push(db.prepare(`INSERT INTO employment_postings (id,batch_id,role_id,payload) VALUES ${chunk.map(()=>'(?,?,?,?)').join(',')} ON CONFLICT(id,batch_id) DO UPDATE SET role_id=excluded.role_id,payload=excluded.payload`).bind(...chunk.flatMap(j=>[j.id,bundle.meta.id,j.roleId,JSON.stringify(j)])));}
  statements.push(db.prepare('INSERT INTO employment_batches (id,meta,row_count) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET meta=excluded.meta,row_count=excluded.row_count').bind(bundle.meta.id,JSON.stringify(bundle.meta),bundle.postings.length));
  // One atomic batch: readers cannot observe a half-imported release.
  await db.batch(statements);
 })().finally(()=>{initializing=null;});
 await initializing;
}
export async function handleMarket(request:Request,db:D1Database|undefined){
 if(request.method!=='GET')return Response.json({code:'METHOD_NOT_ALLOWED'},{status:405,headers:{Allow:'GET'}});
 if(!db)return Response.json({code:'DATABASE_UNAVAILABLE'},{status:503});
 try{await ensureMarketSeed(db);const meta=await db.prepare('SELECT meta FROM employment_batches WHERE id=?').bind(bundle.meta.id).first<{meta:string}>();const result=await db.prepare('SELECT payload FROM employment_postings WHERE batch_id=? ORDER BY id').bind(bundle.meta.id).all<{payload:string}>();
  return Response.json({meta:JSON.parse(meta!.meta),postings:result.results.map(r=>JSON.parse(r.payload))},{headers:{'Cache-Control':'public, max-age=120','X-Data-Source':'D1','X-Data-Batch':bundle.meta.id}});
 }catch(error){console.error('market database operation failed',error instanceof Error?error.message:'unknown');return Response.json({code:'DATABASE_READ_FAILED'},{status:503});}
}
