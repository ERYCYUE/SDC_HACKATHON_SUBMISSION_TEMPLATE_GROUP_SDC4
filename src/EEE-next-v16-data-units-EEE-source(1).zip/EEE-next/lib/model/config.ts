import type {Context,Scenario} from './types.ts';
export const CONFIG={baselineYear:2026,seed:20261021,automateAlpha:.8,automationDemandBeta:.6,growthAdjustLimit:.35,trendThreshold:8,augmentThreshold:.5,freshDays:180,maxRows:12000,fit:{coverage:.65,branch:.2,transfer:.15},outlook:{growth:.5,resilience:.3,funding:.1,policy:.1},yearRange:[2026,2030]} as const;
export const scenarioNames:Record<Scenario,[string,string]>={gradual:['渐进协作','Gradual collaboration'],ai_accel:['AI 加速应用','Accelerated AI adoption'],green:['绿色转型投入','Green transition investment']};
export const defaultContext:Context={region:'CN',scenario:'gradual',year:2030,aiSpeed:50,greenInvestment:50,policySupport:50,fitWeight:.6,asOf:'2026-10-21'};
export const phaseNames={foundation:['基础','Foundations'],core:['核心','Core'],advanced:['进阶','Advanced'],impact:['影响力项目','Impact project']} as const;
