import type {Person,CareerData} from './types.ts';
import {entryStatistics,milestones,type Education} from './entry-gaps.ts';
export const backgroundNames={project:['相关工程项目（课程或竞赛项目也可）','Relevant engineering project (coursework counts)'],research:['科研项目','Research project'],publication:['论文','Publication'],internship:['实习','Internship'],competition:['竞赛 / 项目展示','Competition / showcase'],opensource:['开源项目','Open-source project'],production:['流片或量产项目','Tape-out / production project'],english:['英语读写或证明','English proficiency / credentials']} satisfies Record<string,[string,string]>;
export type Background=keyof typeof backgroundNames;
export const educationStages={unknown:['未填写','Not provided'],'bachelor-studying':['本科在读','Bachelor student'],'bachelor-completed':['本科毕业','Bachelor completed'],'master-studying':['硕士在读','Master student'],'master-completed':['硕士毕业','Master completed'],'doctor-studying':['博士在读','Doctoral student'],'doctor-completed':['博士毕业','Doctorate completed'],other:['其他 / 手动填写','Other / enter manually']} satisfies Record<string,[string,string]>;
export function educationStagePatch(stage:string,p:Person):Partial<Person>{
 const level=stage.split('-')[0] as Education,studying=stage.endsWith('studying');
 if(!['bachelor','master','doctor'].includes(level))return{educationStage:stage};
 if(!studying)return{educationStage:stage,education:level,educationBasis:'current'};
 const levels=['secondary','associate','bachelor','master','doctor'],safe=p.education&&levels.indexOf(p.education)<levels.indexOf(level)?p.education:'unknown';
 return{educationStage:stage,kind:'student',plannedEducation:level,education:safe,educationBasis:'graduation'};
}
export function extractEducation(text:string,old:Person):Partial<Person>{
 const factual=text.split(/想|希望|打算|计划|want|hope|plan|aim/i)[0],patch:Partial<Person>={};
 const stages:[RegExp,string][]=[[/博士(?:在读|生)|doctoral student|phd student/i,'doctor-studying'],[/博士毕业|已取得博士|completed (?:a )?(?:phd|doctorate)/i,'doctor-completed'],[/硕士(?:在读|生)|研究生在读|master.?s? student/i,'master-studying'],[/硕士毕业|已取得硕士|completed (?:a )?master/i,'master-completed'],[/本科在读|本科生|大[一二三四]|undergraduate|bachelor.?s? student|(?:first|second|third|fourth).year.*student/i,'bachelor-studying'],[/本科毕业|已取得本科|completed (?:a )?bachelor/i,'bachelor-completed']];
 const stage=stages.find(([re])=>re.test(factual));if(stage)Object.assign(patch,educationStagePatch(stage[1],old));
 const yr=factual.match(/大([一二三四])|\b(first|second|third|fourth).year/i);if(yr)patch.studyYear=yr[1]?'一二三四'.indexOf(yr[1])+1:['first','second','third','fourth'].indexOf(yr[2].toLowerCase())+1;
 if(/不考虑读研|不想读研|不打算读研|do not plan.*master/i.test(text))patch.graduateInterest='no';else if(/考虑读研|想读研|希望读研|consider.*master/i.test(text))patch.graduateInterest='yes';else if(/读研.*不确定|不确定.*读研|unsure.*master/i.test(text))patch.graduateInterest='unsure';
 const positive=factual.split(/[。；;\n]/).filter(x=>!/(没|无|未|不曾|no |without|haven.t)/i.test(x));
 const patterns:Partial<Record<Background,RegExp>>={project:/做过.{0,30}项目|完成.{0,20}项目|built.{0,60}project/i,research:/参与.{0,15}科研|做过.{0,15}科研|research experience/i,publication:/发表.{0,15}论文|published.{0,30}paper/i,internship:/有.{0,10}实习经历|实习过|completed.{0,15}internship/i,production:/参与.{0,10}流片|完成.{0,10}量产|tape.out experience/i};
 const found=Object.entries(patterns).filter(([,re])=>positive.some(x=>re!.test(x))).map(([key])=>key);
 if(found.length)patch.entryExperiences=[...new Set([...(old.entryExperiences||[]),...found])];
 return patch;
}
const patterns:Record<Background,RegExp>={project:/相关项目|验证项目|项目经验|项目经历|project experience|verification project/i,research:/科研|research/i,publication:/论文|publication|published paper/i,internship:/实习|internship/i,competition:/竞赛|competition|hackathon/i,opensource:/开源|open.source/i,production:/流片|量产|tape.out|production experience/i,english:/英语|english|ielts|toefl|cet[- ]?[46]/i};
// A conservative, auditable text aid. Explicit team annotations take precedence.
export function requirementMentions(job:CareerData['jobs'][number]){
 const map=new Map<Background,{kind:Background;level:'required'|'preferred';quote:string}>();
 for(const x of job.experience_requirements||[])if(x.kind in backgroundNames)map.set(x.kind as Background,{...x,kind:x.kind as Background});
 const lines=[job.requirement_excerpt||'',job.description||''].join('\n').split(/[。；;\n]/);
 for(const line of lines){if(/无需|不要求|不需要|不强制|not required|no.{0,25}(required|necessary)|without.{0,25}experience/i.test(line))continue;
  const preferred=/优先|加分|preferred|a plus|advantage/i.test(line),required=/必须|要求|需具备|须具备|必备|required|must have|essential/i.test(line);
  if(!preferred&&!required)continue;
  for(const [kind,re] of Object.entries(patterns))if(re.test(line)&&!map.has(kind as Background))map.set(kind as Background,{kind:kind as Background,level:preferred?'preferred':'required',quote:line.slice(0,600)});
 }
 for(const x of job.preferred_experiences||[]){const k=x==='networking'?null:x as Background;if(k&&!map.has(k))map.set(k,{kind:k,level:'preferred',quote:job.requirement_excerpt||''});}
 return [...map.values()];
}
export function experienceSummary(jobs:CareerData['jobs'],p:Person){
 return (Object.keys(backgroundNames) as Background[]).map(kind=>{let required=0,preferred=0;for(const j of jobs){const m=requirementMentions(j).find(x=>x.kind===kind);if(m?.level==='required')required++;if(m?.level==='preferred')preferred++;}
 const provided=(p.entryExperiences||[]).includes(kind)||(kind==='english'&&!!p.english?.trim()),known=kind==='english'?provided:provided||!!p.experiencesConfirmed;
 return{kind,required,preferred,requiredShare:jobs.length?required/jobs.length*100:null,preferredShare:jobs.length?preferred/jobs.length*100:null,provided,known,gap:jobs.length>=30&&required/jobs.length>=.3&&known&&!provided};});
}
export function experienceBands(jobs:CareerData['jobs']){const known=jobs.filter(j=>j.experience_min_years!==undefined),n=known.length;return{n,unknown:jobs.length-n,rows:[{id:'entry',count:known.filter(j=>j.experience_min_years===0).length},{id:'junior',count:known.filter(j=>j.experience_min_years!>0&&j.experience_min_years!<=3).length},{id:'senior',count:known.filter(j=>j.experience_min_years!>3).length}]};}
export type Route='direct'|'graduate'|'work-first';
export const routeNames:Record<Route,[string,string]>={direct:['直接就业','Direct employment'],graduate:['读研','Graduate study'],'work-first':['先工作再提升','Work first, then develop']};
export function routeMilestones(route:Route,role:[string,string],worker=false){
 if(route==='graduate')return worker?milestones.map(m=>({...m,title:[m.title[0].replace(/大[一二三四](暑期)?：/,`阶段 ${m.year}：`),m.title[1].replace(/Year [1-4]( summer)?:/,`Phase ${m.year}:`)] as [string,string]})):milestones;
 const rows=route==='direct'?[
  ['项目基础','Project foundations',`完成一个与${role[0]}相关的小项目，保留代码、测试和个人贡献。`,`Build a small ${role[1]} project; keep code, tests and your own contribution.`],
  ['作品与交流','Portfolio and feedback','整理项目作品集，与教师或行业工程师核对岗位任务。','Curate a portfolio and discuss job tasks with a teacher or engineer.'],
  ['实习与验证','Internship and validation','按条件选择实习或开源项目，用岗位原文核对经历缺口。','Choose an internship or open project and check experience gaps against postings.'],
  ['投递与复盘','Applications and reflection','并行比较目标岗位与相邻岗位，逐条核对学历、经验和英语要求。','Compare target and adjacent roles; check degree, experience and English requirements.']
 ]:[
  ['确定起点','Choose a starting point','选择当前可申请的岗位，确认工作任务与可学习的技能。','Choose accessible roles and identify tasks and skills you can develop.'],
  ['工作项目','Work projects','在职责允许范围内积累可展示的工程项目证据，不泄露企业资料。','Build shareable project evidence within your responsibilities and employer confidentiality rules.'],
  ['在职学习','Learning alongside work','按每周可投入时间学习；核对课程、证书或在职硕士的认可度与成本。','Study within your weekly budget; verify course, credential and part-time degree recognition and cost.'],
  ['重新评估','Reassess options','用新岗位样本更新覆盖率，结合项目证据决定升级、转岗或深造。','Refresh coverage with new postings and use project evidence to compare upskilling, a role change or further study.']
 ];
 return rows.map((r,i)=>({id:`${route}-${i+1}`,year:i+1,kind:(i===2?'internship':'competition') as 'internship'|'competition',title:[worker?`阶段 ${i+1}：${r[0]}`:`大${'一二三四'[i]}：${r[0]}`,worker?`Phase ${i+1}: ${r[1]}`:`Year ${i+1}: ${r[1]}`] as [string,string],detail:[r[2],r[3]] as [string,string]}));
}
