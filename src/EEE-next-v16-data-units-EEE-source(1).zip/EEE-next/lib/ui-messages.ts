import {bi,type Bi,type Lang} from './career';

const importErrors:Record<string,Bi>={
 'JSON object required':['文件的最外层必须是 JSON 对象，请参考下载的数据模板。','The file must contain a JSON object. Use the downloadable data template as a reference.'],
 'schema_version=1; jobs + signals: 1–5000 rows':['请将 schema_version 设为 1，并提供 jobs 和 signals 两个数组；两者合计需要 1–5,000 条记录。','Set schema_version to 1 and include both jobs and signals arrays, with 1–5,000 records in total.'],
 'data_kind: synthetic | user':['data_kind 只能填写 synthetic（模拟数据）或 user（用户数据）。','Set data_kind to synthetic for simulated data or user for user-provided data.'],
 'Invalid / duplicate job. Check IDs, region, role_id, skills, source_url, published_at.':['岗位记录存在格式错误或重复编号。请检查岗位编号、岗位类别、地区、技能编号、来源网址和发布日期。','A job record is invalid or its ID is duplicated. Check the job ID, role category, region, skill IDs, source URL and publication date.'],
 'Invalid / duplicate signal. Indices must be 0–100; one row per region + role_id.':['就业趋势记录存在格式错误或重复。同一地区的同一岗位类别只能有一条记录，四项指数必须为 0–100 的数字；还需填写有效的数据日期和来源网址。','An employment trend record is invalid or duplicated. Keep one record per region and role category, use numbers from 0 to 100 for all four indices, and include a valid data date and source URL.']
};

export function dataImportMessage(error:unknown,lang:Lang):string{
 if(error instanceof SyntaxError)return bi(['文件不是有效的 JSON。请检查逗号、引号和括号，或重新下载模板后填写。','The file is not valid JSON. Check commas, quotation marks and brackets, or start again from the downloadable template.'],lang);
 const message=error instanceof Error?error.message:'';
 return bi(importErrors[message]||['无法导入文件，请检查 JSON 内容是否符合本页的数据导入格式。','The file could not be imported. Check that its JSON content follows the import format on this page.'],lang);
}

export function cvReadMessage(error:unknown,lang:Lang):string{
 const message=error instanceof Error?error.message:'';
 if(/[\u4e00-\u9fff]/.test(message)||/^(CV files|PDF CVs|Choose a CV|Not enough text could be read|The CV text)/.test(message))return message;
 if(/password|encrypted/i.test(message))return bi(['无法读取加密的 PDF。请先解除文件密码，或导入不加密的版本。','The PDF is password-protected. Remove the password first or import an unencrypted copy.'],lang);
 return bi(['无法读取这份简历。请确认文件未损坏、格式正确，或改用 TXT 文件／将文字粘贴到对话框。','This CV could not be read. Check that the file is intact and in the correct format, or use a TXT file or paste the text into the chat.'],lang);
}

export function modelErrorMessage(error:unknown,lang:Lang):string{
 const message=error instanceof Error?error.message:'';
 const status=message.match(/Model provider failed \((\d+)\)/)?.[1];
 if(status)return bi([`模型服务暂时无法完成请求（状态码 ${status}）。你仍可使用规则评分结果。`,`The model provider could not complete the request (status ${status}). Rule-based scores remain available.`],lang);
 if(/Invalid provider response/.test(message))return bi(['模型服务返回的内容无法读取，请联系项目维护者检查接口配置。','The model response could not be read. Ask the project maintainer to check the API configuration.'],lang);
 if(/not configured|HTTPS/.test(message))return bi(['模型服务尚未正确配置，请联系项目维护者检查接入设置。','The model service is not configured correctly. Ask the project maintainer to check the connection settings.'],lang);
 if(/Origin rejected/.test(message))return bi(['请求来源校验未通过，请从本网站重新发起请求。','The request origin could not be verified. Submit the request from this website.'],lang);
 if(/Invalid analysis payload|Request too large/.test(message))return bi(['待解读的数据格式或大小不符合要求，请减少内容后重新生成。','The analysis data has an unsupported format or is too large. Reduce it and try again.'],lang);
 return bi(['无法连接模型服务或请求已超时，请稍后重试；当前规则评分结果仍可查看。','The model service could not be reached or the request timed out. Try again later. Rule-based scores remain available.'],lang);
}
