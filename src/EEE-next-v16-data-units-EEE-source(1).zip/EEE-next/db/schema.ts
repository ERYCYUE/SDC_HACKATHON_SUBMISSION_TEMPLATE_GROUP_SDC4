import {sqliteTable,text,integer,primaryKey,index} from 'drizzle-orm/sqlite-core';
export const employmentBatches=sqliteTable('employment_batches',{id:text('id').primaryKey(),meta:text('meta').notNull(),rowCount:integer('row_count').notNull()});
export const employmentPostings=sqliteTable('employment_postings',{id:text('id').notNull(),batchId:text('batch_id').notNull(),roleId:text('role_id').notNull(),payload:text('payload').notNull()},t=>[primaryKey({columns:[t.id,t.batchId]}),index('employment_batch_idx').on(t.batchId),index('employment_role_idx').on(t.roleId)]);

export const publicEmploymentFeeds=sqliteTable('public_employment_feeds',{id:text('id').primaryKey(),payload:text('payload').notNull(),retryAt:integer('retry_at').notNull(),lastError:text('last_error'),lastAttempt:text('last_attempt')});
