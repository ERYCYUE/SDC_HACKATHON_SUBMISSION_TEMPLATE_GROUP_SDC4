import type {CareerData,Person,Context,Bi} from './types.ts';
import {educationPass,isObservedJob,canonicalJobURL} from './entry-gaps.ts';
import {resolveGoal} from './profile.ts';
type Check={name:Bi;status:'pass'|'gap'|'unknown';detail:Bi};
/** Actual observed advertisements only. Unknown requirements never count as passed. */
export function rankObservedPostings(p:Person,c:Context,d:CareerData){
 const goal=resolveGoal(p.goal,d),projected=p.kind==='student'&&p.educationBasis==='graduation';
 const records=new Map(d.market?.postings.map(j=>[j.id,j])||[]);
 const degree=(projected?p.plannedEducation:p.education)||'unknown',seen=new Set<string>();
 const candidates=[...d.jobs].sort((a,b)=>(b.snapshot_date||b.published_at||'').localeCompare(a.snapshot_date||a.published_at||'')).filter(j=>{try{if(j.region!==c.region||!isObservedJob(j)||!/^https?:/.test(j.source_url))return false;const key=canonicalJobURL(j.source_url);if(seen.has(key))return false;seen.add(key);return true;}catch{return false;}});
 return candidates.flatMap(job=>{const role=d.roles.find(r=>r.id===job.role_id);if(!role)return [];
  const catalog=!job.skills.length,requirements=catalog?role.skills:job.skills;
  const matched=requirements.filter(id=>p.skills.includes(id)),missing=requirements.filter(id=>!p.skills.includes(id));
  const skill=matched.length/Math.max(1,requirements.length)*100,branch=role.branch===p.branch,goalMatch=role.id===goal;
  // Do not recommend an unrelated advertisement simply because it has a lower degree requirement.
  if(!branch&&!goalMatch&&!matched.length)return [];
  const edu=educationPass(degree,job.education_min||'unknown');
  const years=typeof p.workYears==='number'?p.workYears:null,min=job.experience_min_years;
  const exp=min===undefined||years===null?null:years>=min;
  const campus=/在校|应届|intern|graduate/i.test(job.experience_raw||'');
  const checks:Check[]=[
   {name:['学历条件','Education'],status:edu===null?'unknown':edu?'pass':'gap',detail:edu===null?['用户或岗位学历信息未提供，需核对。','The user or posting qualification is unknown; confirm it.']:edu?['所选学历达到样本中的最低学历。','The selected qualification meets the recorded minimum.']:['所选学历低于样本要求，可比较相邻岗位与提升路线。','The selected qualification is below the recorded minimum; compare adjacent roles and development routes.']},
   {name:['工作经验','Work experience'],status:exp===null?'unknown':exp?'pass':'gap',detail:exp===null?['经验年数或明确最低年限未知；“经验不限”不等于确认零经验可入职。','Years or the explicit minimum are unknown. Unrestricted experience does not certify entry without experience.']:exp?['自报全职年数达到记录中的最低年限。','Self-reported full-time years meet the recorded minimum.']:[`记录至少要求 ${min} 年，自报 ${years} 年。`,`The recorded minimum is ${min} years; you reported ${years}.`]},
  ];
  if(campus)checks.push({name:['在校 / 应届身份','Student / graduate eligibility'],status:'unknown',detail:['需向企业核对毕业年份、在校身份与招聘批次。','Confirm graduation year, student status and recruitment cohort with the employer.']});
  const record=records.get(job.job_id);
  if(record?.schoolRequired)checks.push({name:['院校条件','Institution requirement'],status:'unknown',detail:[record.schoolRequired,record.schoolRequired]});
  if(job.english_requirement)checks.push({name:['英语条件','English requirement'],status:'unknown',detail:[job.english_requirement,job.english_requirement]});
  const gaps=checks.filter(x=>x.status==='gap').length,unknowns=checks.filter(x=>x.status==='unknown').length;
  const parts={skills:skill*(goal ? 0.45 : 0.7),specialization:branch?10:0,education:edu===true?10:0,experience:exp===true?10:0,goal:goalMatch?25:0};
  const score=Object.values(parts).reduce((s,x)=>s+x,0);
  return [{job,role,record,checks,matched,missing,catalog,score,parts,gaps,unknowns,projected,degree,goalMatch,branch}];
 }).sort((a,b)=>a.gaps-b.gaps||b.score-a.score||a.unknowns-b.unknowns||(b.job.snapshot_date||b.job.published_at||'').localeCompare(a.job.snapshot_date||a.job.published_at||'')||a.job.job_id.localeCompare(b.job.job_id));
}
