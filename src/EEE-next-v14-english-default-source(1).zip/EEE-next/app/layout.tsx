import type { Metadata } from "next";
import "./globals.css";
import "./visual-theme.css";
import "./career-v2.css";

export const metadata: Metadata = {
  title: "EEE Next | EEE Career Navigator",
  description: "Explore your next role in electronic and information engineering. Bilingual career conversations, evidence and learning pathways.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
