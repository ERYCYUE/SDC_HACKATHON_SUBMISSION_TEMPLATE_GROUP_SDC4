import { GetInternationalResponse } from "@workspace/api-zod";
import seed from "../data/international-employment.json" with { type: "json" };
import { logger } from "../../lib/logger";

// Validate once per process. A new release must rebuild the stateless service.
// The digest describes the collected source, not a hash of normalized rows.
export function validateInternationalRelease(snapshots: unknown) {
  if (!Array.isArray(snapshots) || snapshots.some(snapshot =>
    !snapshot || typeof snapshot.fetchedAt !== "string"
    || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z$/.test(snapshot.fetchedAt)
  )) return null;
  const release = { snapshots, refreshMode: "packaged-release-snapshot", staleAfterHours: 48 };
  const parsed = GetInternationalResponse.safeParse(release);
  if (!parsed.success) return null;
  if (parsed.data.snapshots.some(snapshot =>
    snapshot.rows.some(row => !Number.isFinite(row.value))
    || snapshot.requestUrls?.some(url => !url.startsWith("https://"))
  )) return null;
  const ids = parsed.data.snapshots.map(snapshot => snapshot.id);
  if (new Set(ids).size !== 10) return null;
  // Return the original strings and optional provenance exactly as published;
  // the generated validator coerces timestamps to Date objects for validation.
  return release;
}

const release = validateInternationalRelease(seed);

export function handleInternationalSnapshot(request: Request) {
  if (request.method !== "GET") {
    return Response.json(
      { code: "METHOD_NOT_ALLOWED" },
      { status: 405, headers: { Allow: "GET", "Cache-Control": "no-store" } },
    );
  }
  if (!release) {
    logger.error("The international employment release failed validation.");
    return Response.json(
      { code: "INVALID_RELEASE_DATA" },
      { status: 500, headers: { "Cache-Control": "no-store" } },
    );
  }
  return Response.json(release, {
    headers: {
      "Cache-Control": "public, max-age=120",
      "X-Data-Source": "release-snapshot",
    },
  });
}
