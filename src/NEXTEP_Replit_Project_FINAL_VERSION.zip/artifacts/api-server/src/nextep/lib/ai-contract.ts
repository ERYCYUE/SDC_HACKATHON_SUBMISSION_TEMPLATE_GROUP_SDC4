import {z} from 'zod';
const text=z.string().max(1200),label=z.string().max(240),url=z.string().url().max(1500).refine(v=>/^https?:\/\//.test(v));
const skill=z.object({id:label,name:label});
export const aiPayloadSchema=z.object({
 version:z.literal(1),mode:z.enum(['chat','analysis','pathway']),lang:z.enum(['zh','en']),question:z.string().max(4000),
 history:z.array(z.object({who:z.enum(['user','assistant']),text})).max(6).default([]),
 profile:z.object({kind:z.enum(['student','worker']),branch:label,region:label,skills:z.array(skill).max(100),hours:z.number().min(1).max(40),goal:label,confirmed:z.boolean()}),
 entry_gap:z.object({qualification:label,basis:z.enum(['current','graduation']),selectedRoute:label.optional(),enrollment:label.optional(),graduateInterest:label.optional(),experienceReview:z.array(z.object({kind:label,required:z.number(),preferred:z.number(),reported:z.boolean(),known:z.boolean(),gap:z.boolean()})).max(8).optional(),source:label,snapshot:label,total:z.number(),known:z.number(),unknown:z.number(),coverage:z.number().nullable(),masterCoverage:z.number().nullable(),upliftPoints:z.number().nullable(),studyPrompt:z.boolean(),experienceYears:z.number().nullable(),experienceCoverage:z.number().nullable(),englishNote:label,preferred:z.array(z.object({kind:label,quote:text,url})).max(6),routes:z.array(label).length(3)}).optional(),
 employment:z.object({source:label,snapshot:label,sample:z.number(),cityScope:label,monthlyN:z.number(),monthlyMidpointMedianK:z.number().nullable(),dailyN:z.number(),dailyMidpointMean:z.number().nullable(),currency:label,oneSnapshotOnly:z.literal(true),skillsMissing:z.boolean(),taskModelPending:z.boolean()}).optional(),
 bestPosting:z.object({id:label,title:label,company:label,city:label,salary:label,url,snapshot:label,fit:z.number(),catalogSkills:z.boolean(),projectedQualification:z.boolean(),checks:z.array(z.object({name:label,status:z.enum(['pass','gap','unknown']),detail:text})).max(8)}).optional(),
 scenario:z.object({name:label,year:z.number().min(2026).max(2030),asOf:label}),
 role:z.object({id:label,name:label,fit:z.number().min(0).max(100),outlook:z.number().min(0).max(100),matched:z.array(skill).max(100),missing:z.array(skill).max(100),tasks:z.array(z.object({name:label,effect:label})).max(20),synthetic:z.boolean()}),
 evidence:z.object({kind:z.enum(['synthetic','mixed','user']),confidence:label,jobs:z.array(z.object({title:label,url,published:label,synthetic:z.boolean()})).max(5),signals:z.array(z.object({date:label,url,synthetic:z.boolean(),demand:z.number().optional(),adoption:z.number().optional(),funding:z.number().optional(),policy:z.number().optional()})).max(5),research:z.array(z.object({tech:label,period:label,count:z.number().nonnegative(),fetched:label,url,synthetic:z.boolean()})).max(12)}),
 sdgs:z.array(z.object({goal:z.number().int().min(1).max(17),target:label,contribution:label,rationale:text,mitigation:text.optional(),definition:text,verified:z.boolean(),url:url.optional(),synthetic:z.boolean()})).max(16),
 pathway:z.object({hours:z.number().nonnegative(),weeks:z.number().nonnegative(),budget:label,preference:label,start:label,deadline:label,modules:z.array(z.object({title:label,hours:z.number(),start:z.number(),end:z.number(),acceptance:text,resources:z.array(z.object({title:label,url,status:label})).max(2)})).max(40)}).nullable()
});
export type AIPayload=z.infer<typeof aiPayloadSchema>;
export type AIMode=AIPayload['mode'];
export type AIStatus={configured:boolean;model:string|null;reason:'ready'|'disabled'|'missing_key'|'invalid_config'};
export const aiErrors={
 NOT_CONFIGURED:['DeepSeek 尚未启用或未配置密钥，可继续使用本地分析。','DeepSeek is not enabled or has no key. Local analysis remains available.'],
 INVALID_CONFIG:['服务端 DeepSeek 配置有误，请检查接口地址。','The server DeepSeek configuration is invalid. Check the endpoint.'],
 INVALID_PAYLOAD:['分析内容不符合接口要求，请刷新后重试。','The analysis payload is invalid. Refresh and try again.'],
 TOO_LARGE:['分析内容过长，请缩小导入数据或问题范围。','The analysis is too large. Reduce the question or dataset scope.'],
 ORIGIN_REJECTED:['请求来源不匹配，请在网站中重试。','Request origin mismatch. Retry from the website.'],
 RATE_LIMIT:['请求过于频繁，请稍后重试。','Too many requests. Please try again shortly.'],
 PROVIDER_AUTH:['DeepSeek 密钥无效或已失效，请由网站管理员更新。','The DeepSeek key is invalid or expired. Ask the site owner to update it.'],
 PROVIDER_BALANCE:['DeepSeek API 余额不足，请由网站管理员检查账户。','The DeepSeek API balance is insufficient. Ask the site owner to check the account.'],
 PROVIDER_BUSY:['DeepSeek 暂时繁忙，请稍后重试；本地结果仍可使用。','DeepSeek is temporarily busy. Retry later; local results remain available.'],
 TIMEOUT:['DeepSeek 响应超时，请重试或继续使用本地结果。','DeepSeek timed out. Retry or continue with the local results.'],
 INCOMPLETE:['回答达到长度上限，未作为完整分析展示。请缩小问题后重试。','The response reached its length limit and was not shown as a complete analysis. Narrow the question and retry.'],
 NETWORK:['连接失败，请检查网络后重试。','Connection failed. Check your network and retry.'],
 CANCELLED:['已停止本次请求，本地结果保留。','Request stopped. Local results are retained.']
} as const;
export type AIErrorCode=keyof typeof aiErrors;
