import seed from "../data/cn-employment.json" with { type: "json" };
import { validMarketBundle } from "./market.ts";

// This is the same released batch used to seed D1, not a synthetic fallback.
// Node deployments are stateless: publishing a new batch requires a rebuild.
export function handleMarketSnapshot(request: Request) {
  if (request.method !== "GET") {
    return Response.json(
      { code: "METHOD_NOT_ALLOWED" },
      { status: 405, headers: { Allow: "GET" } },
    );
  }
  if (!validMarketBundle(seed)) {
    console.error("The released recruitment snapshot failed validation.");
    return Response.json({ code: "INVALID_RELEASE_DATA" }, { status: 500 });
  }
  return Response.json(seed, {
    headers: {
      "Cache-Control": "public, max-age=120",
      "X-Data-Source": "release-snapshot",
      "X-Data-Batch": seed.meta.id,
    },
  });
}
