import { Router, type Request as ExpressRequest } from "express";
import { Readable } from "node:stream";
import { handleAI, type AIEnv } from "../nextep/lib/ai-server";
import { handleMarketSnapshot } from "../nextep/lib/market-snapshot";
import { handleInternationalSnapshot } from "../nextep/lib/international-snapshot";

// Preserve the original Web Request/Response handlers and their validation.
// The public proxy supplies the originating scheme and host.
function webRequest(req: ExpressRequest): Request {
  const proto = String(req.headers["x-forwarded-proto"] || req.protocol).split(",")[0].trim();
  const host = String(req.headers["x-forwarded-host"] || req.headers.host).split(",")[0].trim();
  const headers = new Headers();
  for (const [name, value] of Object.entries(req.headers)) {
    if (value !== undefined) headers.set(name, Array.isArray(value) ? value.join(", ") : value);
  }
  return new Request(`${proto}://${host}${req.originalUrl}`, {
    method: req.method,
    headers,
    ...(req.method !== "GET" && req.method !== "HEAD"
      ? { body: Readable.toWeb(req), duplex: "half" }
      : {}),
  } as RequestInit);
}

// Dependency injection is used only by the proxy integration test. The normal
// app constructs this router without overrides and retains server-only config.
export function createNextepRouter(ai?: {
  env: AIEnv;
  deps?: Parameters<typeof handleAI>[2];
}) {
const router = Router();
router.all(["/market", "/ai", "/international"], async (req, res, next) => {
  try {
    const request = webRequest(req);
    const response = req.path === "/market"
      ? handleMarketSnapshot(request)
      : req.path === "/international"
      ? handleInternationalSnapshot(request)
      : await handleAI(request, ai?.env ?? {
          AI_ENDPOINT: process.env.AI_ENDPOINT,
          AI_MODEL: process.env.AI_MODEL,
          AI_API_KEY: process.env.AI_API_KEY,
          ALLOW_EXTERNAL_AI: process.env.ALLOW_EXTERNAL_AI,
        }, ai?.deps);
    res.status(response.status);
    response.headers.forEach((value, name) => res.setHeader(name, value));
    res.send(Buffer.from(await response.arrayBuffer()));
  } catch (error) {
    next(error);
  }
});
return router;
}

export default createNextepRouter();
