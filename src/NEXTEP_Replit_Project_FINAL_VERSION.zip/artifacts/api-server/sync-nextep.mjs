import { mkdir, readFile, writeFile } from "node:fs/promises";

// This explicit build-time allowlist keeps the Node adapter aligned with the
// webpage without importing another artifact at runtime or copying Worker code.
const files = [
  "lib/ai-contract.ts",
  "lib/ai-server.ts",
  // Type-only dependencies used by the existing market adapter.
  "lib/career.ts",
  "lib/model/types.ts",
  "lib/model/entry-gaps.ts",
  "data/international-employment.json",
];

export async function syncNextep({ check = false } = {}) {
  for (const file of files) {
    const source = new URL(`../nextep/${file}`, import.meta.url);
    const target = new URL(`./src/nextep/${file}`, import.meta.url);
    const content = (await readFile(source, "utf8")).replace(/\r\n/g, "\n");
    if (check) {
      if (content !== await readFile(target, "utf8")) {
        throw new Error(`NEXTEP backend copy is stale: ${file}`);
      }
    } else {
      await mkdir(new URL(".", target), { recursive: true });
      await writeFile(target, content);
    }
  }
}
