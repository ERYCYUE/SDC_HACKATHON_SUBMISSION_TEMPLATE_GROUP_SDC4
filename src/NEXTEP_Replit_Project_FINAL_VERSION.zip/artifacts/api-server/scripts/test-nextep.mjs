import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { syncNextep } from "../sync-nextep.mjs";
import { aiPayloadSchema } from "../src/nextep/lib/ai-contract.ts";
import { handleAI } from "../src/nextep/lib/ai-server.ts";
import { handleInternationalSnapshot, validateInternationalRelease } from "../src/nextep/lib/international-snapshot.ts";
import { buildAIPayload } from "../../nextep/lib/ai-grounding.ts";
import { makeDefaultData, initialPerson } from "../../nextep/lib/model/catalog.ts";
import { defaultContext } from "../../nextep/lib/model/config.ts";
import { defaultPreferences, buildPathway } from "../../nextep/lib/model/pathways.ts";
import { mergeMarket } from "../../nextep/lib/market.ts";
import { publicFeeds } from "../../nextep/lib/international.ts";
import express from "express";
import { once } from "node:events";
import { createNextepRouter } from "../src/routes/nextep.ts";

// No environment credential reads and no real provider traffic in this suite.
await syncNextep({ check: true });
const json = async path => JSON.parse(await readFile(new URL(path, import.meta.url), "utf8"));
const snapshots = await json("../../nextep/data/international-employment.json");
const market = await json("../../nextep/data/cn-employment.json");
const data = mergeMarket(makeDefaultData(), market);
const person = {
  ...initialPerson, branch: "ic", goal: "ic-verification",
  skills: ["digital", "verilog", "verification", "python", "test"],
  education: "bachelor", plannedEducation: "master", educationBasis: "graduation",
  kind: "student", routePreference: "work-first", educationStage: "undergraduate",
  entryExperiences: ["research", "internship"], experiencesConfirmed: true,
  graduateInterest: "no", workYears: 0, confirmed: true, text: "PRIVATE RAW CV",
};
const context = { ...defaultContext, region: "CN" };
const path = buildPathway("ic-verification", person, context, data, defaultPreferences);
let checks = 0;
const pass = name => { checks++; console.log(`PASS ${name}`); };

assert(validateInternationalRelease(snapshots));
assert.deepEqual(new Set(snapshots.map(s => s.id)), new Set(publicFeeds.map(f => f.id)));
const response = handleInternationalSnapshot(new Request("https://example.test/api/international"));
assert.equal(response.status, 200);
assert.equal(response.headers.get("X-Data-Source"), "release-snapshot");
assert.deepEqual(await response.json(), {
  snapshots, refreshMode: "packaged-release-snapshot", staleAfterHours: 48,
});
pass("all ten official feeds preserve their exact capture dates, units and provenance");

for (const method of ["POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"]) {
  const denied = handleInternationalSnapshot(new Request("https://example.test/api/international", { method }));
  assert.equal(denied.status, 405);
  assert.equal(denied.headers.get("Allow"), "GET");
}
pass("international handler is GET-only");
for (const mutate of [
  x => x.pop(),
  x => { x[1] = structuredClone(x[0]); },
  x => { x[0].id = "unknown-source"; },
  x => { x[0].fetchedAt = "not-a-date"; },
  x => { x[0].fetchedAt = null; },
  x => { x[0].rows[0].value = Infinity; },
  x => { x[0].rows = []; },
  x => { x[0].sha256 = "invalid"; },
  x => { x[0].rawCount = 0; },
  x => { x[0].requestUrls = ["http://untrusted.test"]; },
]) {
  const bad = structuredClone(snapshots);
  mutate(bad);
  assert(validateInternationalRelease(bad) === null, "Invalid release must be rejected");
}
pass("malformed, missing and duplicate snapshots fail closed");

const testEnv = { ALLOW_EXTERNAL_AI: "true", AI_API_KEY: "test-placeholder-not-a-real-key" };
const request = body => new Request("https://example.test/api/ai", {
  method: "POST", headers: { Origin: "https://example.test", "Content-Type": "application/json" },
  body: JSON.stringify(body),
});
let providerCalls = 0;
const payloads = [];
for (const mode of ["chat", "analysis", "pathway"]) for (const lang of ["zh", "en"]) {
  const payload = buildAIPayload(mode, "Explain the evidence", person, context, data, defaultPreferences,
    "ic-verification", mode === "pathway" ? path : null, lang);
  payloads.push(payload);
  assert(payload.bestPosting?.company);
  assert(payload.bestPosting.checks.length);
  assert.deepEqual(aiPayloadSchema.parse(payload), payload);
  let sent;
  const result = await handleAI(request({ ...payload, rawCV: person.text }), testEnv, {
    allow: () => true,
    fetch: async (_url, init) => {
      providerCalls++;
      sent = JSON.parse(init.body);
      return Response.json({ choices: [{ finish_reason: "stop", message: { content: "Mock grounded advice." } }] });
    },
  });
  assert.equal(result.status, 200);
  const grounded = JSON.parse(sent.messages[1].content);
  assert.deepEqual(grounded, JSON.parse(JSON.stringify(payload)));
  assert(!JSON.stringify(sent).includes(person.text));
  assert.match(sent.messages[0].content, /When bestPosting is provided/);
  assert.match(sent.messages[0].content, /not a globally best job/);
}
assert.equal(providerCalls, 6);
pass("webpage-built Chinese/English chat, analysis and pathway payloads retain profile and top-posting evidence");

const noProvider = { allow: () => true, fetch: async () => { throw new Error("Unexpected provider call"); } };
for (const body of [
  { ...payloads[0], bestPosting: { ...payloads[0].bestPosting, checks: [{ name: "test", status: "invalid", detail: "" }] } },
  { ...payloads[0], bestPosting: { ...payloads[0].bestPosting, url: "javascript:alert(1)" } },
]) assert.equal((await handleAI(request(body), testEnv, noProvider)).status, 400);
assert.equal((await handleAI(request(payloads[0]), {}, noProvider)).status, 503);
const foreign = request(payloads[0]);
foreign.headers.set("Origin", "https://foreign.test");
assert.equal((await handleAI(foreign, testEnv, noProvider)).status, 403);
pass("invalid evidence, disabled AI and foreign origins never reach the provider");

// This optional pass targets the real shared proxy, never a standalone port.
// Valid payloads use a deliberately foreign origin, so even a configured server
// rejects them BEFORE reading configuration or making an external AI request.
if (process.argv.includes("--proxy")) {
  const base = "http://localhost:80";
  const live = await fetch(`${base}/api/international`);
  assert.equal(live.status, 200);
  assert.equal(live.headers.get("X-Data-Source"), "release-snapshot");
  assert.deepEqual(await live.json(), { snapshots, refreshMode: "packaged-release-snapshot", staleAfterHours: 48 });
  for (const method of ["POST", "PUT", "PATCH", "DELETE"]) {
    const denied = await fetch(`${base}/api/international?import=untrusted`, {
      method, headers: { "Content-Type": "application/json" }, body: '{"snapshots":[]}',
    });
    assert.equal(denied.status, 405);
    assert.equal(denied.headers.get("Allow"), "GET");
    assert.deepEqual(await denied.json(), { code: "METHOD_NOT_ALLOWED" });
  }
  assert.deepEqual((await (await fetch(`${base}/api/international`)).json()).snapshots, snapshots);
  for (const body of payloads) {
    const denied = await fetch(`${base}/api/ai`, {
      method: "POST",
      headers: { Origin: "https://foreign.test", "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    assert.equal(denied.status, 403);
    assert.deepEqual(await denied.json(), { code: "ORIGIN_REJECTED" });
  }
  const status = await fetch(`${base}/api/ai`);
  assert.equal(status.status, 200);
  const info = await status.json();
  assert.deepEqual(Object.keys(info).sort(), ["configured", "model", "reason"]);
  const oldMarket = await fetch(`${base}/api/market`);
  assert.equal(oldMarket.status, 200);
  assert.deepEqual(await oldMarket.json(), market);
  pass("shared proxy serves exact snapshots, rejects writes and safely routes all six AI payload shapes");
}
// Run only while the managed API service is stopped. Bind its EXISTING routed
// port temporarily, so the actual shared proxy exercises the same Express/Web
// Request adapter with a mock provider, without any production test switch.
const mockPortArg = process.argv.find(arg => arg.startsWith("--mock-proxy-port="));
if (mockPortArg) {
  const port = Number(mockPortArg.split("=")[1]);
  assert(Number.isInteger(port) && port > 0 && port <= 65535);
  const forwarded = [];
  const app = express();
  app.use("/api", createNextepRouter({
    env: testEnv,
    deps: {
      allow: () => true,
      fetch: async (_url, init) => {
        forwarded.push(JSON.parse(init.body));
        return Response.json({ choices: [{ finish_reason: "stop", message: { content: "Mock proxy advice." } }] });
      },
    },
  }));
  const server = app.listen(port, "0.0.0.0");
  try {
    await once(server, "listening");
    const base = "http://localhost:80";
    for (const body of payloads) {
      const accepted = await fetch(`${base}/api/ai`, {
        method: "POST", headers: { Origin: new URL(base).origin, "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      assert.equal(accepted.status, 200);
      assert.equal((await accepted.json()).text, "Mock proxy advice.");
      assert.deepEqual(JSON.parse(forwarded.at(-1).messages[1].content), JSON.parse(JSON.stringify(body)));
    }
    assert.equal(forwarded.length, 6);
    for (const bestPosting of [
      { ...payloads[0].bestPosting, url: "javascript:alert(1)" },
      { ...payloads[0].bestPosting, checks: [{ name: "test", status: "invalid", detail: "" }] },
    ]) {
      const rejected = await fetch(`${base}/api/ai`, {
        method: "POST", headers: { Origin: new URL(base).origin, "Content-Type": "application/json" },
        body: JSON.stringify({ ...payloads[0], bestPosting }),
      });
      assert.equal(rejected.status, 400);
      assert.deepEqual(await rejected.json(), { code: "INVALID_PAYLOAD" });
    }
    assert.equal(forwarded.length, 6);
    pass("shared proxy accepts all six current AI payloads and rejects malformed posting evidence with a mocked provider");
  } finally {
    server.closeAllConnections();
    await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
  }
}
console.log(`${checks} NEXTEP backend checks passed (provider calls mocked).`);
