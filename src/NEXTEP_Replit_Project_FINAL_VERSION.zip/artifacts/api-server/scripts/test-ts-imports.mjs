import { registerHooks } from "node:module";

// Match bundler resolution for the generated workspace TypeScript barrels.
// Test-only: production continues to use the unchanged esbuild/Node command.
registerHooks({
  resolve(specifier, context, nextResolve) {
    try {
      return nextResolve(specifier, context);
    } catch (error) {
      if (!specifier.startsWith(".")) throw error;
      if (error.code === "ERR_UNSUPPORTED_DIR_IMPORT") {
        return nextResolve(`${specifier}/index.ts`, context);
      }
      if (error.code !== "ERR_MODULE_NOT_FOUND") throw error;
      return nextResolve(`${specifier}.ts`, context);
    }
  },
});
