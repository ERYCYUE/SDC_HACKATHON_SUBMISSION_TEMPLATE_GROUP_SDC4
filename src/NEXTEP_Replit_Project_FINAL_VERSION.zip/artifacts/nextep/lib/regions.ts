// EU is the app's Europe group, not a claim that these countries are all EU members
// or that official data covers the whole region.
export const regionOptions: Record<string, [string, string]> = {
  CN: ['中国', 'China'],
  SG: ['新加坡', 'Singapore'],
  MY: ['马来西亚', 'Malaysia'],
  US: ['美国', 'United States'],
  EU: ['欧洲', 'Europe'],
};

export const europeanCountries: Record<string, [string, string]> = {
  DE: ['德国', 'Germany'], FR: ['法国', 'France'], NL: ['荷兰', 'Netherlands'],
  AT: ['奥地利', 'Austria'], BE: ['比利时', 'Belgium'], BG: ['保加利亚', 'Bulgaria'],
  HR: ['克罗地亚', 'Croatia'], CY: ['塞浦路斯', 'Cyprus'], CZ: ['捷克', 'Czechia'],
  DK: ['丹麦', 'Denmark'], EE: ['爱沙尼亚', 'Estonia'], FI: ['芬兰', 'Finland'],
  GR: ['希腊', 'Greece'], HU: ['匈牙利', 'Hungary'], IE: ['爱尔兰', 'Ireland'],
  IT: ['意大利', 'Italy'], LV: ['拉脱维亚', 'Latvia'], LT: ['立陶宛', 'Lithuania'],
  LU: ['卢森堡', 'Luxembourg'], MT: ['马耳他', 'Malta'], PL: ['波兰', 'Poland'],
  PT: ['葡萄牙', 'Portugal'], RO: ['罗马尼亚', 'Romania'], SK: ['斯洛伐克', 'Slovakia'],
  SI: ['斯洛文尼亚', 'Slovenia'], ES: ['西班牙', 'Spain'], SE: ['瑞典', 'Sweden'],
  GB: ['英国', 'United Kingdom'], CH: ['瑞士', 'Switzerland'], NO: ['挪威', 'Norway'],
  IS: ['冰岛', 'Iceland'], LI: ['列支敦士登', 'Liechtenstein'], AL: ['阿尔巴尼亚', 'Albania'],
  AD: ['安道尔', 'Andorra'], BA: ['波黑', 'Bosnia and Herzegovina'],
  BY: ['白俄罗斯', 'Belarus'], MD: ['摩尔多瓦', 'Moldova'], MC: ['摩纳哥', 'Monaco'],
  ME: ['黑山', 'Montenegro'], MK: ['北马其顿', 'North Macedonia'],
  SM: ['圣马力诺', 'San Marino'], RS: ['塞尔维亚', 'Serbia'],
  UA: ['乌克兰', 'Ukraine'], VA: ['梵蒂冈', 'Vatican City'],
};

export function marketRegion(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const code = value.trim().toUpperCase();
  if (Object.hasOwn(regionOptions, code)) return code;
  return Object.hasOwn(europeanCountries, code) || code === 'UK' ? 'EU' : undefined;
}

export const isSupportedRegion = (value: unknown) => marketRegion(value) !== undefined;

export function matchesRegion(record: string, target: string) {
  const recordGroup = marketRegion(record);
  return !!recordGroup && recordGroup === marketRegion(target);
}

export function sourceRegionName(code: string): [string, string] {
  return regionOptions[code] || europeanCountries[code] ||
    (code === 'UK' ? europeanCountries.GB : [code, code]);
}

export function mentionedRegion(text: string): string | undefined {
  if (/新加坡|singapore|\bSG\b/i.test(text)) return 'SG';
  if (/马来|malaysia|\bMY\b/i.test(text)) return 'MY';
  if (/美国|united states|\bUSA?\b/i.test(text)) return 'US';
  if (/欧洲|europe|\bEU\b/i.test(text)) return 'EU';
  if (Object.entries(europeanCountries).some(([code, name]) =>
    name.some(n => new RegExp(n, 'i').test(text)) ||
    text.trim().toUpperCase() === code ||
    new RegExp(`(?:country|region|location|国家|地区|地点)\\s*[:：]\\s*${code}\\b`, 'i').test(text),
  ) || /英国|\bUK\b|britain/i.test(text)) return 'EU';
  if (/中国|回国|china|\bCN\b/i.test(text)) return 'CN';
  return undefined;
}
