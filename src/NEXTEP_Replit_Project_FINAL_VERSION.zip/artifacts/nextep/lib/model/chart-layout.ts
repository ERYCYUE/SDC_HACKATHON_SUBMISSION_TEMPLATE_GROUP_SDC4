export type ScatterInput={id:string;x:number;y:number;radius:number};
export type ScatterPoint=ScatterInput&{rawX:number;rawY:number};
export type ScatterBounds={left:number;right:number;top:number;bottom:number};

/**
 * Separates close markers for display while retaining their exact score as a
 * connector endpoint. The offset is visual only; callers should expose rawX/rawY.
 */
export function spreadOverlappingPoints(
  points:ScatterInput[],
  bounds:ScatterBounds,
  gap=5,
):ScatterPoint[]{
 const placed:ScatterPoint[]=[];
 const goldenAngle=Math.PI*(3-Math.sqrt(5));
 for(const [index,point] of points.entries()){
  const minX=bounds.left+point.radius,minY=bounds.top+point.radius;
  const maxX=bounds.right-point.radius,maxY=bounds.bottom-point.radius;
  let result:{x:number;y:number}|undefined;
  for(let attempt=0;attempt<2400;attempt++){
   const distance=attempt===0?0:8+Math.sqrt(attempt)*4;
   const angle=index*.37+attempt*goldenAngle;
   const x=point.x+Math.cos(angle)*distance,y=point.y+Math.sin(angle)*distance;
   if(x<minX||x>maxX||y<minY||y>maxY)continue;
   const clear=placed.every(other=>Math.hypot(x-other.x,y-other.y)>=point.radius+other.radius+gap);
   if(clear){result={x,y};break;}
  }
  // The plot has ample room for the current role set; retain the exact point
  // if an unusually dense future set cannot be separated within the search.
  result??={x:Math.max(minX,Math.min(maxX,point.x)),y:Math.max(minY,Math.min(maxY,point.y))};
  placed.push({...point,...result,rawX:point.x,rawY:point.y});
 }
 return placed;
}
