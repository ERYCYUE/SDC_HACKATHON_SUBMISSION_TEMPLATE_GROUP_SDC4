import type {CareerData,Person} from './types.ts';
import {matchesRegion,marketRegion} from '../regions.ts';
export const educationLevels=['secondary','associate','bachelor','master','doctor'] as const;
export type Education=typeof educationLevels[number]|'unknown';
export type EducationRequirement=Education|'none';
export const educationNames:Record<EducationRequirement,[string,string]>={unknown:['未提供 / 待核对','Not provided / review needed'],none:['不限学历','No degree requirement'],secondary:['高中 / 中专及以下','Secondary school or below'],associate:['大专','Associate / diploma'],bachelor:['本科','Bachelor'],master:['硕士','Master'],doctor:['博士','Doctorate']};
export const experienceNames={research:['科研 / 论文','Research / publications'],internship:['实习','Internships'],competition:['竞赛 / 项目展示','Competitions / project showcases'],networking:['行业交流 / 导师沟通','Industry / mentor conversations']} as const;
export type ExperienceKind=keyof typeof experienceNames;
export type EntryJob=CareerData['jobs'][number];
export const ENTRY_RULE={coverageBelow:50,upliftAtLeast:30,minKnownSample:30};
const rank=(v:EducationRequirement)=>v==='none'?-1:educationLevels.indexOf(v as typeof educationLevels[number]);
export function educationPass(level:Education,requirement:EducationRequirement){return level==='unknown'||requirement==='unknown'?null:requirement==='none'||rank(level)>=rank(requirement);}
export function canonicalJobURL(url:string){try{const u=new URL(url);u.hash='';for(const k of [...u.searchParams.keys()])if(/^(utm_|spm|from|track|session)/i.test(k))u.searchParams.delete(k);u.searchParams.sort();return u.href;}catch{return url;}}
export function isObservedJob(j:EntryJob){return j.synthetic===false&&!/(^|\.)(example\.(com|org|net)|localhost)$/i.test(new URL(j.source_url).hostname);}
export function preferredExperiences(j:EntryJob):{kind:ExperienceKind;quote:string}[]{
 const out=(j.preferred_experiences||[]).map(kind=>({kind,quote:j.requirement_excerpt||''}));
 for(const sentence of (j.description||'').split(/[。\n;；]/)){if(!/优先|加分|preferred|a plus|advantage/i.test(sentence)||/无需|不要求|不需|no.{0,8}(required|necessary)|not required/i.test(sentence))continue;for(const [kind,re] of Object.entries({research:/科研|论文|research|publications?/i,internship:/实习|internship/i,competition:/竞赛|competition|hackathon/i})){if(re.test(sentence)&&!out.some(r=>r.kind===kind))out.push({kind:kind as ExperienceKind,quote:sentence.slice(0,600)});}}
 return out;
}
export function entryCohort(d:CareerData,roleId:string,region:string,source='boss'){
 const raw=d.jobs.filter(j=>j.role_id===roleId&&matchesRegion(j.region,region)&&isObservedJob(j)&&(source==='all'||j.source_platform===source));
 const batches=[...new Set(raw.map(j=>j.snapshot_date).filter(Boolean))].sort() as string[],latest=batches.at(-1)||'';
 const countryLatest=new Map([...new Set(raw.map(j=>j.region))].map(code=>[code,raw.filter(j=>j.region===code).map(j=>j.snapshot_date||'').sort().at(-1)||'']));
 const chosen=raw.filter(j=>marketRegion(region)==='EU'?(j.snapshot_date||'')===countryLatest.get(j.region):latest?j.snapshot_date===latest:!j.snapshot_date),seen=new Set<string>();
 const jobs=chosen.filter(j=>{const key=canonicalJobURL(j.source_url);if(seen.has(key))return false;seen.add(key);return true;});
 const countrySnapshots=[...countryLatest].map(([country,date])=>({country,date,count:jobs.filter(j=>j.region===country).length})).filter(x=>x.count>0);
 return{raw:raw.length,jobs,latest,duplicates:chosen.length-jobs.length,excluded:raw.length-chosen.length,batches,countrySnapshots};
}
export function entryStatistics(d:CareerData,roleId:string,region:string,degree:Education,years:number|null,source='boss'){
 const cohort=entryCohort(d,roleId,region,source),jobs=cohort.jobs,known=jobs.filter(j=>j.education_min&&j.education_min!=='unknown'),n=known.length;
 const coverage=(level:Education)=>level==='unknown'||!n?null:known.filter(j=>educationPass(level,j.education_min!)).length/n*100;
 const current=coverage(degree),master=degree==='doctor'?null:coverage('master'),uplift=current===null||master===null?null:master-current;
 const meetsRule=current!==null&&uplift!==null&&current<ENTRY_RULE.coverageBelow&&uplift>=ENTRY_RULE.upliftAtLeast&&degree!=='master'&&degree!=='doctor';
 const counts=Object.keys(educationNames).map(level=>({level:level as EducationRequirement,count:jobs.filter(j=>(j.education_min||'unknown')===level).length}));
 const expKnown=jobs.filter(j=>j.experience_min_years!==undefined),expCovered=years===null||!expKnown.length?null:expKnown.filter(j=>j.experience_min_years!<=years).length/expKnown.length*100;
 const preferences=jobs.flatMap(j=>preferredExperiences(j).map(x=>({...x,job:j})));
 return{...cohort,n,unknown:jobs.length-n,counts,current,master,uplift,meetsRule,suggestStudy:meetsRule&&n>=ENTRY_RULE.minKnownSample,masterRequired:known.filter(j=>rank(j.education_min!)>=rank('master')).length,expKnown:expKnown.length,expCovered,english:jobs.filter(j=>j.english_requirement?.trim()),preferences,coverage};
}
export function educationTrend(d:CareerData,roleId:string,region:string,source='boss'){
 const jobs=d.jobs.filter(j=>j.role_id===roleId&&matchesRegion(j.region,region)&&isObservedJob(j)&&(source==='all'||j.source_platform===source)&&j.snapshot_date);
 const rows=[...new Set(jobs.map(j=>j.snapshot_date!))].sort().map(date=>{const x=entryStatistics({...d,jobs:jobs.filter(j=>j.snapshot_date===date)},roleId,region,'bachelor',null,source);return{date,n:x.n,total:x.jobs.length,masterShare:x.n?x.masterRequired/x.n*100:null,countries:x.countrySnapshots.map(c=>c.country).sort().join(',')};});
 // A changing country mix is not a comparable Europe-wide time series.
 return marketRegion(region)==='EU'?rows.map(r=>({...r,masterShare:r.countries===rows.at(-1)?.countries?r.masterShare:null})):rows;
}
export function adjacentEntryRoles(d:CareerData,p:Person,roleId:string,region:string,degree:Education,source='boss'){
 const role=d.roles.find(r=>r.id===roleId)!;return d.roles.filter(r=>r.id!==roleId&&(r.branch===role.branch||r.skills.some(s=>role.skills.includes(s)))).map(r=>({role:r,overlap:r.skills.filter(s=>p.skills.includes(s)).length,stats:entryStatistics(d,r.id,region,degree,p.workYears??null,source)})).sort((a,b)=>(b.stats.current??-1)-(a.stats.current??-1)||b.overlap-a.overlap||a.role.id.localeCompare(b.role.id)).slice(0,3);
}
export const researchDirections:Record<string,[string,string]>={ic:['数字芯片验证、形式化验证、EDA 与低功耗设计','Digital verification, formal methods, EDA and low-power design'],embedded:['嵌入式系统、端侧 AI 与物联网可靠性','Embedded systems, edge AI and IoT reliability'],communication:['无线通信、射频系统与智能网络','Wireless communications, RF systems and intelligent networks'],signal:['信号处理、多模态感知与低功耗推理','Signal processing, multimodal sensing and low-power inference'],control:['机器人控制、嵌入式智能与安全验证','Robot control, embedded intelligence and safety validation'],hardware:['电力电子、储能控制与硬件可靠性','Power electronics, storage control and hardware reliability'],optics:['光电器件、硅光子与光通信系统','Optoelectronics, silicon photonics and optical communications']};
export const milestones:{id:string;year:number;kind:ExperienceKind;title:[string,string];detail:[string,string]}[]=[
 {id:'y1-project',year:1,kind:'competition',title:['大一：完成可复现的小项目','Year 1: build a reproducible small project'],detail:['保存代码、测试和复盘；可选择低成本校内展示，不要求获奖。','Keep code, tests and a reflection. An affordable campus showcase is optional; an award is not required.']},
 {id:'y1-mentor',year:1,kind:'networking',title:['大一：与教师或学长交流方向','Year 1: discuss directions with teachers or peers'],detail:['了解实验室与行业任务，不将付费社交或人脉数量作为门槛。','Learn about lab and industry tasks. Paid networking or contact counts are not requirements.']},
 {id:'y2-lab',year:2,kind:'research',title:['大二：尝试实验室或开放科研项目','Year 2: try a lab or open research project'],detail:['先做文献复现、测试或数据整理；论文发表不是默认目标。','Start with replication, testing or data work. Publication is not assumed to be necessary.']},
 {id:'y2-showcase',year:2,kind:'competition',title:['大二：整理项目或竞赛作品集','Year 2: curate project or competition evidence'],detail:['展示本人贡献、工程取舍与复现材料；竞赛自愿参加。','Show your own contribution, trade-offs and reproducible materials. Competitions are optional.']},
 {id:'y3-summer',year:3,kind:'internship',title:['大三暑期：科研或实习二选一','Year 3 summer: choose research or an internship'],detail:['结合时间和经济条件选择，记录任务与成果，不要求两者兼得。','Choose according to time and finances. Record tasks and outputs; doing both is not required.']},
 {id:'y3-research',year:3,kind:'research',title:['大三：形成研究问题与复现报告','Year 3: develop a question and replication report'],detail:['比较目标方向与导师项目；申请资格、英语和日期需查学校当年公告。','Compare research directions and supervisor projects. Verify current eligibility, English and dates with each institution.']},
 {id:'y4-apply',year:4,kind:'research',title:['大四：按目标项目准备申请','Year 4: prepare applications for chosen programs'],detail:['整理成绩、项目说明和推荐材料；国内考试、推免及海外申请按各自官方安排核对。','Organize transcripts, project evidence and references. Check the relevant official timelines for each admission route.']},
 {id:'y4-employment',year:4,kind:'internship',title:['大四：同步准备就业与毕业项目','Year 4: retain employment and capstone options'],detail:['升学与就业可并行准备，避免把读研设为唯一出路。','You may prepare study and work options in parallel; graduate study is not the only route.']}
];
