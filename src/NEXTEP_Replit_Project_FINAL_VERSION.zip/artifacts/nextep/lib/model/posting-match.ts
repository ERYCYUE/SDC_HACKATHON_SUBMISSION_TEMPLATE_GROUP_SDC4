import type {CareerData,Person,Context,Bi} from './types.ts';
import {educationPass,isObservedJob,canonicalJobURL} from './entry-gaps.ts';
import {resolveGoal} from './profile.ts';
import {matchesRegion} from '../regions.ts';
type Check={name:Bi;status:'pass'|'gap'|'unknown';detail:Bi};
// Search-result categories in the workbook are noisy. A concrete recommendation
// requires a title anchor for that category; keep excluded rows in the source DB.
const titleRules:Record<string,RegExp>={
 driver:/linux|android|bsp|内核|固件|嵌入式|设备驱动|底层|\bdriver\b|firmware|rtos|驱动开发|驱动软件/i,
 'ic-verification':/验证|verification|\buvm\b|\bdv\b/i,
 'ic-design':/芯片|集成电路|\bic\b|rtl|数字前端|soc|asic|cpu|微电子/i,
 'analog-ic':/模拟|analog|mixed.?signal|数模混合|电源芯片/i,
 'ic-layout':/版图|layout|物理设计|后端设计/i,
 fpga:/fpga|可编程逻辑/i,fae:/fae|现场应用|应用工程|技术支持|售前|field application/i,
 embedded:/嵌入式|embedded|单片机|mcu|\barm\b|固件|bsp|rtos|物联网|linux/i,
 iot:/物联|iot|传感|智能硬件|sensor|智能家居/i,
 network:/通信|通讯|网络|交换|无线|5g|6g|network|telecom/i,
 'comm-algorithm':/通信|通讯|无线|基带|信号|调制|communication|modem|5g|6g|wifi/i,
 'chip-test':/芯片|半导体|\bic\b|ate|封装|晶圆/i,
 rf:/射频|天线|\brf\b|微波|雷达/i,emc:/emc|emi|电磁|安规/i,
 hardware:/硬件|电路|hardware|电子|板级/i,'hardware-test':/硬件|电子|电路|可靠性|测试|hardware/i,
 'pcb-design':/pcb|电路板|layout|绘板|硬件/i,
 automotive:/汽车|车载|车辆|智能驾|新能源|电控|电驱|automotive|adas/i,
 electrical:/电气|电力|配电|电控|高低压|electrical/i,
 plc:/plc|自动化|电气|控制/i,power:/电力|电源|电能|储能|电池|电机|充电|power|逆变|变流/i,
 photonics:/光|photon|laser|opto/i,signal:/信号|dsp|音频|图像|雷达|算法|signal|audio/i,
 algorithm:/算法|algorithm|机器学习|深度学习|\bai\b|人工智能|machine learning|数据科学|计算机视觉/i,
 software:/软件|开发|program|software|java|c\+\+|python|后端|前端|全栈|研发|测试|算法/i,
};
export function postingTitleFitsRole(job:CareerData['jobs'][number]){
 return !titleRules[job.role_id]||titleRules[job.role_id].test(job.title);
}
/** Actual observed advertisements only. Unknown requirements never count as passed. */
export function rankObservedPostings(p:Person,c:Context,d:CareerData){
 const goal=resolveGoal(p.goal,d),projected=p.kind==='student'&&p.educationBasis==='graduation';
 const records=new Map(d.market?.postings.map(j=>[j.id,j])||[]);
 const degree=(projected?p.plannedEducation:p.education)||'unknown',seen=new Set<string>();
  const candidates=[...d.jobs].sort((a,b)=>(b.snapshot_date||b.published_at||'').localeCompare(a.snapshot_date||a.published_at||'')).filter(j=>{try{if(!matchesRegion(j.region,c.region)||!isObservedJob(j)||!/^https?:/.test(j.source_url))return false;const key=canonicalJobURL(j.source_url);if(seen.has(key))return false;seen.add(key);return true;}catch{return false;}});
 return candidates.flatMap(job=>{const role=d.roles.find(r=>r.id===job.role_id);if(!role||!postingTitleFitsRole(job))return [];
  const catalog=!job.skills.length,requirements=catalog?role.skills:job.skills;
  const matched=requirements.filter(id=>p.skills.includes(id)),missing=requirements.filter(id=>!p.skills.includes(id));
  const skill=matched.length/Math.max(1,requirements.length)*100,branch=role.branch===p.branch,goalMatch=role.id===goal;
  // Do not recommend an unrelated advertisement simply because it has a lower degree requirement.
  if(!branch&&!goalMatch&&!matched.length)return [];
  const edu=educationPass(degree,job.education_min||'unknown');
  const years=typeof p.workYears==='number'?p.workYears:null,min=job.experience_min_years;
  const exp=min===undefined||years===null?null:years>=min;
  const campus=/在校|应届|intern|graduate/i.test(job.experience_raw||'');
  const checks:Check[]=[
   {name:['学历条件','Education'],status:edu===null?'unknown':edu?'pass':'gap',detail:edu===null?['用户或岗位学历信息未提供，需核对。','The user or posting qualification is unknown; confirm it.']:edu?['所选学历达到样本中的最低学历。','The selected qualification meets the recorded minimum.']:['所选学历低于样本要求，可比较相邻岗位与提升路线。','The selected qualification is below the recorded minimum; compare adjacent roles and development routes.']},
   {name:['工作经验','Work experience'],status:exp===null?'unknown':exp?'pass':'gap',detail:exp===null?['经验年数或明确最低年限未知；“经验不限”不等于确认零经验可入职。','Years or the explicit minimum are unknown. Unrestricted experience does not certify entry without experience.']:exp?['自报全职年数达到记录中的最低年限。','Self-reported full-time years meet the recorded minimum.']:[`记录至少要求 ${min} 年，自报 ${years} 年。`,`The recorded minimum is ${min} years; you reported ${years}.`]},
  ];
  if(campus)checks.push({name:['在校 / 应届身份','Student / graduate eligibility'],status:'unknown',detail:['需向企业核对毕业年份、在校身份与招聘批次。','Confirm graduation year, student status and recruitment cohort with the employer.']});
  const record=records.get(job.job_id);
  if(record?.schoolRequired)checks.push({name:['院校条件','Institution requirement'],status:'unknown',detail:[record.schoolRequired,record.schoolRequired]});
  if(job.english_requirement)checks.push({name:['英语条件','English requirement'],status:'unknown',detail:[job.english_requirement,job.english_requirement]});
  const gaps=checks.filter(x=>x.status==='gap').length,unknowns=checks.filter(x=>x.status==='unknown').length;
  const parts={skills:skill*(goal ? 0.45 : 0.7),specialization:branch?10:0,education:edu===true?10:0,experience:exp===true?10:0,goal:goalMatch?25:0};
  const score=Object.values(parts).reduce((s,x)=>s+x,0);
  const studentEntryPreference=p.kind==='student'?(campus?0:min===0?1:2):0;
  return [{job,role,record,checks,matched,missing,catalog,score,parts,gaps,unknowns,projected,degree,goalMatch,branch,studentEntryPreference}];
 }).sort((a,b)=>a.gaps-b.gaps||b.score-a.score||a.studentEntryPreference-b.studentEntryPreference||a.unknowns-b.unknowns||(b.job.snapshot_date||b.job.published_at||'').localeCompare(a.job.snapshot_date||a.job.published_at||'')||a.job.job_id.localeCompare(b.job.job_id));
}
