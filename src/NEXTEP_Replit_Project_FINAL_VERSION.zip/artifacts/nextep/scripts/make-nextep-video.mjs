import sharp from "sharp";
import { mkdir, writeFile } from "node:fs/promises";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import path from "node:path";

// Composite the generated footage and narration into a branded, reproducible
// deliverable. All large intermediates live in the ignored outputs directory.
const run = promisify(execFile);
const work = path.resolve("outputs/nextep-video-work");
const target = path.resolve("outputs/NEXTEP_Animated_Explainer_EN_1080p.mp4");
const W = 1920, H = 1080, FPS = 24;
const lengths = [8, 8, 8, 8, 8, 4];
const narration = [
  "For electrical and electronic engineering students, AI is changing careers. What should you learn next?",
  "NEXTEP tracks AI developments to explore which EEE skills and roles may rise or decline.",
  "Match your strengths and interests with future-focused EEE paths, from embedded AI to smart grids.",
  "Build a personalised learning plan: strengthen foundations, learn new tools, and practise through hands-on projects.",
  "Explore links to all seventeen UN Sustainable Development Goals. Different roles contribute in different ways.",
  "NEXTEP. Engineer your future.",
];
const sections = ["THE NEXT QUESTION", "TRACK & ANTICIPATE", "MATCH & EXPLORE", "PLAN & LEARN", "CONNECT TO PURPOSE", "YOUR NEXT STEP"];
const goals = [
  ["No poverty", "#E5243B"], ["Zero hunger", "#DDA63A"],
  ["Good health and well-being", "#4C9F38"], ["Quality education", "#C5192D"],
  ["Gender equality", "#FF3A21"], ["Clean water and sanitation", "#26BDE2"],
  ["Affordable and clean energy", "#FCC30B"], ["Decent work and economic growth", "#A21942"],
  ["Industry, innovation and infrastructure", "#FD6925"], ["Reduced inequalities", "#DD1367"],
  ["Sustainable cities and communities", "#FD9D24"], ["Responsible consumption and production", "#BF8B2E"],
  ["Climate action", "#3F7E44"], ["Life below water", "#0A97D9"],
  ["Life on land", "#56C02B"], ["Peace, justice and strong institutions", "#00689D"],
  ["Partnerships for the goals", "#19486A"],
];
const esc = s => String(s).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
const text = (x, y, s, size = 26, color = "#F6F7FE", extra = "") =>
  `<text x="${x}" y="${y}" font-size="${size}" fill="${color}" ${extra}>${esc(s)}</text>`;
const rect = (x, y, w, h, fill, extra = "") =>
  `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="16" fill="${fill}" ${extra}/>`;
function wrap(str, max) {
  const lines = [];
  let line = "";
  for (const word of str.split(" ")) {
    if ((line + " " + word).trim().length > max && line) { lines.push(line); line = word; }
    else line = (line + " " + word).trim();
  }
  if (line) lines.push(line);
  return lines;
}
function chip(x, y, scale = 1) {
  return `<g transform="translate(${x},${y}) scale(${scale})" fill="none" stroke="#B5A7FF" stroke-width="1.55" stroke-linecap="round">
    <rect x="4" y="4" width="16" height="16" rx="3"/><rect x="8" y="8" width="8" height="8" rx="1.5"/>
    <path d="M9 1v3m6-3v3M9 20v3m6-3v3M1 9h3m-3 6h3M20 9h3m-3 6h3"/>
  </g>`;
}
const svg = content => `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><g font-family="DejaVu Sans, sans-serif">${content}</g></svg>`;
async function png(name, content) {
  await sharp(Buffer.from(svg(content))).png().toFile(path.join(work, name));
}
async function ff(args) {
  try { await run("ffmpeg", ["-hide_banner", "-loglevel", "warning", "-y", ...args], { maxBuffer: 16 * 1024 * 1024 }); }
  catch (error) { throw new Error(`FFmpeg failed:\n${error.stderr || error.message}`); }
}
async function duration(file) {
  const { stdout } = await run("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", file]);
  return Number(stdout.trim());
}
function heading(lines, y = 352) {
  return lines.map((line, i) => text(96, y + 94 * i, line, 78, "#F7F8FF", 'font-weight="700" letter-spacing="-1.8"')).join("");
}
function pill(x, y, label, color = "#9DEDF3", width = 250) {
  return rect(x, y, width, 54, "#102039", `stroke="${color}" stroke-opacity=".32"`) +
    text(x + 20, y + 35, label, 20, color);
}
function header(i) {
  let content = rect(92, 62, 62, 62, "#171A38", 'stroke="#8172CB" stroke-opacity=".5"') + chip(104, 74, 1.6);
  content += text(174, 107, "NEXTEP", 39, "#F8F9FF", 'font-weight="700" letter-spacing="3"');
  content += text(177, 137, "engineer your future", 16, "#AAA8CC", 'letter-spacing="1.2"');
  content += text(1824, 98, "EEE CAREER FUTURES", 17, "#B1B4D7", 'text-anchor="end" letter-spacing="3"');
  content += `<path d="M96 172H1824" stroke="#A9A5EE" stroke-opacity=".14"/>`;
  content += text(96, 912, `${String(i + 1).padStart(2, "0")} / ${sections[i]}`, 15, "#C4C5E4", 'letter-spacing="2.4"');
  content += text(1824, 912, "EEE ONLY  /  STUDENT-CENTRED", 15, "#AAAED1", 'text-anchor="end" letter-spacing="2"');
  for (let j = 0; j < 6; j++) content += `<rect x="${96 + 290 * j}" y="932" width="278" height="3" rx="1.5" fill="${j === i ? "#A998FF" : "#40475F"}"/>`;
  return content;
}
function sceneArt(i) {
  const label = text(99, 253, sections[i], 17, "#B3A0FF", 'letter-spacing="4.2"');
  if (i === 0) return label + heading(["The future changes.", "Your next step", "can be clearer."]) +
    text(100, 674, "Built for Electrical & Electronic", 29, "#CDD1E9") +
    text(100, 715, "Engineering students.", 29, "#CDD1E9") +
    pill(100, 788, "One discipline. Real focus.", "#9DEDF3", 345);
  if (i === 1) return label + heading(["Understand", "what’s changing."], 384) +
    text(100, 600, "Explore how AI may reshape", 29, "#CDD1E9") +
    text(100, 641, "engineering skills and careers.", 29, "#CDD1E9") +
    pill(100, 727, "AI developments", "#B9A8FF", 257) +
    pill(374, 727, "Skills & roles", "#9DEDF3", 235) +
    text(100, 838, "Signals to explore — not guaranteed predictions.", 20, "#8F99BC");
  if (i === 2) return label + heading(["Find a direction", "that fits you."], 384) +
    text(100, 600, "Connect your strengths and interests", 29, "#CDD1E9") +
    text(100, 641, "with future-focused EEE pathways.", 29, "#CDD1E9") +
    pill(100, 727, "Strengths", "#B9A8FF", 180) + pill(296, 727, "Interests", "#9DEDF3", 180) + pill(492, 727, "Goals", "#A5DEBD", 145) +
    rect(995, 794, 825, 62, "#0D1830", 'fill-opacity=".88" stroke="#7379AD" stroke-opacity=".4"') +
    text(1020, 834, "Embedded AI   ·   Semiconductors   ·   Smart grids", 22, "#E0DDFB") +
    text(100, 838, "Illustrative career directions", 20, "#8F99BC");
  if (i === 3) {
    let body = label + heading(["Make learning", "a clear next step."], 384) +
      text(100, 600, "A personalised route from what", 29, "#CDD1E9") +
      text(100, 641, "you know to what you need next.", 29, "#CDD1E9") +
      pill(100, 727, "Learn. Practise. Build.", "#9DEDF3", 320);
    const labels = [["01", "Circuit", "foundations"], ["02", "Python +", "control"], ["03", "Smart-grid", "project"]];
    labels.forEach(([n, first, second], j) => {
      const x = 1010 + 275 * j;
      body += rect(x, 705, 255, 128, "#0C1834", 'fill-opacity=".9" stroke="#8C8DD2" stroke-opacity=".5"');
      body += text(x + 18, 736, n, 18, "#B8A6FC") + text(x + 18, 774, first, 23, "#EEF0FF", 'font-weight="600"') + text(x + 18, 807, second, 23);
    });
    return body + text(1010, 866, "Illustrative pathway · smart-grid engineering", 20, "#ADB4D2");
  }
  if (i === 4) {
    let body = label + heading(["Build a career.", "Connect it", "to purpose."], 340) +
      text(100, 649, "A framework covering all 17", 28, "#CDD1E9") +
      text(100, 689, "UN Sustainable Development Goals.", 28, "#CDD1E9") +
      text(100, 768, "Smart grids, for example:", 23, "#C0C7E5") +
      pill(100, 792, "7  ENERGY", "#FCC30B", 177) + pill(292, 792, "9  INNOVATION", "#FD6925", 220) +
      pill(527, 792, "13  CLIMATE", "#83BD88", 203) +
      text(100, 877, "Potential contributions — not UN endorsement.", 19, "#909AB8");
    goals.forEach(([name, color], index) => {
      const x = 958 + (index % 3) * 290, y = 210 + Math.floor(index / 3) * 110;
      body += rect(x, y, 274, 98, "#111B32", `fill-opacity=".96" stroke="${color}" stroke-opacity=".7"`);
      body += `<rect x="${x}" y="${y + 13}" width="5" height="72" rx="2" fill="${color}"/>`;
      body += text(x + 19, y + 38, String(index + 1).padStart(2, "0"), 24, color, 'font-weight="700"');
      const lines = wrap(name, 20);
      const startY = y + (lines.length === 3 ? 27 : lines.length === 2 ? 38 : 56);
      lines.forEach((line, j) => { body += text(x + 65, startY + j * 25, line, 18.5, "#E3E8F9"); });
    });
    return body;
  }
  return `<defs><radialGradient id="halo"><stop stop-color="#7460DB" stop-opacity=".3"/><stop offset="1" stop-color="#11172A" stop-opacity="0"/></radialGradient></defs>
    <ellipse cx="960" cy="490" rx="680" ry="360" fill="url(#halo)"/>` +
    chip(596, 342, 4.7) +
    text(762, 454, "NEXTEP", 116, "#F5F4FF", 'font-weight="700" letter-spacing="8"') +
    text(960, 580, "engineer your future", 51, "#CBC6EE", 'text-anchor="middle" letter-spacing="3"') +
    `<path d="M743 638H1177" stroke="#8F87C8" stroke-opacity=".5"/>` +
    text(960, 713, "EEE focus. Personal pathways. Sustainable futures.", 27, "#B8C8E1", 'text-anchor="middle"');
}
await mkdir(work, { recursive: true });
const voiceDurations = await Promise.all(narration.map((_, i) => duration(path.join(work, `voice_0${i + 1}.mp3`))));
const speeds = voiceDurations.map((d, i) => Math.max(1, d / (lengths[i] - 1.05)));
if (speeds.some(s => s > 1.2)) throw new Error("Narration needs rewriting rather than excessive speed-up.");
const shade = `<defs>
  <linearGradient id="left"><stop stop-color="#080C22" stop-opacity=".99"/><stop offset=".39" stop-color="#080C22" stop-opacity=".96"/><stop offset=".61" stop-color="#080C22" stop-opacity=".12"/><stop offset="1" stop-color="#080C22" stop-opacity=".04"/></linearGradient>
  <linearGradient id="edges" x2="0" y2="1"><stop stop-color="#070B1E" stop-opacity=".58"/><stop offset=".23" stop-color="#070B1E" stop-opacity="0"/><stop offset=".77" stop-color="#070B1E" stop-opacity="0"/><stop offset="1" stop-color="#070B1E" stop-opacity=".94"/></linearGradient>
  </defs><rect width="1920" height="1080" fill="url(#left)"/><rect width="1920" height="1080" fill="url(#edges)"/>`;
await png("shade.png", shade);
await png("shade-outro.png", '<rect width="1920" height="1080" fill="#080C22" fill-opacity=".79"/>');
let srt = "", total = 0;
const timestamp = s => {
  const ms = Math.round(s * 1000);
  return `${String(Math.floor(ms / 3600000)).padStart(2, "0")}:${String(Math.floor(ms / 60000) % 60).padStart(2, "0")}:${String(Math.floor(ms / 1000) % 60).padStart(2, "0")},${String(ms % 1000).padStart(3, "0")}`;
};
for (let i = 0; i < 6; i++) {
  const n = String(i + 1).padStart(2, "0"), len = lengths[i];
  const spokenLength = voiceDurations[i] / speeds[i];
  const lines = wrap(narration[i], 107);
  const caption = rect(83, 969, 1754, 88, "#030716", 'fill-opacity=".86" stroke="#7A82A8" stroke-opacity=".2"') +
    lines.map((line, j) => text(960, (lines.length === 1 ? 1023 : 1006) + j * 34, line, 25, "#F8F9FF", 'text-anchor="middle"')).join("");
  await Promise.all([png(`art_${n}.png`, sceneArt(i)), png(`header_${n}.png`, header(i)), png(`caption_${n}.png`, caption)]);
  const source = path.join(work, `scene_${i === 5 ? "02" : n}.mp4`);
  const fadeOut = (0.45 + spokenLength - 0.15).toFixed(3);
  const filter = `[0:v]scale=${W}:${H}:force_original_aspect_ratio=increase,crop=${W}:${H},setsar=1,fps=${FPS},trim=duration=${len},setpts=PTS-STARTPTS,eq=brightness=-0.035:saturation=.9[base];` +
    `[base][1:v]overlay=shortest=1[shaded];[2:v]format=rgba,fade=t=in:st=0.12:d=0.55:alpha=1[title];` +
    `[shaded][title]overlay=x=0:y='20*(1-min(t/0.7,1))':shortest=1[art];` +
    `[art][3:v]overlay=shortest=1[branded];[4:v]format=rgba,fade=t=in:st=0.4:d=0.15:alpha=1,fade=t=out:st=${fadeOut}:d=0.15:alpha=1[caption];` +
    `[branded][caption]overlay=shortest=1,fade=t=in:st=0:d=0.2,fade=t=out:st=${len - .2}:d=0.2,format=yuv420p[out]`;
  const images = [i === 5 ? "shade-outro.png" : "shade.png", `art_${n}.png`, `header_${n}.png`, `caption_${n}.png`];
  if (!process.argv.includes("--audio-only")) await ff(["-filter_complex_threads", "1", "-stream_loop", "-1", "-i", source,
    ...images.flatMap(file => ["-loop", "1", "-framerate", String(FPS), "-i", path.join(work, file)]),
    "-filter_complex", filter, "-map", "[out]", "-an", "-t", String(len), "-r", String(FPS),
    "-c:v", "libx264", "-preset", "fast", "-crf", "19", "-threads", "2",
    "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709",
    path.join(work, `composed_${n}.mp4`)]);
  srt += `${i + 1}\n${timestamp(total + .45)} --> ${timestamp(total + .45 + spokenLength)}\n${wrap(narration[i], 70).join("\n")}\n\n`;
  console.log(`Scene ${i + 1}/6 composed (${len}s, narration ${spokenLength.toFixed(2)}s).`);
  total += len;
}
const segmentList = lengths.map((_, i) => `file '${path.join(work, `composed_0${i + 1}.mp4`)}'`).join("\n");
await writeFile(path.join(work, "segments.txt"), segmentList);
const silent = path.join(work, "assembled-silent.mp4");
await ff(["-f", "concat", "-safe", "0", "-i", path.join(work, "segments.txt"), "-c", "copy", silent]);
// Bake each voice segment to the same sample clock before concatenating.
// Keeping resampling/loudness analysis separate from the final mux also makes
// the narration track independently verifiable.
for (let i = 0; i < narration.length; i++) {
  await ff(["-i", path.join(work, `voice_0${i + 1}.mp3`), "-af",
    `atempo=${speeds[i].toFixed(6)},loudnorm=I=-16:TP=-2:LRA=8,aresample=48000,aformat=sample_fmts=s16:channel_layouts=stereo,asetpts=N/SR/TB,adelay=450:all=1,apad=whole_len=${lengths[i] * 48000},atrim=end_sample=${lengths[i] * 48000},asetpts=N/SR/TB`,
    "-c:a", "pcm_s16le", "-ar", "48000", "-ac", "2", path.join(work, `narration_0${i + 1}.wav`)]);
}
await writeFile(path.join(work, "narration-segments.txt"), narration.map((_, i) =>
  `file '${path.join(work, `narration_0${i + 1}.wav`)}'`).join("\n"));
const speech = path.join(work, "narration-complete.wav");
await ff(["-f", "concat", "-safe", "0", "-i", path.join(work, "narration-segments.txt"),
  "-c:a", "pcm_s16le", speech]);
if (Math.abs(await duration(speech) - total) > 0.01) throw new Error("Narration timeline has the wrong duration.");
const audioFilters = [
  "[1:a]volume=0.9[spoken]",
  `[2:a]atrim=duration=${total},asetpts=PTS-STARTPTS,volume=0.10,afade=t=in:st=0:d=1.2,afade=t=out:st=${total - 2}:d=2[bed]`,
  "[spoken][bed]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[mixed]",
];
await ff(["-filter_complex_threads", "1", "-i", silent, "-i", speech,
  "-i", path.join(work, "music.mp3"), "-filter_complex", audioFilters.join(";"),
  "-map", "0:v", "-map", "[mixed]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
  "-t", String(total), "-movflags", "+faststart", target]);
const { stdout: probeText } = await run("ffprobe", ["-v", "error", "-show_streams", "-of", "json", target]);
const streams = JSON.parse(probeText).streams;
const video = streams.find(s => s.codec_type === "video"), audio = streams.find(s => s.codec_type === "audio");
if (!video || video.width !== W || video.height !== H || !audio ||
    Math.abs(Number(video.duration) - total) > 0.1 ||
    Math.abs(Number(audio.duration) - total) > 0.1) {
  throw new Error("Final export must have full-length 1080p video AND audio streams.");
}
await writeFile("outputs/NEXTEP_Animated_Explainer_EN.srt", srt);
await writeFile(path.join(work, "storyboard.json"), JSON.stringify({ duration: total, resolution: "1920x1080", sections, narration, goals }, null, 2));
const frames = [];
for (let i = 0; i < 6; i++) {
  const filename = path.join(work, `proof_0${i + 1}.jpg`);
  await ff(["-ss", String(i < 5 ? i * 8 + 4 : 42), "-i", target, "-frames:v", "1", "-vf", "scale=960:540", "-q:v", "2", filename]);
  frames.push({ input: filename, left: (i % 2) * 960, top: Math.floor(i / 2) * 540 });
}
await sharp({ create: { width: 1920, height: 1620, channels: 3, background: "#080C22" } }).composite(frames).jpeg({ quality: 90 }).toFile("outputs/NEXTEP_Video_Contact_Sheet.jpg");
console.log(`Finished ${total}s video: ${target}`);
