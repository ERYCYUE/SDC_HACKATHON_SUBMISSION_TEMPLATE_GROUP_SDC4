// Self-contained reading deck for judges; not a speaker-led pitch.
const P=require('pptxgenjs'),fs=require('fs'),path=require('path');
const p=new P();p.layout='LAYOUT_WIDE';p.author='NEXTEP';
p.title='NEXTEP — EEE Student Futures | Judges’ Reading Edition';
p.subject='EEE-only career exploration, personalised reskilling and all 17 UN SDGs';
p.lang='en-GB';p.theme={headFontFace:'DejaVu Sans',bodyFontFace:'DejaVu Sans',lang:'en-GB'};
const C={navy:'101C35',paper:'F7F6F2',ink:'18243A',muted:'626C7A',purple:'7464EE',lav:'E8E3FF',mint:'B7E4D0',teal:'137C72',orange:'FFB18B',white:'FFFFFF'};
const sdg=JSON.parse(fs.readFileSync('data/sdg-impact.json'));
let page=0;const manifest=[];
function box(s,x,y,w,h,col){s.addShape('rect',{x,y,w,h,fill:{color:col},line:{color:col,width:0}});}
function t(s,v,x,y,w,h,size=13,color=C.ink,bold=false,extra={}){
 s.addText(v,{x,y,w,h,fontFace:'DejaVu Sans',fontSize:size,color,bold,margin:0,valign:'top',...extra});
}
function pic(s,name,x,y,w,h){
 s.addImage({path:path.join('outputs/nextep-assets',name+'.jpg'),x,y,w,h,sizing:{type:'cover',w,h}});
}
function base(section,title,sub='',source='Project basis: NEXTEP README and current prototype catalog.',dark=false){
 const s=p.addSlide();page++;s.background={color:dark?C.navy:C.paper};
 manifest.push({page,section,title});
 box(s,.61,.35,.2,.2,dark?C.mint:C.purple);
 t(s,'NEXTEP',.97,.28,2,.34,13,dark?C.white:C.ink,true,{charSpacing:1.8});
 t(s,section.toUpperCase(),6.1,.3,6.6,.3,9,dark?'BCC6D5':C.muted,false,{align:'right',charSpacing:1});
 t(s,title,.65,.96,12.02,.93,28,dark?C.white:C.ink,true);
 if(sub)t(s,sub,.67,1.99,11.98,.52,12.5,dark?'BCC6D5':C.muted);
 if(source)t(s,source,.66,6.66,12,.23,8,dark?'BCC6D5':C.muted);
 s.addShape('line',{x:.6,y:7.02,w:12.12,h:0,line:{color:dark?'34415A':'D9DDE0',width:.7}});
 t(s,'engineer your future  /  Judges’ reading edition',.62,7.13,9,.2,8,dark?'BCC6D5':C.muted);
 t(s,String(page).padStart(2,'0'),12.13,7.11,.55,.24,9,dark?'BCC6D5':C.muted,false,{align:'right'});
 return s;
}
function panel(s,x,y,w,h,head,body,col=C.white,size=13){
 box(s,x,y,w,h,col);t(s,head,x+.23,y+.2,w-.46,.5,16,C.ink,true);
 t(s,body,x+.23,y+.91,w-.46,h-1.09,size,C.ink,false,{breakLine:false,paraSpaceAfter:6});
}
function cols(s,items,y=2.75,h=3.67){
 const w=(12.02-(items.length-1)*.28)/items.length;
 items.forEach((a,i)=>panel(s,.65+i*(w+.28),y,w,h,a[0],a[1],a[2]||C.white,a[3]||13));
}
function table(s,headers,rows,widths,{y=2.75,rowH=.77,font=11.1}={}){
 let x=.65;headers.forEach((h,i)=>{box(s,x,y,widths[i],.43,C.navy);t(s,h,x+.13,y+.09,widths[i]-.26,.25,10,C.white,true);x+=widths[i];});
 rows.forEach((r,j)=>{let x=.65;const yy=y+.43+j*rowH;
  r.forEach((v,i)=>{box(s,x,yy,widths[i],rowH,j%2? 'ECEBF3':C.white);t(s,v,x+.13,yy+.13,widths[i]-.26,rowH-.21,font,C.ink,i===0);x+=widths[i];});
 });
}
function band(s,head,body,y=5.89,col=C.navy){
 box(s,.65,y,12.02,.61,col);t(s,head,.87,y+.13,2.5,.36,11,C.white,true);
 t(s,body,3.42,y+.13,8.96,.36,11,C.white);
}
// 01
{
 const s=base('Project dossier / Executive overview','Engineer your future.','EEE-only career exploration, personalised learning and connections to all 17 UN SDGs.','Reading guide: project rationale 2–5 • methods 6–9 • student case 10–12 • SDGs 13–17 • delivery and evidence 18–25.',true);
 pic(s,'students',8.31,2.7,4.36,3.71);
 t(s,'NEXTEP',.68,2.86,7.1,.8,42,C.white,true,{charSpacing:2});
 t(s,'Built exclusively for Electrical &\nElectronic Engineering (EEE) students.',.7,3.86,7.08,.85,23,C.mint,true);
 t(s,'NEXTEP helps students understand how AI may reshape EEE work, choose a suitable career direction, and turn skill gaps into an actionable learning pathway. Every direction can be explored through the UN’s 17 Sustainable Development Goals, connecting employability with purpose.',.7,4.99,7.01,1.26,13.5,'D4DCE8');
}
// 02
{
 const s=base('01 / Executive summary','What the project does — and why it matters.','A decision-support prototype for EEE students, not a promise to predict an individual’s future.');
 cols(s,[
 ['The problem and the response','EEE students must choose modules, projects and specialisations while AI changes engineering tasks. A broad job title alone does not explain which capabilities to develop or how to begin.\n\nNEXTEP joins three activities: tracking technological change, comparing relevant EEE roles, and planning learning. Its central output is a reasoned next step: a target direction, a visible skill gap and a project-backed pathway.',C.lav],
  ['The distinctive scope','EEE is the exclusive disciplinary scope, not a temporary segment of a cross-major careers platform. Recommendations can therefore connect circuits, embedded systems, power, verification and related capabilities within a shared engineering context.\n\nSustainability is equally central. The full 17-SDG framework is retained, while individual roles and projects link only to relevant goals and specific targets. The prototype distinguishes its new sampled postings from team-authored mappings and unvalidated scenarios.',C.mint]
 ]);
}
// 03
{
 const s=base('02 / Student need','The decisions students face before graduation.','The need is specific: decide what to pursue, what to learn and what evidence of ability to build.');
 cols(s,[
 ['Choosing a direction','A student may enjoy electronics but be unsure whether to explore embedded AI, verification, power electronics or another EEE direction. Similar-sounding roles can require different foundations.\n\nNEXTEP helps the student compare capabilities, role tasks and scenario outlooks before committing to a specialisation.',C.lav,12.5],
 ['Choosing what to learn','A course list does not explain prerequisites, the order of study or what can fit around an academic timetable. The newest tool is not automatically the most important skill.\n\nThe pathway begins from confirmed skills, identifies missing foundations and sequences learning around a time budget.',C.mint,12.5],
 ['Choosing why it matters','Students also want their work to address meaningful problems. Sustainability needs a concrete connection to technical learning, not just an SDG badge.\n\nNEXTEP links EEE capabilities to projects such as water sensing, energy monitoring or accessible navigation, then identifies relevant SDG targets.',C.orange,12.5]
 ]);
}
// 04
{
 const s=base('03 / Differentiation','Specialisation is the main difference: EEE only.','Conceptual comparison of approaches — not a tested ranking or claim about named competitors.');
 table(s,['Decision dimension','Broad guidance approach','NEXTEP’s intended approach'],[
 ['Scope','Supports many disciplines using general categories.','Exclusively Electrical & Electronic Engineering.'],
 ['Role reasoning','May begin from broad job titles and interests.','Connect EEE technology changes, tasks, skills and role directions.'],
 ['Learning output','May point to relevant courses or qualifications.','Sequence EEE skill gaps, prerequisites, resources and a capstone.'],
 ['Sustainability','May treat impact as a separate preference.','Connect the pathway to relevant goals within all 17 UN SDGs.']
 ],[2.1,4.29,5.63],{rowH:.76});
}
// 05
{
 const s=base('04 / End-to-end design','One student context connects the whole journey.','The product is organised around a continuous decision process rather than isolated recommendation pages.');
 table(s,['Stage','What the student contributes','What NEXTEP returns'],[
 ['1. Establish context','Confirm skills, interests, constraints and a possible goal.','An editable starting profile; unknowns remain visible.'],
 ['2. Explore change','Choose a technology, region or scenario to inspect.','Technology/task explanations and EEE role outlooks.'],
 ['3. Compare directions','Inspect roles and adjust the fit/outlook balance.','Separate capability-fit and scenario-outlook reasoning.'],
 ['4. Plan and connect','Choose a target role, learning budget and project.','A sequenced pathway, project and relevant SDG links.']
 ],[2.05,4.65,5.32],{rowH:.76});
}
// 06
{
 const s=base('05 / Tracking & forecasting','How AI signals become EEE career scenarios.','Technology → affected tasks → changing skill needs → possible role outlooks.');
 cols(s,[
 ['Inputs and interpretation','Research records can be refreshed through the arXiv updater, retaining source queries and timestamps. Research activity is a signal of attention, not direct evidence of industrial adoption.\n\nThe catalog links technology fronts to EEE tasks. Scenario assumptions describe which tasks may be automated, augmented or newly required; the role outlook aggregates those effects.',C.lav],
 ['What a student can do','Inspect the technology view, compare scenario curves and read why a role or skill changes. For example, more capable on-device models can motivate investigation of embedded deployment, verification and power efficiency.\n\nThe useful decision is whether to explore a capability or project. A rising research signal alone is not enough to claim that a job will grow or that a student will be hired.',C.white]
 ]);
}
// 07
{
 const s=base('06 / Forecast boundaries','Scenarios support exploration; they are not guarantees.','The current implementation must be interpreted as an explainable prototype, not a trained employment-prediction model.');
 cols(s,[
 ['What the model offers','The prototype includes 2024–2030 exploration and three scenario curves. Students can see how changed assumptions affect the same role or skill, rather than relying on one fixed future.\n\nPersonal fit, role outlook and evidence support are separate concepts. Scenario ranges are not statistical confidence intervals, and evidence labels are not calibrated probabilities.',C.mint],
 ['What remains unvalidated','Technology adoption assumptions, task effects and role scenarios have not been calibrated against longitudinal job outcomes. The China BOSS sample is one fixed-page snapshot, not a time series; other demo employment inputs remain synthetic. Paper counts are not vacancy counts, salaries or prediction accuracy.\n\nThe research updater is available, but an always-on collection schedule is not enabled by default. Repeated batches, independent source checks and outcome validation are required before stronger predictive claims.',C.orange]
 ]);
}
// 08
{
 const s=base('07 / Matching mechanism','A suitable role is not simply the most fashionable role.','Capability fit and future outlook answer different questions and remain visible to the student.');
 cols(s,[
 ['Personal fit: “Can I build towards it?”','The student confirms current skills and interests. The prototype compares these capabilities with the requirements of an EEE role, exposing the missing skills rather than hiding the reasoning behind one label.\n\nA student can inspect alternatives or pin a preferred target. Pinning changes the working target; it does not inflate that role’s score or turn an aspiration into a confirmed skill.',C.lav],
 ['Outlook: “Why explore this direction?”','Outlook reflects scenario assumptions and available regional evidence, not the individual’s aptitude. The default recommendation balance is 60% fit and 40% outlook; the student can adjust the weighting.\n\nThese are decision-support scores, not probabilities of employment. Their purpose is to make trade-offs inspectable: a promising direction may need more preparation, while a familiar role may face different task changes.',C.mint]
 ]);
}
// 09
{
 const s=base('08 / Reskilling mechanism','The pathway converts a gap into an ordered plan.','Learning is organised around dependencies, practical constraints and a demonstrable project.');
 cols(s,[
 ['Sequence matters','Prerequisites are ordered before dependent skills. Among feasible next steps, the model uses skill importance and trend assumptions to prioritise learning.\n\nThe plan groups foundations, core learning, advanced capabilities and project work. It includes estimated learning effort rather than treating every resource as equally short or equally valuable.',C.lav,12.5],
 ['Constraints matter','Students can work with weekly study time, start dates, cost preferences and resource preferences. Project effort is included in the total plan.\n\nThe scheduled duration can exceed the theoretical minimum because whole-week blocks may leave unused hours. This distinction should remain visible rather than promising an unrealistically compressed plan.',C.mint,12.5],
 ['Evidence matters','The pathway can be exported as Markdown, JSON or a calendar file and printed through the browser. Progress is self-reported and saved locally.\n\nA simulated improvement in role fit assumes that the learning gap has been completed. It is not an assessment result, a qualification or proof that proficiency has improved.',C.orange,12.5]
 ]);
}
// 10
{
 const s=base('09 / Worked student example','From an EEE starting point to a defensible direction.','Illustrative persona and reasoning only — no real student outcome or computed recommendation score is claimed.');
 pic(s,'study',.65,2.75,4.19,3.72);
 panel(s,5.12,2.75,7.55,3.72,'Starting point → candidate direction',
 'Assume an EEE student has circuit fundamentals and introductory Python, enjoys hands-on systems and wants to work on energy-efficient devices. These are starting assumptions, not a complete competence assessment.\n\nEmbedded AI is one direction to investigate because it combines sensing, hardware, software and resource constraints. The student should compare it with other EEE roles rather than being told it is the single “correct” choice.\n\nA useful learning goal is to deploy and evaluate a small sensor-based model, documenting what the device can do, where it fails and what it costs in energy.',C.lav,13);
}
// 11
{
 const s=base('10 / Worked learning sequence','What this student would learn — and in what order.','An example sequence; the real plan depends on confirmed skills, prerequisites and available study time.');
 table(s,['Phase','Learning focus','Evidence that makes the learning visible'],[
 ['1. Foundations','Embedded C/C++, MCU I/O, sensor interfaces and basic measurements.','Read sensor data reliably; explain wiring, units and failure cases.'],
 ['2. Deployment','Prepare a small model, deploy to a device and profile behaviour.','Record inference behaviour, memory use and reproducible test inputs.'],
 ['3. Evaluation','Check latency, model errors and device power consumption.','Compare operating modes and state the measurement conditions.'],
 ['4. Capstone','Integrate a sensor prototype and document the engineering trade-offs.','Produce a demo, test log, limitations and a clear explanation of design choices.']
 ],[1.65,4.64,5.73],{rowH:.77});
}
// 12
{
 const s=base('11 / Project-based proof','A portfolio artefact is more useful than a completion tick.','Example: an energy-aware smart sensor. The project is illustrative, not a deployed or validated solution.');
 pic(s,'circuit',.65,2.75,4.19,3.72);
 panel(s,5.12,2.75,7.55,3.72,'What the student should be able to show',
 'Technical work: a repeatable data-collection process, an on-device model or decision function, and a working prototype with documented interfaces.\n\nEvaluation: test conditions, representative failures, latency and energy measurements. The student should explain why a particular design was chosen rather than claiming that “AI” alone makes it useful.\n\nSustainability reasoning: identify a relevant goal and target, explain the potential contribution and describe evidence still needed. Lower device energy use, for example, does not by itself demonstrate a measured reduction in community emissions.',C.mint,13);
}
// 13
{
 const s=base('12 / Sustainability architecture','EEE is the discipline. All 17 SDGs are the framework.','The SDG layer connects career preparation to possible social and environmental value.');
 cols(s,[
 ['Breadth without pretending universal impact','All 17 goals have project content in the SDG catalog, covering more than energy and climate. EEE can also enable health sensing, accessible technology, environmental monitoring, education and collaboration.\n\nThis does not mean every EEE role supports every goal. Nor does it mean the prototype covers all 169 UN targets. The current SDG catalog contains 35 selected target entries and 17 project ideas.',C.lav],
 ['Specific links that can be inspected','The intended chain is role → skill → project → goal/target → contribution rationale. Students can explore all goals, narrow the view to a role or pathway, and inspect relevant project links.\n\nOfficial UN sources define the goals and targets. Career mappings and contribution strengths are team-authored assumptions; they are not UN certification, endorsement or proof of impact. Risk links must not be counted as positive contribution.',C.mint]
 ],2.75,3.67);
}
// 14–15 full SDG coverage with an EEE mechanism for every goal.
const examples=[
 'Off-grid solar lighting and charging','Soil sensing and automated irrigation','Heart-rate and fall-alert sensing',
 'Affordable electronics kits and labs','Inclusive embedded workshops','Low-power water-quality sensing',
 'Energy monitoring and scheduling','Vibration-based maintenance support','Open RISC-V verification',
 'Accessible ultrasonic navigation','Community air-quality sensing','Repairable electronics and reuse',
 'Rainfall and flood-warning systems','Coastal temperature/turbidity buoys','Forest acoustic monitoring',
 'Emergency broadcast and messaging','Open engineering and reusable data'
];
for(let g=0;g<2;g++){
 const s=base('13 / All 17 UN SDGs',g?'Goals 10–17: inclusion, resilience and partnership.':'Goals 1–9: access, wellbeing and infrastructure.',
 'Each tile pairs an official goal name with a team-authored EEE project idea; these are potential connections, not measured results.',
 'Sources: UN goal definitions via data/sdg-impact.json; project examples from the same catalog. No UN endorsement is implied.');
 for(let i=0;i<9;i++){
  const n=g*9+i,x=.65+(i%3)*4.15,y=2.78+Math.floor(i/3)*1.18;
  if(n>=17){box(s,x,y,3.78,1.02,C.navy);t(s,'Different EEE pathways,\nshared global goals.',x+.2,y+.21,3.38,.62,16,C.white,true);continue;}
  const goal=sdg.goals[n];box(s,x,y,3.78,1.02,C.white);box(s,x,y,.72,1.02,goal.color.slice(1));
  t(s,String(goal.id),x+.05,y+.23,.62,.5,26,C.white,true,{align:'center'});
  t(s,goal.name.en,x+.91,y+.1,2.68,.43,11.1,C.ink,true);
  t(s,examples[n],x+.91,y+.66,2.68,.28,8.6,C.muted);
 }
}
// 16
{
 const s=base('14 / From labels to targets','Three inspectable EEE-to-SDG examples.','A target-level explanation is more informative than a row of colourful SDG badges.');
 table(s,['EEE project idea','Target link and contribution logic','What would need to be checked'],[
 ['Off-grid solar lighting\nSkills: circuits, power, MCU','1.4 + 7.b: affordable lighting/charging may enable access to services and energy infrastructure.','Efficiency, runtime, cost, protection tests and relevance to intended users.'],
 ['Smart irrigation\nSkills: sensing and control','2.4 + 6.4: sensing and controlled watering may support resource-efficient agricultural practice.','Sensor reliability, water-use baseline, crop context and maintenance burden.'],
 ['Repairable electronics\nSkills: design and testing','12.5 + 12.4: repair and reuse may reduce waste and improve materials handling.','Repair success, component reuse, safe handling and actual waste avoided.']
 ],[2.66,4.67,4.69],{rowH:1.02,font:10.8});
 t(s,'Targets are paraphrased here. These are testable project hypotheses, not validated development outcomes.',.68,6.41,11.9,.21,9,C.muted);
}
// 17
{
 const s=base('15 / Responsible sustainability','Sustainability includes trade-offs and who benefits.','EEE technologies can create benefits and costs at the same time; the project should expose both.');
 cols(s,[
 ['Environmental trade-offs','More capable devices can consume energy, require new hardware and create electronic waste. Efficiency gains may be offset if usage expands.\n\nA pathway should encourage measurement, repairability and reuse. Proposed project evidence includes power tests, material choices and a clear statement of what has not been assessed.',C.mint,12.5],
 ['Access and inclusion','Assistive navigation, affordable labs and inclusive workshops create possible links to goals such as 4, 5 and 10. These social contributions depend on affordability, accessibility and actual participation.\n\nAn engineering prototype cannot establish inclusion by itself. Intended users should help define the problem, evaluate usability and identify unintended exclusion.',C.lav,12.5],
 ['Work and collaboration','Automation may improve tasks while disrupting existing work. Open engineering and shared data can support partnership, but they also require appropriate documentation and governance.\n\nNEXTEP’s goal is informed learning and adaptation. It should not label a group of workers obsolete or assume a technical improvement automatically creates fair outcomes.',C.orange,12.5]
 ]);
}
// 18
{
 const s=base('16 / Reading the product','Five connected views support one exploration.','This is a functional walkthrough, not a screenshot or claim of independently tested usability.');
 table(s,['View','Purpose','What a judge should inspect'],[
 ['Overview','Establish the student context and current direction.','Whether the starting assumptions and selected role are clear.'],
 ['Track & Forecast','Explore technology/task change and scenarios.','Whether changes are explained without implying certainty.'],
 ['Match & Reskill','Compare EEE roles and build a pathway.','Whether gaps, prerequisites and constraints affect the plan.'],
 ['SDG Impact','Inspect goals, targets and capstone connections.','Whether all 17 goals remain accessible and links are justified.'],
 ['Evidence','Inspect sources, assumptions and provenance.','Whether synthetic inputs and verified definitions are distinguished.']
 ],[2.15,4.45,5.42],{rowH:.63,font:10.7});
}
// 19
{
 const s=base('17 / Data provenance','Not all inputs have the same evidence status.','Transparent provenance is necessary because the prototype combines real sources with demonstration assumptions.');
 table(s,['Input type','Current basis','How it should be interpreted'],[
 ['Research records','arXiv records where fetched; timestamps and queries retained.','Evidence of research activity, not direct hiring demand.'],
 ['China employment sample','1,998 BOSS postings from a team workbook; 25 specialties across Beijing, Shanghai and Shenzhen; one 21–23 Oct 2026 batch.','Real sampled postings, not platform-wide or national demand, hiring outcomes or a trend series.'],
 ['Database & filters','D1-backed persistent batch; filter by specialty, city, stated education, advertised monthly-midpoint band and experience.','Education and pay are source-reported fields; ad salary is not personal expected income.'],
 ['Role directory & task model','Team-authored role/skill mappings; 15 supplemental specialties have no task model.','Those outlooks stay at a neutral 50 pending modelling; mappings are assumptions, not observed job skills.'],
 ['Career scenarios','Technology adoption and task-effect assumptions; no longitudinal employment outcomes.','Exploratory, unvalidated projections; one batch cannot produce a real growth rate.'],
 ['UN goals & project links','Official UN definitions; team-authored career/project mappings.','All 17 goals remain in scope; mappings are not UN endorsement or measured impact.']
 ],[2.18,4.55,5.29],{y:2.52,rowH:.58,font:9.7});
}
// 20
{
 const s=base('18 / Current implementation','A real sample is connected; a forecast is still a hypothesis.','The database expands current evidence for exploration without turning one sample into a national market estimate.');
 cols(s,[
 ['Database and student controls','The team workbook supplies 1,998 unique BOSS search-result records across 25 EEE directions and Beijing, Shanghai and Shenzhen. The application seeds and reads this batch through D1. Students can filter by direction, city, education, advertised monthly-pay midpoint and experience, then inspect source records and separate monthly from daily pay.\n\nThe capture is a single batch from 21–23 October 2026. Posting dates are unknown; the sample was taken from fixed result pages, not a random or platform-wide frame.',C.mint,11.8],
 ['Interpretation and limits','Counts do not measure nationwide demand or popularity. A single batch cannot yield real hiring or salary growth. Salary figures are advertised ranges or workbook estimates, not take-home pay or an individual income forecast.\n\nThe team directory supplies role/skill assumptions; 15 additional specialties have no task model and retain a neutral outlook. Technology/task career scenarios remain unvalidated. No student outcomes, prediction accuracy or impact results are claimed.',C.orange,11.8]
 ]);
}
// 21
{
 const s=base('19 / Privacy & student agency','The student remains in control of the interpretation.','A career-support tool should make sensitive inputs, assumptions and optional sharing understandable.');
 cols(s,[
 ['Local-first profile handling','CV parsing takes place in the browser for supported text-based files. The uploaded CV and full raw text are not persisted or uploaded by that parsing flow.\n\nStructured profile information, chat and progress are stored locally; imported datasets use browser storage. This reduces routine server handling, but local browser data still needs appropriate care on shared devices.',C.lav],
 ['Human control and optional AI','The student confirms skills, can compare targets and can revise the goal. No inferred interest should silently become a verified capability.\n\nIf configured, external AI advice requires per-session opt-in and disclosure of the structured context being sent. Raw CV files and their full parsed text are excluded. The tool supports exploration; it does not make hiring decisions or issue qualifications.',C.mint]
 ]);
}
// 22
{
 const s=base('20 / Evaluation proposal','How the project should demonstrate usefulness.','Proposed validation plan — no participant results, accuracy figures or impact percentages are reported.');
 table(s,['Question','Proposed test','Evidence to collect'],[
 ['Do students understand their options?','Give EEE students a structured exploration task, with and without the prototype.','Explanation quality, clarity ratings and reasons for the next decision.'],
 ['Are the pathways feasible?','Ask EEE educators to review prerequisites, effort and capstone suitability.','Review comments, dependency errors and revisions required.'],
 ['Are recommendations explainable?','Ask students to trace a suggestion back to skills, scenario and sources.','Misunderstandings, unsupported inferences and source-tracing success.'],
 ['Are SDG links defensible?','Review selected role/project/target links with domain and sustainability reviewers.','Rationale quality, trade-offs identified and links rejected or refined.']
 ],[2.55,4.47,5],{rowH:.77,font:10.9});
}
// 23
{
 const s=base('21 / Development priorities','What must happen before stronger claims are justified.','The next step is deeper EEE validation, not expansion into unrelated majors.');
 cols(s,[
 ['1. Extend and validate market evidence','The first team-workbook BOSS sample is now connected. Add later, clearly dated batches and broader coverage only with declared collection methods, so any future comparison uses actual repeated observations rather than the current single snapshot.\n\nReview extraction and search terms; separate observed postings and research activity from adoption assumptions. Validate forecasts before making stronger claims.',C.lav,12.5],
 ['2. Validate the student journey','Run a small, supervised EEE student study and educator review. Check whether users can explain a role choice, identify realistic skill gaps and follow a manageable plan.\n\nUse feedback to improve explanations, prerequisite sequencing and resource suitability. Report outcomes only after measurement; do not infer them from interface completion.',C.mint,12.5],
 ['3. Verify sustainability links','Review project-target relevance, user needs and unintended harms. Establish a practical measurement plan for selected prototypes before claiming social or environmental benefits.\n\nKeep all 17 SDGs available while marking strong, weak, indirect and risk-related links honestly. Retain clear separation between UN definitions and team-authored mappings.',C.orange,12.5]
 ]);
}
// 24
{
 const s=base('22 / Overall assessment','The contribution is a coherent EEE decision pathway.','NEXTEP joins career readiness and sustainable purpose without claiming certainty about the future.','Assessment summary: project contribution and intended value; effectiveness and outcomes remain to be validated.',true);
 const arr=[
 ['EEE DEPTH','One discipline, connected reasoning','Role exploration, task changes, skills and learning are framed within Electrical & Electronic Engineering — not generic advice across every major.',C.lav],
 ['ACTIONABILITY','A next step the student can inspect','The output is more than a suggested job title: it includes gaps, prerequisites, resource constraints and a project that can make learning visible.',C.mint],
 ['PURPOSE','All 17 SDGs, with specific links','Students can connect capability-building to relevant goals and targets, while distinguishing potential contribution from proven impact.',C.orange]
 ];
 arr.forEach((a,i)=>{const x=.65+i*4.1;box(s,x,2.81,3.82,3.55,a[3]);t(s,a[0],x+.22,3.04,3.38,.29,10,C.purple,true);t(s,a[1],x+.22,3.59,3.38,.84,21,C.ink,true);t(s,a[2],x+.22,4.76,3.38,1.31,12.5,C.ink);});
}
// 25
{
 const s=base('Appendix / Sources & interpretation','Sources, visual credits and claim boundaries.','The deck is designed to stand alone: examples, implemented features and proposed evaluation are explicitly separated.','No UN affiliation or endorsement is implied. No student outcome, prediction accuracy, revenue or partnership result is claimed.');
 cols(s,[
  ['Project and framework sources','Project basis: README.md; docs/V2_GUIDE.md; docs/CN_EMPLOYMENT.md; lib/market.ts; lib/market-server.ts; data/cn-employment.json; data/demo-v2.json; data/sdg-impact.json. These distinguish the team-workbook postings from team-authored catalog assumptions and proposed scenarios.\n\nOfficial SDG framework: sdgs.un.org/goals. Goal/target definitions and verification labels should be consulted for full wording. Target descriptions in this deck are shortened paraphrases.\n\nResearch API documentation: info.arxiv.org/help/api/user-manual.html. Research counts are not employment statistics.',C.white,11.4],
 ['Photographs and reading notes','Student collaboration: Unsplash, photo 1758270705290-62b6294dd044. Students studying: Pexels, photo 6209565. Circuit board: Pexels, photo 163125. Solar-panel laboratory image in earlier editions: Cal Poly.\n\nPhotographs are contextual illustrations, not NEXTEP users. All personas, capstones and role-pathway examples are illustrative unless explicitly identified otherwise.\n\nLearning hours, fit scores, contribution mappings and model scenarios are decision aids. None should be read as a qualification, hiring guarantee or certified sustainability result.',C.lav,12]
 ]);
}
fs.writeFileSync('outputs/NEXTEP_Judges_Reading_EN_contents.json',JSON.stringify(manifest,null,2));
p.writeFile({fileName:'outputs/NEXTEP_Judges_Reading_EN.pptx'}).then(()=>console.log(`Created ${page} pages for independent judge reading.`));
