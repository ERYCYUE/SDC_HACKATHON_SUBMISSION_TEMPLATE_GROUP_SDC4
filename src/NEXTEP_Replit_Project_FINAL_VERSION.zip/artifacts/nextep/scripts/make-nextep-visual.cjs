/* Editable English presentation. Photos live with generated output, not the app. */
const pptxgen = require('pptxgenjs');
const path = require('path');
const pptx = new pptxgen();
pptx.layout = 'LAYOUT_WIDE';
pptx.author = 'NEXTEP';
pptx.subject = 'Student career readiness, AI disruption and sustainability';
pptx.title = 'NEXTEP — Engineer your future';
pptx.company = 'NEXTEP';
pptx.lang = 'en-GB';
pptx.theme = {
  headFontFace: 'DejaVu Sans', bodyFontFace: 'DejaVu Sans', lang: 'en-GB',
};
const C = { navy:'101C35', ink:'18243A', paper:'F7F6F2', white:'FFFFFF',
  purple:'7464EE', lavender:'E8E3FF', mint:'B7E4D0', teal:'137C72',
  orange:'FFB18B', coral:'DC644B', muted:'626C7A', pale:'E8EBEE', dark:'1E2D48' };
const W=13.333333, H=7.5, F='DejaVu Sans';
const asset=n=>path.join('outputs/nextep-assets',n+'.jpg');
let page=0;
function rect(s,x,y,w,h,fill,line=fill,r=0) {
  s.addShape(r?'roundRect':'rect',{x,y,w,h,rectRadius:r, radius:r,
    fill:{color:fill},line:{color:line,width:0}});
}
function text(s,t,x,y,w,h,size=18,color=C.ink,bold=false,extra={}) {
  s.addText(t,{x,y,w,h,fontFace:F,fontSize:size,color,bold,margin:0,
    breakLine:false,valign:'mid',...extra});
}
function line(s,x,y,w,color=C.pale,width=1) {
  s.addShape('line',{x,y,w,h:0,line:{color,width,beginArrowType:'none',endArrowType:'none'}});
}
function photo(s,name,x,y,w,h) {
  s.addImage({path:asset(name),x,y,w,h,sizing:{type:'cover',w,h}});
}
function pill(s,t,x,y,w,fill=C.lavender,ink=C.purple) {
  rect(s,x,y,w,.34,fill,fill,.12);
  text(s,t,x+.13,y+.015,w-.26,.30,9,ink,true);
}
function chip(s,x,y,size=.22,col=C.purple) {
  rect(s,x,y,size,size,col);
  for(let i=0;i<3;i++) {
    const a=size*(i+1)/4;
    rect(s,x-.045,y+a,.045,.018,col);rect(s,x+size,y+a,.045,.018,col);
    rect(s,x+a,y-.045,.018,.045,col);rect(s,x+a,y+size,.018,.045,col);
  }
}
function base(section,dark=false) {
  const s=pptx.addSlide();page++;s.background={color:dark?C.navy:C.paper};
  const ink=dark?C.white:C.ink;
  chip(s,.57,.35,.21,dark?C.mint:C.purple);
  text(s,'NEXTEP',.94,.28,2,.34,13,ink,true,{charSpacing:1.9});
  text(s,section.toUpperCase(),8,.3,4.7,.28,9,dark?'BCC6D5':C.muted,false,{align:'right',charSpacing:1.5});
  line(s,.58,7.04,12.16,dark?'34415A':'D9DDE0',.7);
  text(s,'engineer your future',.58,7.13,5,.17,8,dark?'B7C1D0':C.muted);
  text(s,String(page).padStart(2,'0'),12.18,7.1,.56,.22,9,dark?'B7C1D0':C.muted,false,{align:'right'});
  return s;
}
function title(s,t,sub='',dark=false) {
  text(s,t,.62,.99,12.05,1.12,31,dark?C.white:C.ink,true,{breakLine:false});
  if(sub) text(s,sub,.64,2.14,11.9,.55,13,dark?'BCC6D5':C.muted,false,{valign:'top'});
}
function note(s,t) { text(s,t,.65,6.64,12,.24,8.5,C.muted); }
function row(s,n,head,body,x,y,w,accent=C.purple,dark=false) {
  text(s,n,x,y,.47,.4,15,accent,true);
  text(s,head,x+.65,y,w-.65,.38,17,dark?C.white:C.ink,true);
  text(s,body,x+.65,y+.52,w-.72,.7,12,dark?'BBC6D7':C.muted,false,{valign:'top'});
}
// 01 — Editorial cover: typography + full-height real photograph.
{
  const s=base('Student futures / project overview',true);
  photo(s,'students',7.13,.89,5.6,5.94);
  rect(s,7.13,5.62,5.6,1.21,C.mint);
  text(s,'FOR STUDENTS. FOR WHAT’S NEXT.',7.43,5.88,5,.28,11,C.ink,true);
  text(s,'AI readiness × purposeful careers',7.43,6.28,5,.25,12,C.ink);
  pill(s,'A CAREER COMPASS FOR STUDENTS',.65,1.12,3.95,C.dark,C.mint);
  text(s,'Engineer\nyour future.',.6,1.94,6.28,2.06,43,C.white,true,{breakLine:false});
  text(s,'What should I aim for?\nWhat should I learn next?',.67,4.3,5.9,.85,22,C.orange,false);
  text(s,'NEXTEP connects AI change, personal learning\nand sustainable engineering careers.',.67,5.63,5.9,.77,13,'BEC9D9');
  s.addNotes('Photos are contextual illustrations, not NEXTEP users or verified project outcomes. This presentation describes the project vision; forecast results are scenario-based.');
}
// 02 — Student problem, human image and question.
{
  const s=base('01 / The student challenge');
  title(s,'The future of work is changing.\nStudents need a direction, not more anxiety.');
  photo(s,'study',.65,2.61,5.04,3.73);
  rect(s,.65,5.43,5.04,.91,C.navy);
  text(s,'“Will what I learn today\nstill matter when I graduate?”',.91,5.58,4.52,.59,15,C.white,true);
  row(s,'01','Changing tasks','AI can reshape tasks within a role — not just replace whole job titles.',6.12,2.69,6.45,C.coral);
  row(s,'02','Unclear priorities','Students must choose modules, projects and new tools before the future is certain.',6.12,3.99,6.45,C.purple);
  row(s,'03','A search for meaning','Career decisions should connect personal strengths with real-world problems.',6.12,5.29,6.45,C.teal);
}
// 03 — Three colour-coded pillars, no repeated generic bullet boxes.
{
  const s=base('02 / The NEXTEP approach',true);
  title(s,'One connected journey.\nThree questions students can act on.','From understanding change to choosing a direction and building evidence of ability.',true);
  const items=[
    ['01','UNDERSTAND','What is changing?','Track AI progress and explore\nemerging or shifting roles.',C.lavender,C.purple],
    ['02','CHOOSE','Where could I go?','Match interests and current skills\nto possible future roles.',C.mint,C.teal],
    ['03','BUILD','What do I learn next?','Follow a personalised reskilling\npathway linked to SDG impact.',C.orange,C.coral]
  ];
  items.forEach((a,i)=>{
    const x=.65+i*4.13;rect(s,x,3.12,3.78,3.17,a[4]);
    text(s,a[0],x+.24,3.33,1,.69,36,a[5],true);
    text(s,a[1],x+.25,4.22,3.25,.25,9,a[5],true,{charSpacing:2});
    text(s,a[2],x+.25,4.68,3.25,.43,19,C.ink,true);
    text(s,a[3],x+.25,5.36,3.25,.67,12,C.ink);
  });
}
// 04 — Signal-to-decision mechanism and actual hardware imagery.
{
  const s=base('03 / Track & forecast');
  title(s,'Turn AI developments into\nbetter learning decisions.');
  photo(s,'circuit',8.77,2.55,3.92,3.83);
  pill(s,'ILLUSTRATIVE EXAMPLE',.65,2.6,2.65);
  const blocks=[
    ['TECHNOLOGY SIGNAL','More capable models\non smaller devices',C.lavender],
    ['TASK IMPLICATION','More intelligent sensing;\nnew testing challenges',C.mint],
    ['LEARNING RESPONSE','Explore embedded AI,\nvalidation and efficiency',C.orange]
  ];
  blocks.forEach((a,i)=>{
    const y=3.2+i*.94;rect(s,.65,y,7.72,.77,a[2]);
    text(s,a[0],.88,y+.12,2.08,.50,9,C.ink,true);
    text(s,a[1],3.18,y+.11,4.94,.53,13,C.ink);
  });
  note(s,'Outlooks are scenario-based estimates, not guaranteed job predictions. Catalog assumptions must be distinguished from external evidence.');
}
// 05 — Student-facing goals: contrasting typography and tactile colour blocks.
{
  const s=base('04 / Goals that survive change');
  title(s,'Do not chase one “AI-proof” job.\nBuild a direction you can keep adapting.');
  const ys=2.66;
  [['01','CAPABILITY','Understand systems.\nBuild things that work.','Circuit fundamentals • coding\nmeasurement • systems thinking',C.lavender,C.purple],
   ['02','ADAPTABILITY','Learn new tools.\nKeep your judgement.','AI-assisted workflows • testing\ncritical evaluation • continuous learning',C.mint,C.teal],
   ['03','PURPOSE','Choose a problem\nworth solving.','Energy access • resilient infrastructure\nresponsible resource use',C.orange,C.coral]
  ].forEach((a,i)=>{
    const x=.65+i*4.14;rect(s,x,ys,3.77,3.75,a[4]);
    text(s,a[0],x+.24,ys+.2,1,.6,30,a[5],true);
    text(s,a[1],x+.24,ys+1.02,3.27,.25,10,a[5],true,{charSpacing:1});
    text(s,a[2],x+.24,ys+1.52,3.27,.87,20,C.ink,true);
    line(s,x+.24,ys+2.71,3.27,a[5],.7);
    text(s,a[3],x+.24,ys+2.94,3.27,.55,10,C.ink);
  });
}
// 06 — Concrete matching example, native editable visual.
{
  const s=base('05 / Matching in practice',true);
  title(s,'From “I like electronics”\nto a role worth exploring.','Illustrative student journey — not an actual profile, recommendation score or employment outcome.',true);
  rect(s,.65,2.98,3.83,3.37,C.paper);
  pill(s,'STARTING POINT',.91,3.24,2.05,C.lavender,C.purple);
  text(s,'EEE student',.91,3.86,3.3,.5,24,C.ink,true);
  text(s,'Has: circuit basics + Python\nEnjoys: hands-on problem-solving\nCares about: energy efficiency',.91,4.63,3.25,1.14,12,C.muted,false,{breakLine:false});
  text(s,'→',4.68,4.12,.67,.6,30,C.mint,true);
  rect(s,5.53,2.98,7.15,3.37,C.dark);
  text(s,'POSSIBLE DIRECTION',5.86,3.29,6.4,.26,10,C.mint,true,{charSpacing:1.5});
  text(s,'Embedded AI engineering',5.86,3.88,6.4,.57,26,C.white,true);
  text(s,'Why explore it?',5.86,4.73,3,.32,13,C.orange,true);
  text(s,'Combines software + hardware + real-world sensing.\nCompare fit, skill gaps and outlook before committing.',5.86,5.2,6.33,.68,13,'CAD3E0');
  text(s,'Personal fit ≠ market outlook. Students should be able to inspect both.',.69,6.59,11.9,.24,10,'BCC6D5');
}
// 07 — Learning pathway with a real board image, no numerical forecasts.
{
  const s=base('06 / Personalised learning');
  title(s,'A pathway, not a pile of course links.','Example destination: build and evaluate an energy-aware edge-AI sensor.');
  const stages=[
    ['01','FOUNDATIONS','Strengthen the basics','C/C++ • microcontrollers\nsensors • measurement',C.lavender,C.purple],
    ['02','NEW CAPABILITIES','Add embedded AI','Model deployment • profiling\nvalidation • power measurement',C.mint,C.teal],
    ['03','PROOF OF SKILL','Build a capstone','Compare accuracy, latency\nand energy use on a device',C.orange,C.coral]
  ];
  stages.forEach((a,i)=>{
    const x=.65+i*4.15;rect(s,x,2.99,3.78,2.52,a[4]);
    text(s,a[0],x+.23,3.19,.65,.48,25,a[5],true);
    text(s,a[1],x+.23,3.87,3.31,.24,10,a[5],true);
    text(s,a[2],x+.23,4.32,3.31,.35,16,C.ink,true);
    text(s,a[3],x+.23,4.85,3.31,.48,10.5,C.ink);
  });
  line(s,.94,5.94,11.4,C.purple,1.3);
  ['Start from current skills','Prioritise the gaps','Revisit as evidence changes'].forEach((t,i)=>{
    rect(s,.92+i*4.15,5.87,.12,.12,C.purple);
    text(s,t,.93+i*4.15,6.19,3.73,.31,11,C.muted);
  });
  note(s,'Sequence shown for illustration; the actual pathway depends on starting skills, prerequisites and available study time.');
}
// 08 — SDGs: real photo + official goal colours, carefully scoped contribution.
{
  const s=base('07 / Sustainable development');
  title(s,'Your next skill can serve a bigger goal.','NEXTEP connects career and learning choices to the UN’s 17 Sustainable Development Goals.');
  photo(s,'solar',.65,2.86,5.18,3.55);
  rect(s,.65,5.72,5.18,.69,C.navy);
  text(s,'Real-world context: students testing solar panels',.88,5.9,4.72,.26,10,C.white);
  const sdgs=[
    ['7','AFFORDABLE AND CLEAN ENERGY','Power electronics → energy conversion', 'FCC30B'],
    ['9','INDUSTRY, INNOVATION & INFRASTRUCTURE','Embedded systems → robust infrastructure','FD6925'],
    ['13','CLIMATE ACTION','Efficient devices → lower energy demand','3F7E44']
  ];
  sdgs.forEach((a,i)=>{
    const y=2.87+i*1.13;rect(s,6.2,y,.76,.76,a[3]);
    text(s,a[0],6.2,y+.11,.76,.5,25,C.white,true,{align:'center'});
    text(s,a[1],7.19,y+.03,5.45,.26,10,C.ink,true);
    text(s,a[2],7.19,y+.4,5.45,.35,12,C.muted);
  });
  note(s,'Example links indicate potential contribution, not measured impact. Evidence, trade-offs and targets should be checked for each project.');
}
// 09 — Capstone mini case with visual, objective and evidence.
{
  const s=base('08 / What learning looks like');
  title(s,'Make the future tangible.\nBuild something you can explain.');
  photo(s,'circuit',.65,2.64,5.15,3.84);
  pill(s,'ILLUSTRATIVE CAPSTONE',.91,2.88,2.9,C.navy,C.white);
  text(s,'Energy-aware\nsmart sensor',6.26,2.74,6.1,1.02,28,C.ink,true);
  row(s,'→','Learn','Collect sensor data, deploy a small model and test the device.',6.27,4.01,6.12,C.purple);
  row(s,'→','Show','Document accuracy, latency, energy use and limitations.',6.27,5.33,6.12,C.teal);
}
// 10 — Journey diagram, editorial rather than dense repeated cards.
{
  const s=base('09 / The student experience',true);
  title(s,'A repeatable loop for an uncertain future.','NEXTEP supports a next decision — not a one-time prediction of an entire career.',true);
  const a=[
    ['EXPLORE','See what AI is changing.',C.lavender,C.purple],
    ['COMPARE','Inspect roles and fit.',C.mint,C.teal],
    ['COMMIT','Choose one learning goal.',C.orange,C.coral],
    ['REVISIT','Update with new evidence.',C.lavender,C.purple]
  ];
  a.forEach((v,i)=>{
    const x=.65+i*3.13;rect(s,x,3.2,2.78,2.32,v[2]);
    text(s,String(i+1).padStart(2,'0'),x+.22,3.41,2.34,.57,30,v[3],true);
    text(s,v[0],x+.22,4.28,2.34,.28,12,C.ink,true);
    text(s,v[1],x+.22,4.87,2.34,.36,10.5,C.ink);
    if(i<3)text(s,'→',x+2.83,4.04,.27,.4,17,C.white);
  });
  text(s,'Skills → projects → reflection → a better-informed next step',.69,6.18,12,.39,18,C.mint);
}
// 11 — Closing, colourful image triptych and student-centred takeaway.
{
  const s=base('10 / Why NEXTEP matters');
  title(s,'Not a promise of a perfect future.\nA better way to prepare for it.');
  [['students','CLARITY','Know what to aim for.',C.lavender],
   ['circuit','CAPABILITY','Know what to learn next.',C.mint],
   ['solar','PURPOSE','Know why it matters.',C.orange]
  ].forEach((v,i)=>{
    const x=.65+i*4.15;photo(s,v[0],x,2.66,3.78,2.09);
    rect(s,x,4.75,3.78,1.23,v[3]);
    text(s,v[1],x+.23,4.94,3.31,.24,10,C.ink,true,{charSpacing:1});
    text(s,v[2],x+.23,5.4,3.31,.32,14,C.ink,true);
  });
  text(s,'NEXTEP',.67,6.33,2.4,.4,20,C.purple,true,{charSpacing:2});
  text(s,'engineer your future',3.11,6.36,6,.35,18,C.muted);
}
// 12 — Sources and clarity on what is and is not evidence.
{
  const s=base('Appendix / Visual credits & interpretation');
  title(s,'Sources, examples and responsible claims.');
  text(s,'IMAGE CREDITS',.67,2.61,4.6,.3,11,C.purple,true,{charSpacing:1.3});
  const credits=[
    ['Student collaboration','Unsplash — photo 1758270705290-62b6294dd044','https://unsplash.com/photos/1758270705290-62b6294dd044'],
    ['Students studying','Pexels — photo 6209565','https://www.pexels.com/photo/6209565/'],
    ['Circuit-board detail','Pexels — photo 163125','https://www.pexels.com/photo/163125/'],
    ['Solar-panel testing','Cal Poly — university engineering lab photograph','https://www.calpoly.edu/sites/default/files/2021-08/news_surp-solar_hero-2.jpg']
  ];
  credits.forEach((v,i)=>{
    const y=3.16+i*.67;text(s,v[0],.67,y,5.4,.24,12,C.ink,true);
    text(s,v[1],.67,y+.29,5.4,.23,9,C.muted,false,{hyperlink:{url:v[2]}});
  });
  rect(s,6.72,2.59,5.95,3.8,'EAE7F6');
  text(s,'HOW TO READ THIS DECK',7.03,2.91,5.32,.28,11,C.purple,true);
  text(s,'• Photos provide context; they do not show\n   NEXTEP users or validated outcomes.\n\n• Profiles and learning paths are illustrative.\n\n• Forecasts are scenario-based, not guarantees.\n\n• SDG links describe potential contribution;\n   they are not proof of measured impact.',7.03,3.5,5.27,2.5,12,C.ink,false,{valign:'top'});
  note(s,'Project basis: NEXTEP project brief and README. SDG framework: United Nations, sdgs.un.org/goals. No UN affiliation or endorsement implied.');
}
pptx.writeFile({fileName:'outputs/NEXTEP_Student_Futures_Visual_EN.pptx'})
  .then(()=>console.log('Created 12-slide NEXTEP visual English deck.'));
