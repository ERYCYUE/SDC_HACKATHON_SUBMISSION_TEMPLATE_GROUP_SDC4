import fs from "node:fs/promises";
import path from "node:path";
import pptxgen from "pptxgenjs";

const pptx = new pptxgen();
pptx.layout = "LAYOUT_WIDE";
pptx.author = "NEXTEP";
pptx.subject = "电子信息工程职业探索、AI 技术趋势与可持续发展";
pptx.title = "NEXTEP｜让技能连接未来";
pptx.company = "NEXTEP";
pptx.lang = "zh-CN";
pptx.theme = {
  headFontFace: "Microsoft YaHei",
  bodyFontFace: "Microsoft YaHei",
  lang: "zh-CN",
};
pptx.defineSlideMaster({
  title: "NEXTEP",
  background: { color: "080B1D" },
  objects: [
    { rect: { x: 0, y: 0, w: 0.055, h: 7.5, line: { color: "080B1D", transparency: 100 }, fill: { color: "9181FF" } } },
  ],
});

const W = 13.333;
const H = 7.5;
const C = {
  bg: "080B1D",
  panel: "111831",
  panel2: "161F3D",
  panel3: "202A4B",
  white: "F3F1FF",
  text: "D7DCF0",
  muted: "9AA6C6",
  faint: "687595",
  purple: "A794FF",
  cyan: "65D5E0",
  green: "83DDA6",
  orange: "FFC17E",
  pink: "F19AD7",
  blue: "75AEFF",
  line: "303957",
};
const FONT = "Microsoft YaHei";
const S = pptx.ShapeType;

function txt(slide, value, x, y, w, h, size = 16, color = C.text, opts = {}) {
  slide.addText(value, {
    x, y, w, h, fontFace: FONT, fontSize: size, color,
    margin: 0, breakLine: false, valign: "mid", fit: "shrink",
    paraSpaceAfterPt: 0, charSpacing: 0,
    ...opts,
  });
}
function rect(slide, x, y, w, h, fill, radius = 0.18, line = fill, transparency = 0) {
  slide.addShape(radius ? S.roundRect : S.rect, {
    x, y, w, h, rectRadius: radius,
    line: { color: line, transparency: line === fill ? 100 : 0, width: 0.8 },
    fill: { color: fill, transparency },
    radius,
  });
}
function line(slide, x1, y1, x2, y2, color = C.line, width = 1, dash) {
  slide.addShape(S.line, {
    x: x1, y: y1, w: x2 - x1, h: y2 - y1,
    line: { color, width, ...(dash ? { dashType: "dash" } : {}) },
  });
}
function circle(slide, x, y, d, fill, lineColor = fill, transparency = 0) {
  slide.addShape(S.ellipse, {
    x, y, w: d, h: d,
    line: { color: lineColor, transparency: lineColor === fill ? 100 : 0, width: 1 },
    fill: { color: fill, transparency },
  });
}
function chip(slide, x, y, size = 0.42) {
  rect(slide, x, y, size, size, "171E3B", 0.1, "625A93");
  const inset = size * 0.30;
  slide.addShape(S.rect, {
    x: x + inset, y: y + inset, w: size - inset * 2, h: size - inset * 2,
    line: { color: C.purple, width: 1.1 }, fill: { color: "171E3B", transparency: 100 },
  });
  for (let i = 0; i < 4; i++) {
    const p = size * (0.35 + i * 0.1);
    line(slide, x + p, y + size * 0.13, x + p, y + inset, C.purple, 0.8);
    line(slide, x + p, y + size - inset, x + p, y + size * 0.87, C.purple, 0.8);
    line(slide, x + size * 0.13, y + p, x + inset, y + p, C.purple, 0.8);
    line(slide, x + size - inset, y + p, x + size * 0.87, y + p, C.purple, 0.8);
  }
}
function brand(slide, x = 0.55, y = 0.35, small = false) {
  const m = small ? 0.34 : 0.42;
  chip(slide, x, y, m);
  txt(slide, "NEXTEP", x + m + 0.12, y - 0.006, small ? 1.25 : 1.55, m * 0.64, small ? 14 : 17, C.white, { bold: true, charSpacing: 1.3 });
  txt(slide, "engineer your future", x + m + 0.13, y + m * 0.57, small ? 1.7 : 2.3, 0.15, small ? 7.5 : 8.5, C.muted, { charSpacing: 0.4 });
}
function footer(slide, page, section = "PROJECT OVERVIEW") {
  line(slide, 0.58, 7.0, 12.75, 7.0, C.line, 0.65);
  txt(slide, "NEXTEP  ·  engineer your future", 0.62, 7.1, 3.5, 0.17, 8.4, C.muted, { charSpacing: 0.55 });
  txt(slide, section.toUpperCase(), 9.25, 7.1, 2.7, 0.17, 7.5, C.faint, { align: "right", charSpacing: 1.1 });
  txt(slide, String(page).padStart(2, "0"), 12.25, 7.09, 0.42, 0.18, 8.5, C.purple, { bold: true, align: "right" });
}
function heading(slide, section, title, subtitle, page, kicker = "NEXTEP  /  PROJECT OVERVIEW") {
  brand(slide);
  txt(slide, `${kicker}     ·     ${section.toUpperCase()}`, 0.62, 1.04, 10.5, 0.22, 8.3, C.cyan, { bold: true, charSpacing: 1.25 });
  txt(slide, title, 0.62, 1.36, 11.9, 0.56, 27.5, C.white, { bold: true, charSpacing: 0.2 });
  txt(slide, subtitle, 0.64, 2.0, 11.9, 0.38, 11.6, C.muted);
  footer(slide, page, section);
}
function pill(slide, label, x, y, w, color = C.purple, fill = "1A2040") {
  rect(slide, x, y, w, 0.31, fill, 0.12, fill);
  circle(slide, x + 0.11, y + 0.115, 0.075, color);
  txt(slide, label, x + 0.25, y + 0.045, w - 0.34, 0.2, 8.4, C.text, { bold: true });
}
function card(slide, x, y, w, h, opts = {}) {
  rect(slide, x, y, w, h, opts.fill || C.panel, 0.16, opts.line || C.panel);
  if (opts.accent) rect(slide, x + 0.02, y + 0.14, 0.035, h - 0.28, opts.accent, 0.015, opts.accent);
}
function dotList(slide, items, x, y, w, opts = {}) {
  const color = opts.color || C.cyan;
  const gap = opts.gap || 0.48;
  items.forEach((item, i) => {
    circle(slide, x, y + i * gap + 0.11, 0.075, color);
    txt(slide, item, x + 0.19, y + i * gap, w - 0.19, 0.31, opts.size || 11, opts.textColor || C.text);
  });
}

// 01 — Cover: NEXTEP brand and a custom, editable SDG-style technology orbit.
{
  const slide = pptx.addSlide("NEXTEP");
  brand(slide, 0.72, 0.56, false);
  txt(slide, "职业探索 × AI 技术趋势 × 可持续发展", 0.77, 2.0, 5.9, 0.28, 10, C.cyan, { bold: true, charSpacing: 1.8 });
  txt(slide, "让技能\n连接未来。", 0.72, 2.52, 6.4, 1.65, 38, C.white, { bold: true, breakLine: false, valign: "mid", lineSpacingMultiple: 1.08 });
  txt(slide, "NEXTEP 用可解释的趋势情景、个人能力画像与学习路径，\n帮助电子信息工程人才看见变化，并规划下一步。", 0.78, 4.44, 5.65, 0.74, 13, C.text, { breakLine: false, valign: "top", lineSpacingMultiple: 1.2 });
  pill(slide, "项目介绍  /  产品原型", 0.78, 5.48, 2.15, C.purple, "171E3A");
  txt(slide, "TRACK  →  MATCH  →  RESKILL  →  CONNECT", 0.8, 6.24, 5.7, 0.24, 8.8, C.faint, { bold: true, charSpacing: 1.15 });

  const cx = 9.76, cy = 3.68, outer = 2.15;
  [outer * 2, outer * 1.55, outer * 1.04].forEach((d, i) => {
    slide.addShape(S.ellipse, {
      x: cx - d / 2, y: cy - d / 2, w: d, h: d,
      line: { color: i === 0 ? "343353" : "363456", width: i === 0 ? 0.8 : 1, transparency: i === 0 ? 12 : 0 },
      fill: { color: C.bg, transparency: 100 },
    });
  });
  const orbitColors = [C.purple, C.cyan, C.green, C.orange, C.pink, C.blue];
  for (let i = 0; i < 12; i++) {
    const a = (Math.PI * 2 * i) / 12 - Math.PI / 2;
    const r = outer * 0.84;
    const x = cx + Math.cos(a) * r;
    const y = cy + Math.sin(a) * r;
    circle(slide, x - 0.095, y - 0.095, 0.19, "171E3B", orbitColors[i % orbitColors.length]);
    txt(slide, String(i + 1).padStart(2, "0"), x - 0.07, y - 0.043, 0.14, 0.09, 5.8, C.white, { bold: true, align: "center" });
  }
  rect(slide, cx - 0.8, cy - 0.55, 1.6, 1.1, "181E40", 0.2, "625A93");
  chip(slide, cx - 0.15, cy - 0.34, 0.3);
  txt(slide, "NEXTEP", cx - 0.57, cy + 0.06, 1.14, 0.28, 19, C.white, { bold: true, charSpacing: 1 });
  txt(slide, "ENGINEERING  ×  SUSTAINABILITY", cx - 1.4, 6.25, 2.8, 0.19, 7.3, C.muted, { align: "center", charSpacing: 1.0 });
  footer(slide, 1, "INTRODUCTION");
}

// 02 — Purpose and the transition challenge.
{
  const slide = pptx.addSlide("NEXTEP");
  heading(slide, "WHY NEXTEP", "职业变化，需要一张“可行动”的地图", "技术信号不等于职业结论；把变化转成个人能理解、能规划的下一步。", 2);
  const cards = [
    { x: 0.65, n: "01", color: C.cyan, title: "技术在变", lines: ["AI 能力持续扩展", "不同技术发展节奏不一", "需要跟踪信号与情景"] },
    { x: 4.58, n: "02", color: C.purple, title: "任务在变", lines: ["岗位由多项任务构成", "部分任务被增强或重组", "技能需求随情景变化"] },
    { x: 8.51, n: "03", color: C.orange, title: "人的路径要跟上", lines: ["个体起点并不相同", "转型需要具体学习步骤", "还要看见更广的社会价值"] },
  ];
  for (const c of cards) {
    card(slide, c.x, 2.7, 3.65, 2.7, { accent: c.color });
    txt(slide, c.n, c.x + 0.26, 2.94, 0.48, 0.32, 12, c.color, { bold: true, charSpacing: 1.2 });
    txt(slide, c.title, c.x + 0.26, 3.4, 3.0, 0.46, 20, C.white, { bold: true });
    dotList(slide, c.lines, c.x + 0.29, 4.12, 3.0, { gap: 0.38, size: 10.5, color: c.color });
  }
  rect(slide, 0.68, 5.82, 11.52, 0.7, "151B35", 0.16);
  txt(slide, "NEXTEP 的定位", 0.94, 6.0, 1.55, 0.25, 10, C.purple, { bold: true });
  txt(slide, "提供决策支持与学习规划，不代替个人判断，也不把情景推演当成确定预测。", 2.53, 5.98, 9.2, 0.28, 12, C.white, { bold: true });
}

// 03 — The three connected product pillars.
{
  const slide = pptx.addSlide("NEXTEP");
  heading(slide, "THE PRODUCT", "三大目标，串起一条职业探索路径", "从外部变化到个人行动，再把技能与可持续发展目标相连接。", 3);
  const colX = [0.68, 4.57, 8.46];
  const colW = 3.58;
  const blocks = [
    { n: "01", en: "TRACK & FORECAST", zh: "追踪与预测", accent: C.cyan, body: "持续观察 AI 技术与任务变化，比较不同未来情景下的技能与岗位趋势。", foot: "技术信号 → 技能与任务趋势" },
    { n: "02", en: "MATCH & RESKILL", zh: "匹配与规划", accent: C.purple, body: "结合个人能力与目标岗位，识别差距，生成可执行的个性化学习路径。", foot: "个人起点 → 未来岗位与路线" },
    { n: "03", en: "CONNECT TO THE SDGs", zh: "可持续发展连接", accent: C.green, body: "展示岗位、技能与工程项目如何对应联合国 17 项可持续发展目标。", foot: "职业与项目 → SDG 具体目标" },
  ];
  blocks.forEach((b, i) => {
    const x = colX[i];
    card(slide, x, 2.72, colW, 2.82, { accent: b.accent });
    txt(slide, b.n, x + 0.25, 2.99, 0.42, 0.26, 10, b.accent, { bold: true, charSpacing: 1.1 });
    txt(slide, b.en, x + 0.8, 3.0, 2.45, 0.2, 7.8, C.muted, { bold: true, charSpacing: 1.0 });
    txt(slide, b.zh, x + 0.25, 3.48, 3.0, 0.45, 19, C.white, { bold: true });
    txt(slide, b.body, x + 0.27, 4.06, 3.03, 0.78, 10.4, C.text, { valign: "top", breakLine: false, lineSpacingMultiple: 1.12 });
    line(slide, x + 0.26, 5.05, x + 3.31, 5.05, C.line, 0.8);
    txt(slide, b.foot, x + 0.27, 5.17, 3.0, 0.22, 8.8, b.accent, { bold: true });
    if (i < 2) {
      circle(slide, x + colW + 0.08, 3.98, 0.3, "171E3A", "393659");
      txt(slide, "›", x + colW + 0.12, 3.96, 0.2, 0.25, 18, C.purple, { bold: true, align: "center" });
    }
  });
  rect(slide, 0.68, 5.95, 11.35, 0.47, "111831", 0.12);
  txt(slide, "核心原则", 0.91, 6.08, 0.9, 0.18, 8.7, C.orange, { bold: true });
  txt(slide, "趋势有来源 · 匹配看个人 · 路径能调整 · SDG 关联说明贡献与风险", 1.9, 6.06, 9.8, 0.22, 10.2, C.text);
}

// 04 — Tracking and scenarios, all metric counts from the current prototype.
{
  const slide = pptx.addSlide("NEXTEP");
  heading(slide, "01  /  TRACK", "先看技术与任务，别把趋势误读成命运", "追踪 AI 技术信号；在多个情景中观察任务、技能与岗位需求可能如何变化。", 4);
  const stats = [
    { x: 0.7, n: "12", label: "技术前沿", c: C.cyan },
    { x: 2.75, n: "2024—2030", label: "情景观察窗口", c: C.purple },
    { x: 5.45, n: "3", label: "可比较情景", c: C.orange },
  ];
  stats.forEach((s) => {
    card(slide, s.x, 2.62, 2.35, 0.96);
    txt(slide, s.n, s.x + 0.2, 2.77, 1.95, 0.34, s.n.length > 3 ? 17 : 24, s.c, { bold: true });
    txt(slide, s.label, s.x + 0.22, 3.2, 1.95, 0.18, 9, C.muted);
  });
  card(slide, 8.25, 2.56, 3.76, 3.62, { line: C.panel2 });
  txt(slide, "三种未来假设", 8.55, 2.85, 3.1, 0.32, 15.5, C.white, { bold: true });
  const scenarios = [
    ["渐进协作", C.cyan, "人机协作逐步深化"],
    ["AI 加速应用", C.purple, "采用节奏更快"],
    ["绿色转型投入", C.green, "绿色投入成为驱动"],
  ];
  scenarios.forEach((s, i) => {
    const y = 3.45 + i * 0.72;
    circle(slide, 8.58, y + 0.045, 0.15, s[1]);
    txt(slide, s[0], 8.86, y, 1.5, 0.24, 10.6, C.white, { bold: true });
    txt(slide, s[2], 10.2, y, 1.45, 0.24, 8.5, C.muted, { align: "right" });
    if (i < 2) line(slide, 8.58, y + 0.48, 11.65, y + 0.48, C.line, 0.65);
  });
  rect(slide, 8.55, 5.68, 3.1, 0.29, "20203D", 0.1);
  txt(slide, "情景参数是模型假设，不是实测采用率", 8.66, 5.73, 2.88, 0.15, 7.7, C.orange);

  txt(slide, "从信号到技能", 0.73, 3.93, 2.2, 0.29, 13, C.white, { bold: true });
  const steps = [
    ["研究信号", "arXiv 季度记录", C.cyan],
    ["任务变化", "被替代 · 增强 · 新增", C.purple],
    ["技能趋势", "随情景对比", C.green],
  ];
  steps.forEach((s, i) => {
    const x = 0.74 + i * 2.27;
    card(slide, x, 4.52, 1.95, 1.08, { fill: "10172F", accent: s[2] });
    txt(slide, s[0], x + 0.2, 4.68, 1.55, 0.25, 11.5, C.white, { bold: true });
    txt(slide, s[1], x + 0.2, 5.05, 1.58, 0.2, 8.3, C.muted);
    if (i < 2) txt(slide, "→", x + 1.99, 4.88, 0.27, 0.23, 15, C.purple, { bold: true, align: "center" });
  });
  txt(slide, "研究论文计数反映研究活跃度，不等同于产业采用、招聘需求或预测准确率。", 0.74, 5.9, 7.25, 0.23, 8.6, C.muted, { italic: true });
}

// 05 — Matching combines two separate considerations.
{
  const slide = pptx.addSlide("NEXTEP");
  heading(slide, "02  /  MATCH", "把“我适合什么”与“未来需要什么”分开看", "个人适配依据已确认的能力；岗位前景依据情景模型与标注的区域证据。", 5);
  const x = 0.9, y = 2.72, w = 6.0, h = 3.25;
  txt(slide, "岗位前景：高", x + 0.1, y - 0.3, 1.4, 0.18, 8.6, C.muted, { bold: true });
  txt(slide, "岗位前景：较低", x + 0.1, y + h + 0.12, 1.5, 0.18, 8.1, C.muted, { bold: true });
  txt(slide, "个人能力适配度：低  →  高", x + 2.6, y + h + 0.12, 3.25, 0.18, 8.6, C.muted, { bold: true, align: "right" });
  const quadrants = [
    { x, y, label: "规划能力提升", detail: "岗位前景较高，识别技能差距", c: C.blue },
    { x: x + w / 2 + 0.025, y, label: "优先探索", detail: "能力适配与岗位前景均可参考", c: C.green },
    { x, y: y + h / 2 + 0.025, label: "重新评估方向", detail: "补充证据或比较其他角色", c: C.orange },
    { x: x + w / 2 + 0.025, y: y + h / 2 + 0.025, label: "能力可迁移", detail: "目前适配较高，前景仍需比较", c: C.purple },
  ];
  quadrants.forEach((q) => {
    rect(slide, q.x, q.y, w / 2 - 0.04, h / 2 - 0.04, "111831", 0.11, "1E2946");
    circle(slide, q.x + 0.2, q.y + 0.24, 0.13, q.c);
    txt(slide, q.label, q.x + 0.42, q.y + 0.2, 2.12, 0.24, 10.2, C.white, { bold: true });
    txt(slide, q.detail, q.x + 0.22, q.y + 0.63, 2.45, 0.2, 8.2, C.muted);
  });
  line(slide, x + w / 2, y + 0.07, x + w / 2, y + h - 0.07, "3B4564", 0.85);
  line(slide, x + 0.07, y + h / 2, x + w - 0.07, y + h / 2, "3B4564", 0.85);

  card(slide, 7.43, 2.74, 4.47, 3.3, { accent: C.purple });
  txt(slide, "岗位目录与推荐", 7.75, 3.02, 3.8, 0.33, 16, C.white, { bold: true });
  txt(slide, "16", 7.75, 3.55, 0.75, 0.5, 28, C.purple, { bold: true });
  txt(slide, "类岗位角色", 8.5, 3.69, 1.25, 0.22, 10.5, C.text);
  pill(slide, "其中 4 类为新兴角色", 9.76, 3.65, 1.86, C.cyan);
  line(slide, 7.78, 4.29, 11.57, 4.29, C.line, 0.75);
  txt(slide, "可调推荐权重", 7.8, 4.51, 1.4, 0.24, 9.2, C.muted);
  txt(slide, "适配 60%", 9.26, 4.47, 1.03, 0.25, 10.2, C.cyan, { bold: true, align: "center" });
  txt(slide, "前景 40%", 10.45, 4.47, 1.1, 0.25, 10.2, C.purple, { bold: true, align: "center" });
  rect(slide, 7.81, 4.9, 3.75, 0.09, "242E4D", 0.04);
  rect(slide, 7.81, 4.9, 2.25, 0.09, C.cyan, 0.04);
  txt(slide, "默认组合；用户可调整。目标收藏不增加评分。", 7.82, 5.28, 3.85, 0.22, 8.7, C.text);
  txt(slide, "匹配分不是录用概率、工资预测或职业消失概率。", 0.95, 6.47, 10.8, 0.2, 9.2, C.orange, { bold: true });
}

// 06 — Personalised reskilling pathways.
{
  const slide = pptx.addSlide("NEXTEP");
  heading(slide, "03  /  RESKILL", "从技能差距，到有先后顺序的学习计划", "路径不只回答“学什么”，也纳入前置关系、时间、偏好与可交付成果。", 6);
  const steps = [
    { n: "01", title: "明确目标", sub: "选择目标岗位 / 原岗升级", c: C.cyan },
    { n: "02", title: "识别差距", sub: "从个人能力与需求出发", c: C.purple },
    { n: "03", title: "安排学习", sub: "按前置关系与阶段排序", c: C.orange },
    { n: "04", title: "规划节奏", sub: "结合日期、工时与偏好", c: C.green },
    { n: "05", title: "完成项目", sub: "用工程成果连接 SDG", c: C.pink },
  ];
  line(slide, 1.22, 3.38, 11.77, 3.38, "384362", 1.4);
  steps.forEach((s, i) => {
    const cx = 1.34 + i * 2.47;
    circle(slide, cx - 0.23, 3.15, 0.46, "131A35", s.c);
    circle(slide, cx - 0.105, 3.275, 0.21, s.c);
    txt(slide, s.n, cx - 0.28, 2.72, 0.56, 0.2, 8.8, s.c, { bold: true, align: "center" });
    txt(slide, s.title, cx - 0.85, 3.82, 1.7, 0.31, 11.2, C.white, { bold: true, align: "center" });
    txt(slide, s.sub, cx - 1.0, 4.23, 2.0, 0.44, 8.1, C.muted, { align: "center", valign: "top" });
  });
  card(slide, 0.76, 5.15, 3.7, 0.95);
  txt(slide, "30", 1.02, 5.34, 0.67, 0.38, 23, C.cyan, { bold: true });
  txt(slide, "项技能目录", 1.78, 5.4, 1.5, 0.22, 11, C.white, { bold: true });
  txt(slide, "能力目标与岗位要求对齐", 2.88, 5.43, 1.3, 0.18, 7.8, C.muted, { align: "right" });
  card(slide, 4.81, 5.15, 3.7, 0.95);
  txt(slide, "96", 5.07, 5.34, 0.67, 0.38, 23, C.purple, { bold: true });
  txt(slide, "项任务定义", 5.83, 5.4, 1.5, 0.22, 11, C.white, { bold: true });
  txt(slide, "解释岗位如何发生变化", 6.94, 5.43, 1.35, 0.18, 7.8, C.muted, { align: "right" });
  card(slide, 8.85, 5.15, 3.7, 0.95);
  txt(slide, "17", 9.11, 5.34, 0.67, 0.38, 23, C.green, { bold: true });
  txt(slide, "个工程项目", 9.87, 5.4, 1.5, 0.22, 11, C.white, { bold: true });
  txt(slide, "以实践连接目标", 11.13, 5.43, 1.13, 0.18, 7.8, C.muted, { align: "right" });
  txt(slide, "路径可导出、可追踪进度；模拟提升假设不等于技能已被验证。", 0.79, 6.43, 11.3, 0.2, 9.1, C.orange);
}

// 07 — SDGs connected at the target and project level.
{
  const slide = pptx.addSlide("NEXTEP");
  heading(slide, "04  /  SDG IMPACT", "让“职业有意义”落到具体目标与工程项目", "不把每个岗位强行对应所有目标；说明潜在贡献，同时披露风险与证据状态。", 7);
  const sdgPalette = ["E5243B", "DDA63A", "4C9F38", "C5192D", "FF3A21", "26BDE2", "FCC30B", "A21942", "FD6925", "DD1367", "FD9D24", "BF8B2E", "3F7E44", "0A97D9", "56C02B", "00689D", "19486A"];
  const startX = 0.88, startY = 2.78, cell = 0.43, gap = 0.21;
  for (let i = 0; i < 17; i++) {
    const row = Math.floor(i / 9);
    const col = i % 9;
    const x = startX + col * (cell + gap);
    const y = startY + row * 0.78;
    rect(slide, x, y, cell, cell, sdgPalette[i], 0.09, sdgPalette[i]);
    txt(slide, String(i + 1).padStart(2, "0"), x + 0.02, y + 0.09, cell - 0.04, 0.16, 9, C.white, { bold: true, align: "center" });
  }
  txt(slide, "17", 9.2, 2.65, 1.05, 0.7, 42, C.white, { bold: true });
  txt(slide, "项联合国可持续发展目标", 10.12, 2.88, 2.2, 0.25, 12, C.text, { bold: true });
  line(slide, 9.22, 3.64, 12.03, 3.64, C.line, 0.75);
  const metrics = [
    { n: "35", label: "个相关子目标条目", c: C.cyan },
    { n: "111", label: "条岗位、技能与项目关联", c: C.purple },
  ];
  metrics.forEach((m, i) => {
    const y = 3.9 + i * 0.84;
    txt(slide, m.n, 9.24, y, 0.93, 0.36, 20, m.c, { bold: true });
    txt(slide, m.label, 10.28, y + 0.07, 1.8, 0.21, 9.6, C.white, { bold: true });
  });
  card(slide, 0.9, 4.67, 7.4, 1.15, { accent: C.green });
  txt(slide, "从技能到贡献", 1.2, 4.9, 1.6, 0.27, 12.4, C.white, { bold: true });
  txt(slide, "角色需求 → 所需技能 → 工程项目 → 具体 SDG 子目标", 3.0, 4.92, 4.8, 0.22, 10.5, C.green, { bold: true });
  txt(slide, "覆盖的是当前目录中的相关子目标，不代表覆盖全部 169 个子目标。关联与强度属于团队假设，并非联合国背书。", 0.94, 6.1, 11.2, 0.34, 8.9, C.muted, { valign: "top" });
}

// 08 — A simple walkthrough for a user.
{
  const slide = pptx.addSlide("NEXTEP");
  heading(slide, "THE USER JOURNEY", "从“我想转型”到下一步行动", "NEXTEP 把复杂问题拆解为可理解、可确认、可调整的几个步骤。", 8);
  const flow = [
    { n: "01", name: "分享起点", detail: "经历 · 能力 · 地区", color: C.cyan },
    { n: "02", name: "确认画像", detail: "目标与已掌握技能", color: C.blue },
    { n: "03", name: "比较岗位", detail: "适配与前景分开展示", color: C.purple },
    { n: "04", name: "安排学习", detail: "差距 · 依赖 · 时间", color: C.orange },
    { n: "05", name: "实践进展", detail: "项目 · 进度 · 导出", color: C.green },
  ];
  flow.forEach((s, i) => {
    const y = 2.68 + i * 0.66;
    if (i < flow.length - 1) line(slide, 1.0, y + 0.4, 1.0, y + 0.94, "3B4565", 1.0);
    circle(slide, 0.79, y + 0.03, 0.43, "161E3C", s.color);
    txt(slide, s.n, 0.83, y + 0.14, 0.35, 0.13, 7.7, s.color, { bold: true, align: "center" });
    txt(slide, s.name, 1.45, y, 1.55, 0.25, 12.2, C.white, { bold: true });
    txt(slide, s.detail, 3.02, y + 0.02, 2.55, 0.22, 9.4, C.muted);
    if (i < flow.length - 1) line(slide, 1.46, y + 0.49, 5.6, y + 0.49, C.line, 0.6);
  });
  card(slide, 6.56, 2.72, 5.23, 3.4, { accent: C.purple });
  txt(slide, "你始终保有选择权", 6.91, 3.04, 4.35, 0.34, 18, C.white, { bold: true });
  dotList(slide, [
    "目标岗位可以比较，不必只选一个",
    "技能画像由本人确认，不替你自动定论",
    "学习路径按时间与资源偏好调整",
    "个人进度与资料保存在本机",
  ], 6.97, 3.66, 4.25, { gap: 0.47, size: 10.2, color: C.purple });
  rect(slide, 6.92, 5.64, 4.45, 0.29, "1C2340", 0.1);
  txt(slide, "解释透明  ·  路径可调  ·  进度由自己记录", 7.08, 5.69, 4.15, 0.17, 8.7, C.cyan, { bold: true, align: "center" });
}

// 09 — Evidence, limitations and privacy.
{
  const slide = pptx.addSlide("NEXTEP");
  heading(slide, "TRUST & LIMITS", "可信的职业工具，也要说明自己不知道什么", "把数据来源、合成假设、隐私边界与模型限制放在台面上。", 9);
  const cols = [
    {
      x: 0.72, accent: C.cyan, title: "证据与模型",
      points: [
        ["就业目录", "默认岗位与地区指标为明确标注的合成演示"],
        ["研究记录", "arXiv 来源与抓取时间逐条保留；缺失条目标注合成"],
        ["趋势推演", "技术曲线与任务效应是情景假设，未训练就业预测模型"],
        ["SDG 关联", "目标定义状态分明；岗位与项目连接属于团队假设"],
      ],
    },
    {
      x: 6.73, accent: C.purple, title: "隐私与使用边界",
      points: [
        ["本地简历解析", "文件和完整原文不持久化、不上传"],
        ["本机保存", "结构化画像、对话与进度保存在浏览器"],
        ["AI 助手", "外部 AI 默认关闭；需明确同意后才可启用"],
        ["使用定位", "支持自主探索；不用于招聘决策或影响认证"],
      ],
    },
  ];
  cols.forEach((col) => {
    card(slide, col.x, 2.62, 5.72, 3.66, { accent: col.accent });
    txt(slide, col.title, col.x + 0.29, 2.89, 4.95, 0.32, 15.5, C.white, { bold: true });
    col.points.forEach((p, i) => {
      const yy = 3.46 + i * 0.61;
      pill(slide, p[0], col.x + 0.3, yy, 1.28, col.accent, "1A2140");
      txt(slide, p[1], col.x + 1.75, yy + 0.025, 3.47, 0.28, 8.8, C.text, { valign: "mid" });
    });
  });
  txt(slide, "匹配分不是录用概率；研究计数不是市场需求；路径完成不等于岗位胜任。", 0.82, 6.47, 11.0, 0.22, 10.2, C.orange, { bold: true, align: "center" });
}

// 10 — Close with a clear, realistic next step.
{
  const slide = pptx.addSlide("NEXTEP");
  brand(slide, 0.74, 0.55);
  txt(slide, "从可解释的探索，\n走向可验证的转型。", 0.78, 1.63, 8.65, 1.35, 34, C.white, { bold: true, lineSpacingMultiple: 1.08 });
  txt(slide, "让每个人看见技术变化、理解自己的选择，\n并把工程技能连接到一个更可持续的未来。", 0.83, 3.27, 7.9, 0.72, 15, C.text, { valign: "top", lineSpacingMultiple: 1.18 });
  const next = [
    { x: 0.83, title: "现在", desc: "追踪技术与任务变化", c: C.cyan },
    { x: 4.7, title: "接着", desc: "生成个性化学习路线", c: C.purple },
    { x: 8.57, title: "再向前", desc: "连接 SDG 与真实证据", c: C.green },
  ];
  next.forEach((n, i) => {
    card(slide, n.x, 4.6, 3.46, 0.96, { accent: n.c });
    txt(slide, n.title, n.x + 0.24, 4.76, 0.83, 0.22, 10, n.c, { bold: true });
    txt(slide, n.desc, n.x + 1.08, 4.75, 2.15, 0.25, 10, C.white, { bold: true });
    if (i < 2) txt(slide, "→", n.x + 3.48, 4.91, 0.28, 0.25, 15, C.purple, { bold: true, align: "center" });
  });
  rect(slide, 0.84, 6.0, 10.95, 0.52, "131A34", 0.13);
  txt(slide, "下一步：用经核实的长期就业结果与领域专家反馈，校准数据与假设。", 1.08, 6.15, 10.45, 0.2, 10.5, C.text, { align: "center" });
  footer(slide, 10, "THANK YOU");
}

const outDir = path.resolve("outputs");
await fs.mkdir(outDir, { recursive: true });
const output = path.join(outDir, "NEXTEP_项目介绍.pptx");
await pptx.writeFile({ fileName: output });
console.log(`Wrote ${output}`);
