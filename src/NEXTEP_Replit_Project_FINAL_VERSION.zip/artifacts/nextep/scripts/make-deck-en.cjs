const P=require("pptxgenjs");const p=new P();p.layout="LAYOUT_WIDE";
const BG="0B0B24",CARD="1A1A40",INK="FFFFFF",MUT="A9A9D0",ACC="8B7CFF",ACC2="5CE1E6",F="Calibri";
function base(t,k){const s=p.addSlide();s.background={color:BG};
 s.addText("NEXTEP",{x:.5,y:.25,w:3,h:.3,fontFace:F,fontSize:11,bold:true,color:ACC,charSpacing:4});
 if(k)s.addText(k,{x:9,y:.25,w:3.8,h:.3,fontFace:F,fontSize:10,color:MUT,align:"right"});
 if(t)s.addText(t,{x:.5,y:.7,w:12.3,h:.9,fontFace:F,fontSize:30,bold:true,color:INK,valign:"top"});return s;}
function card(s,x,y,w,h,head,body,col){s.addShape("roundRect",{x,y,w,h,fill:{color:CARD},line:{color:col||ACC,width:1},rectRadius:.1});
 s.addText(head,{x:x+.2,y:y+.15,w:w-.4,h:.5,fontFace:F,fontSize:16,bold:true,color:col||ACC2,valign:"top"});
 s.addText(body,{x:x+.2,y:y+.7,w:w-.4,h:h-.85,fontFace:F,fontSize:13,color:INK,valign:"top",paraSpaceAfter:4});}
// 1 title
let s=p.addSlide();s.background={color:BG};
s.addText("NEXTEP",{x:.8,y:2,w:11,h:1.3,fontFace:F,fontSize:72,bold:true,color:INK,charSpacing:6});
s.addText("Engineer your future.",{x:.8,y:3.3,w:11,h:.6,fontFace:F,fontSize:28,color:ACC});
s.addText("A career compass for students facing an AI-disrupted job market — what to aim for, and what to learn next.",{x:.8,y:4.2,w:9,h:.9,fontFace:F,fontSize:16,color:MUT});
s.addText("ENGINEERING × SUSTAINABILITY",{x:.8,y:6.4,w:8,h:.3,fontFace:F,fontSize:11,color:ACC2,charSpacing:4});
// 2 problem
s=base("Students are choosing careers in a market that is changing under them","THE PROBLEM");
card(s,.5,1.9,4,3.6,"Jobs are shifting fast","AI is automating tasks and creating new roles at the same time.\n\nDegrees take 3–4 years; skill demand can change faster than that.");
card(s,4.7,1.9,4,3.6,"Advice is outdated","Career guidance is built on today's job titles, not tomorrow's.\n\nStudents can't see which skills will grow and which will fade.");
card(s,8.9,1.9,4,3.6,"The result: uncertainty","Students don't know what to study, which goals to set, or how their work will matter.\n\nMany learn the wrong things, or freeze.");
s.addText("The question NEXTEP answers: “What should I aim for, and what should I learn, so my career still matters in 10 years?”",{x:.5,y:5.9,w:12.3,h:.8,fontFace:F,fontSize:16,italic:true,color:ACC});
// 3 what is
s=base("NEXTEP: a future-career explorer built for students","WHAT IT IS");
s.addText("An interactive web app where students explore electronic engineering careers, see how they are changing with AI, and get a clear path to build the skills those careers need.",{x:.5,y:1.8,w:12.3,h:1,fontFace:F,fontSize:18,color:MUT});
card(s,.5,3.1,4,2.8,"1  Know the future","Track AI progress and see which roles and skills are rising or declining.");
card(s,4.7,3.1,4,2.8,"2  Set the right goals","Match your interests and strengths to future-proof roles and meaningful goals.");
card(s,8.9,3.1,4,2.8,"3  Learn what's next","Get a personalised reskilling roadmap of the new things to learn, step by step.");
// 4 tracking
s=base("Pillar 1 — Track and forecast how AI reshapes work","KNOW THE FUTURE");
card(s,.5,1.9,6,3.9,"What students see","• Continuous tracking of AI technology progress\n• Roles and skills forecast to grow, evolve or decline\n• Plain-language explanation of why each shift happens\n• A view of the field, not just a single job title");
card(s,6.8,1.9,6,3.9,"Why it matters to a student","• Choose electives and projects with evidence, not guesswork\n• Spot opportunities before they become crowded\n• Avoid investing years in skills that are fading\n• Replace career anxiety with a clear picture",ACC2);
// 5 goals
s=base("Pillar 2 — Goals worth pursuing in a time of disruption","SET THE RIGHT GOALS");
s.addText("When job titles are unstable, durable goals matter more than a fixed destination.",{x:.5,y:1.7,w:12.3,h:.5,fontFace:F,fontSize:16,color:MUT});
card(s,.5,2.4,4,3.4,"Aim for capabilities","Target skill clusters (e.g. embedded systems, AI hardware, power electronics) that carry over between roles.");
card(s,4.7,2.4,4,3.4,"Aim for adaptability","Build the habit of learning: fundamentals first, then specialisations that can be swapped as the market moves.");
card(s,8.9,2.4,4,3.4,"Aim for purpose","Connect your career to problems that matter, anchored in the UN Sustainable Development Goals.");
// 6 matching
s=base("Matching students to future roles","SET THE RIGHT GOALS");
const steps=[["Explore","Browse future roles in electronic engineering"],["Compare","See required skills, outlook and AI impact"],["Match","Align roles with your interests and strengths"],["Choose","Pick a goal with a clear next step"]];
steps.forEach((a,i)=>{const x=.5+i*3.1;s.addShape("roundRect",{x,y:2.2,w:2.8,h:2.6,fill:{color:CARD},line:{color:ACC,width:1},rectRadius:.1});
 s.addText(String(i+1),{x:x+.2,y:2.3,w:.8,h:.6,fontFace:F,fontSize:28,bold:true,color:ACC});
 s.addText(a[0],{x:x+.2,y:2.95,w:2.4,h:.4,fontFace:F,fontSize:18,bold:true,color:INK});
 s.addText(a[1],{x:x+.2,y:3.4,w:2.4,h:1.3,fontFace:F,fontSize:13,color:MUT,valign:"top"});});
s.addText("Roles are presented as directions to explore, not fixed predictions of a single outcome.",{x:.5,y:5.4,w:12.3,h:.5,fontFace:F,fontSize:14,italic:true,color:MUT});
// 7 reskilling
s=base("Pillar 3 — A personalised roadmap of what to learn next","LEARN WHAT'S NEXT");
card(s,.5,1.9,4,3.9,"Start from where you are","Current course, skills and interests set the starting point, so the roadmap is realistic.");
card(s,4.7,1.9,4,3.9,"See the skill gap","Compare your skills to your target role and spot what's missing, ordered by priority.");
card(s,8.9,1.9,4,3.9,"Follow a step-by-step path","Foundations → new technologies → hands-on projects, with a clear sequence rather than a long list.");
s.addText("Includes new areas students rarely meet in class: AI-enabled design, edge AI, sustainable electronics and more.",{x:.5,y:6.1,w:12.3,h:.6,fontFace:F,fontSize:14,italic:true,color:ACC});
// 8 SDG
s=base("Every future role connects to the UN Sustainable Development Goals","MEANINGFUL WORK");
s.addText("17",{x:.6,y:1.9,w:3,h:1.6,fontFace:F,fontSize:96,bold:true,color:ACC});
s.addText("UN SDGs",{x:.6,y:3.5,w:3,h:.5,fontFace:F,fontSize:20,color:INK});
s.addText("Each role, skill and project is linked to the goals it helps advance — clean energy, industry and innovation, climate action, health and more.",{x:4.2,y:1.9,w:8.6,h:1.2,fontFace:F,fontSize:17,color:INK,valign:"top"});
card(s,4.2,3.4,4.2,2.4,"For students","Choose work you can believe in and see the real-world impact of the skills you learn.");
card(s,8.6,3.4,4.2,2.4,"For the future","Engineering talent directed toward sustainability, not only toward the latest technology.",ACC2);
// 9 journey
s=base("A student's journey with NEXTEP","HOW IT WORKS");
const j=["Open the explorer","Discover rising and declining roles","Match to a future role","Set a purposeful goal","Follow the learning roadmap","Revisit as the market changes"];
j.forEach((t,i)=>{const x=.5+(i%3)*4.15,y=1.9+Math.floor(i/3)*2.1;s.addShape("roundRect",{x,y,w:3.9,h:1.8,fill:{color:CARD},line:{color:i%2?ACC2:ACC,width:1},rectRadius:.1});
 s.addText(String(i+1),{x:x+.2,y:y+.15,w:.7,h:.6,fontFace:F,fontSize:26,bold:true,color:ACC});
 s.addText(t,{x:x+.2,y:y+.8,w:3.5,h:.8,fontFace:F,fontSize:16,color:INK,valign:"top"});});
// 10 impact
s=base("Impact: confident students, ready for what's next","VALUE");
card(s,.5,1.9,4,3.6,"Students","Clarity on goals, a concrete learning plan, and less anxiety about AI.");
card(s,4.7,1.9,4,3.6,"Universities & educators","Insight into emerging skills to keep curricula and advice current.",ACC2);
card(s,8.9,1.9,4,3.6,"Society","A workforce prepared for change and aimed at sustainable development.");
// 11 close
s=p.addSlide();s.background={color:BG};
s.addText("Engineer your future.",{x:.8,y:2.4,w:11.5,h:1,fontFace:F,fontSize:48,bold:true,color:INK});
s.addText("Know what's coming. Set the right goals. Learn what's next.",{x:.8,y:3.5,w:11.5,h:.6,fontFace:F,fontSize:22,color:ACC});
s.addText("NEXTEP",{x:.8,y:6.4,w:4,h:.4,fontFace:F,fontSize:14,bold:true,color:ACC2,charSpacing:4});
p.writeFile({fileName:"outputs/NEXTEP_Project_Overview_EN.pptx"}).then(()=>console.log("ok"));
