// English roadshow deck: problem, solution, technical method and expected,
// testable impact. Keeps the project's established photo-led visual language.
const P = require('pptxgenjs');
const fs = require('fs');
const path = require('path');
const p = new P();
p.layout = 'LAYOUT_WIDE';
p.author = 'NEXTEP';
p.company = 'NEXTEP';
p.title = 'NEXTEP — EEE Student Futures | Roadshow Pitch';
p.subject = 'Problem, solution, technical method and proposed impact';
p.lang = 'en-GB';
p.theme = { headFontFace: 'DejaVu Sans', bodyFontFace: 'DejaVu Sans', lang: 'en-GB' };

const C = {
  navy:'101C35', ink:'18243A', paper:'F7F6F2', white:'FFFFFF',
  purple:'7464EE', lavender:'E8E3FF', mint:'B7E4D0', teal:'137C72',
  orange:'FFB18B', coral:'DC644B', muted:'626C7A', pale:'E8EBEE',
  dark:'1E2D48',
};
const sdgData = JSON.parse(fs.readFileSync('data/sdg-impact.json', 'utf8'));
const W = 13.333333;
const F = 'DejaVu Sans';
const image = name => path.join('outputs/nextep-assets', `${name}.jpg`);
let page = 0;

function rect(s,x,y,w,h,fill,line=fill,r=0) {
  s.addShape(r ? 'roundRect' : 'rect', {
    x,y,w,h,rectRadius:r,radius:r,fill:{color:fill},line:{color:line,width:0},
  });
}
function text(s,value,x,y,w,h,size=16,color=C.ink,bold=false,extra={}) {
  s.addText(value,{
    x,y,w,h,fontFace:F,fontSize:size,color,bold,margin:0,
    valign:'mid',breakLine:false,fit:'shrink',...extra,
  });
}
function line(s,x,y,w,color=C.pale,width=1) {
  s.addShape('line',{x,y,w,h:0,line:{color,width,beginArrowType:'none',endArrowType:'none'}});
}
function photo(s,name,x,y,w,h) {
  s.addImage({path:image(name),x,y,w,h,sizing:{type:'cover',w,h}});
}
function chip(s,x,y,size=.21,col=C.purple) {
  rect(s,x,y,size,size,col);
  for(let i=0;i<3;i++){
    const q=size*(i+1)/4;
    rect(s,x-.045,y+q,.045,.018,col);rect(s,x+size,y+q,.045,.018,col);
    rect(s,x+q,y-.045,.018,.045,col);rect(s,x+q,y+size,.018,.045,col);
  }
}
function base(section,dark=false) {
  const s=p.addSlide();page++;s.background={color:dark?C.navy:C.paper};
  const ink=dark?C.white:C.ink;
  chip(s,.57,.35,.21,dark?C.mint:C.purple);
  text(s,'NEXTEP',.94,.28,2,.34,13,ink,true,{charSpacing:1.9});
  text(s,section.toUpperCase(),7.3,.3,5.4,.28,9,dark?'BCC6D5':C.muted,false,{align:'right',charSpacing:1.2});
  line(s,.58,7.04,12.16,dark?'34415A':'D9DDE0',.7);
  text(s,'engineer your future  /  ROADSHOW',.58,7.13,7,.18,8,dark?'B7C1D0':C.muted);
  text(s,String(page).padStart(2,'0'),12.18,7.1,.56,.22,9,dark?'B7C1D0':C.muted,false,{align:'right'});
  return s;
}
function title(s,head,sub='',dark=false) {
  text(s,head,.62,.98,12.05,1.06,29,dark?C.white:C.ink,true,{valign:'top'});
  if(sub)text(s,sub,.64,2.09,11.93,.48,13,dark?'BCC6D5':C.muted,false,{valign:'top'});
}
function pill(s,label,x,y,w,fill=C.lavender,ink=C.purple) {
  rect(s,x,y,w,.34,fill,fill,.12);
  text(s,label,x+.13,y+.025,w-.26,.27,9,ink,true);
}
function card(s,{x,y,w,h,kicker,head,body,color=C.lavender,accent=C.purple,bodySize=14}) {
  rect(s,x,y,w,h,color);
  text(s,kicker,x+.22,y+.19,w-.44,.27,9,accent,true,{charSpacing:1.2});
  text(s,head,x+.22,y+.57,w-.44,.65,18,C.ink,true,{valign:'top'});
  text(s,body,x+.22,y+1.34,w-.44,h-1.52,bodySize,C.ink,false,{valign:'top'});
}
function note(s,value,dark=false) {
  text(s,value,.66,6.64,12,.25,9,dark?'BCC6D5':C.muted,false,{valign:'mid'});
}
if (sdgData.goals.length !== 17 || sdgData.goals.some((g,i)=>g.id!==i+1 || typeof g.name.en!=='string')) {
  throw new Error('The current verified SDG list did not match the complete set of 17 goal names.');
}

// 01 — Promise and target audience.
{
  const s=base('EEE student futures / pitch',true);
  photo(s,'students',7.12,.85,5.6,5.92);
  rect(s,7.12,5.59,5.6,1.18,C.mint);
  text(s,'A clearer next step for EEE students.',7.42,5.83,4.95,.34,15,C.ink,true);
  text(s,'A career compass for Electrical & Electronic Engineering.',7.42,6.26,4.9,.25,11,C.ink);
  pill(s,'STUDENT FUTURES  /  ROADSHOW PITCH',.65,1.10,4.0,C.dark,C.mint);
  text(s,'Engineer\nyour future.',.6,1.86,6.2,1.82,43,C.white,true,{valign:'top'});
  text(s,'AI-era careers. EEE skills.\nPersonalised paths to learn and build.',.67,3.94,5.95,.85,21,C.orange,true,{valign:'top'});
  text(s,'From a changing labour market to a next step that makes sense for the student—and the problems they want to solve.',.68,5.45,5.93,.84,14,'BEC9D9',false,{valign:'top'});
  s.addNotes('Opening premise: NEXTEP is exclusively focused on Electrical and Electronic Engineering students. The photography is illustrative, not a depiction of NEXTEP users.');
}

// 02 — The problem: linked student decisions, not a generic AI scare story.
{
  const s=base('01 / The problem');
  title(s,'The hard questions arrive before the job title is clear.','AI changes tasks. Students still have to choose what to learn before the future is certain.');
  photo(s,'study',.65,2.72,4.52,3.52);
  rect(s,.65,5.44,4.52,.8,C.navy);
  text(s,'“Where should I focus next?”',.91,5.65,4.04,.36,15,C.white,true);
  const rows=[
    ['01','What is changing?','New tools can change how EEE work is done, but signals are scattered.'],
    ['02','Where do I fit?','Broad job boards do not connect a student’s skills to EEE role requirements.'],
    ['03','What do I learn next?','Course lists rarely explain the order, practice and project needed to close a gap.'],
  ];
  rows.forEach((r,i)=>{
    const y=2.77+i*1.12;
    text(s,r[0],5.55,y,.5,.38,16,[C.coral,C.purple,C.teal][i],true);
    text(s,r[1],6.15,y,6.1,.35,17,C.ink,true);
    text(s,r[2],6.15,y+.43,6.0,.53,13,C.muted,false,{valign:'top'});
    if(i<2)line(s,6.15,y+.98,6.05,'D9DDE0',.65);
  });
  note(s,'NEXTEP frames career uncertainty as a decision-support problem—not proof that AI will eliminate particular jobs.');
}

// 03 — The solution, in one student-centred flow.
{
  const s=base('02 / The solution',true);
  title(s,'One EEE-focused journey from signals to action.','Students can revisit the pathway as their skills, interests and evidence change.',true);
  const cards=[
    {kicker:'01  /  TRACK',head:'Understand change',body:'Explore AI developments, affected engineering tasks and possible shifts in skills and roles.',color:C.lavender,accent:C.purple},
    {kicker:'02  /  MATCH',head:'Choose a direction',body:'Compare a student’s confirmed strengths and interests with the skills needed in EEE roles.',color:C.mint,accent:C.teal},
    {kicker:'03  /  PLAN',head:'Learn with purpose',body:'Turn skill gaps into a sequenced reskilling pathway, a practical project and relevant SDG links.',color:C.orange,accent:C.coral},
  ];
  cards.forEach((a,i)=>card(s,{...a,x:.65+i*4.13,y:3.0,w:3.78,h:2.9,bodySize:13}));
  text(s,'Signals  →  role fit  →  skill gap  →  learning plan  →  relevant SDGs',.68,6.26,11.9,.3,14,C.mint,true);
}

// 04 — Why the EEE-only focus is a product differentiator.
{
  const s=base('03 / Why EEE');
  title(s,'Not every degree. Deeper guidance for EEE.','A single-discipline scope makes the pathway technically specific, rather than a cross-major checklist.');
  photo(s,'circuit',.65,2.72,4.55,3.48);
  const items=[
    ['EEE role context','Embedded systems, power, electronics, communications and verification.'],
    ['Connected skill map','Relate technologies to engineering tasks, prerequisites and role capabilities.'],
    ['Useful next step','Prioritise a realistic skill gap and build evidence through a hands-on project.'],
  ];
  items.forEach((r,i)=>{
    const y=2.86+i*1.12;
    rect(s,5.55,y,.13,.76,[C.purple,C.teal,C.coral][i]);
    text(s,r[0],5.9,y,6.4,.3,17,C.ink,true);
    text(s,r[1],5.9,y+.38,6.32,.47,13,C.muted,false,{valign:'top'});
  });
  rect(s,5.55,6.07,6.87,.48,C.lavender);
  text(s,'EEE is the core market—not a temporary starting category.',5.76,6.17,6.48,.25,12,C.ink,true);
}

// 05 — The technical method and explicit boundaries.
{
  const s=base('04 / Technical method',true);
  title(s,'A transparent pipeline—not a black-box career verdict.','Evidence is linked to role tasks, student skills and a plan the student can inspect.',true);
  const steps=[
    ['1','Evidence','EEE research signals, role and skill catalogs, and a fixed job-posting sample.',C.lavender,C.purple],
    ['2','Scenarios','Map technologies to affected tasks; compare assumption-led skill and role outlooks.',C.mint,C.teal],
    ['3','Student match','Compare confirmed profile skills with role needs; keep personal fit separate from outlook.',C.orange,C.coral],
    ['4','Learning pathway','Order skill gaps by prerequisites, available study time and a project that demonstrates learning.',C.lavender,C.purple],
    ['5','Purpose links','Connect EEE roles and projects to relevant SDGs and targets across the full 17-goal framework.',C.mint,C.teal],
  ];
  steps.forEach((a,i)=>{
    const y=2.63+i*.69;
    rect(s,.68,y,.48,.48,a[4]);
    text(s,a[0],.68,y+.09,.48,.26,13,C.ink,true,{align:'center'});
    text(s,a[1],1.42,y,2.22,.34,15,C.white,true);
    text(s,a[2],3.76,y,8.65,.44,12.2,'D0D7E3',false,{valign:'top'});
    if(i<4)line(s,1.42,y+.55,10.92,'34415A',.55);
  });
  rect(s,.68,6.24,11.96,.44,'27344D');
  text(s,'Research counts ≠ labour demand  ·  Scenarios ≠ job probabilities  ·  Project links ≠ certified impact',.9,6.32,11.53,.25,10,C.white,true);
  s.addNotes('The current experience is an explainable decision-support prototype. Role fit uses student-confirmed profile information and EEE role requirements. Forecast scenarios use explicit assumptions and are not calibrated hiring probabilities. Optional DeepSeek conversation is user-opt-in and disabled by default; it explains decisions without changing computed scores or progress.');
}

// 06 — One plausible student pathway, explicitly illustrative.
{
  const s=base('05 / A student example');
  title(s,'From “I like electronics” to a project worth testing.','Illustrative pathway for a student exploring embedded AI—not a real profile or hiring prediction.');
  photo(s,'study',.65,2.74,3.66,3.52);
  pill(s,'STARTING POINT',.9,2.98,1.95,C.lavender,C.purple);
  const columns=[
    {x:4.68,color:C.lavender,accent:C.purple,n:'01',head:'Strengthen foundations',body:'C/C++ · microcontrollers\nSensor interfaces · measurement'},
    {x:7.43,color:C.mint,accent:C.teal,n:'02',head:'Learn for the role',body:'On-device models\nProfiling · validation · power'},
    {x:10.18,color:C.orange,accent:C.coral,n:'03',head:'Build and show',body:'Smart-sensor prototype\nMeasure accuracy, latency and energy'},
  ];
  columns.forEach(a=>{
    rect(s,a.x,3.25,2.47,2.5,a.color);
    text(s,a.n,a.x+.2,3.43,.6,.42,21,a.accent,true);
    text(s,a.head,a.x+.2,4.08,2.06,.55,14,C.ink,true,{valign:'top'});
    text(s,a.body,a.x+.2,4.86,2.08,.7,11.5,C.ink,false,{valign:'top'});
  });
  text(s,'The sequence follows prerequisites and available study time; the student can inspect and revise each step.',4.69,6.04,7.9,.49,12,C.muted);
  note(s,'A completed project is evidence to discuss—not a guarantee of employability.');
}

// 07 — Keep all 17 goals visible, with examples marked as possible EEE routes.
{
  const s=base('06 / The complete UN SDG framework');
  title(s,'One EEE pathway. Connections across all 17 goals.','Role → skills → project → relevant Sustainable Development Goals.');
  text(s,'UN GOAL',1.37,2.46,2.87,.22,9,C.muted,true,{charSpacing:1});
  text(s,'POSSIBLE EEE EXAMPLE',4.08,2.46,2.54,.22,9,C.muted,true,{charSpacing:.7});
  text(s,'UN GOAL',7.48,2.46,2.75,.22,9,C.muted,true,{charSpacing:1});
  text(s,'POSSIBLE EEE EXAMPLE',10.08,2.46,2.57,.22,9,C.muted,true,{charSpacing:.7});
  const examples=[
    'Off-grid lighting and charging','Soil sensing and irrigation','Health and fall-alert sensors',
    'Affordable electronics learning kits','Inclusive engineering workshops','Water-quality monitoring',
    'Energy monitoring and control','Predictive maintenance projects','Open chip verification',
    'Accessible navigation devices','Community air-quality sensing','Repairable electronics',
    'Flood-warning systems','Coastal monitoring buoys','Forest acoustic monitoring',
    'Emergency communication systems','Shared engineering tools and data',
  ];
  for(let i=0;i<17;i++){
    const col=i<9?0:1, row=i<9?i:i-9;
    const x=col===0?.68:6.79, y=2.79+row*.405;
    const g=sdgData.goals[i], color=g.color.replace('#','');
    rect(s,x,y,.43,.31,color);
    text(s,String(g.id),x+.02,y+.036,.39,.22,10,C.white,true,{align:'center'});
    text(s,g.name.en,x+.55,y+.02,2.93,.28,9.6,C.ink,true);
    text(s,examples[i],x+3.48,y+.02,2.45,.28,10.3,C.muted);
  }
  note(s,'Examples suggest possible contribution routes. Mappings are team-authored; each role should connect only to relevant goals. This is not UN endorsement.');
}

// 08 — Expected impact with a measurable evaluation plan, not invented results.
{
  const s=base('07 / Expected impact');
  title(s,'The impact we expect—and how to test it.','These are intended outcomes. The prototype has not yet demonstrated them.');
  const items=[
    {x:.65,color:C.lavender,accent:C.purple,kicker:'STUDENT AGENCY',head:'Clearer career direction',body:'Expected: students can explain a target EEE role, why it fits and what is still unknown.',measure:'Measure: compare decision clarity before and after the guided journey.'},
    {x:4.78,color:C.mint,accent:C.teal,kicker:'SKILL READINESS',head:'Actionable learning',body:'Expected: students turn a skill gap into a realistic learning sequence and practical project.',measure:'Measure: review plans, project work and student follow-through.'},
    {x:8.91,color:C.orange,accent:C.coral,kicker:'SUSTAINABLE PURPOSE',head:'Purpose with evidence',body:'Expected: students link an EEE project to relevant goals—and understand its trade-offs.',measure:'Measure: assess target-level reasoning, evidence and limitations.'},
  ];
  items.forEach(a=>{
    rect(s,a.x,2.78,3.77,3.13,a.color);
    text(s,a.kicker,a.x+.23,3.0,3.31,.25,9,a.accent,true,{charSpacing:1});
    text(s,a.head,a.x+.23,3.49,3.32,.61,17,C.ink,true,{valign:'top'});
    text(s,a.body,a.x+.23,4.21,3.3,.76,12.2,C.ink,false,{valign:'top'});
    line(s,a.x+.23,5.08,3.3,'C6CDD3',.8);
    text(s,a.measure,a.x+.23,5.19,3.3,.62,10.6,C.ink,true,{valign:'top'});
  });
  rect(s,.66,6.01,12,.48,C.navy);
  text(s,'Pilot with EEE students and educators. Report participation, changes, non-completion and limitations.',.88,6.12,11.55,.25,11.4,C.white,true);
  note(s,'No student-success, employment-placement or SDG-impact results are claimed at this stage.');
}

// 09 — What is working and what needs evidence.
{
  const s=base('08 / Prototype and evidence',true);
  title(s,'A working prototype. Clear limits on the claims.','Roadshow credibility depends on distinguishing implemented features from intended impact.',true);
  const stats=[['1,998','job postings'],['25','EEE directions'],['3','Chinese cities']];
  stats.forEach((r,i)=>{
    const x=.68+i*2.58;
    rect(s,x,2.68,2.36,.9,[C.lavender,C.mint,C.orange][i]);
    text(s,r[0],x+.16,2.78,2.04,.42,24,C.ink,true);
    text(s,r[1],x+.17,3.29,2.03,.2,10.2,C.ink);
  });
  photo(s,'circuit',8.38,2.72,4.27,3.35);
  const points=[
    ['In the prototype','Role exploration, profile matching, skill gaps, learning pathways and a full 17-goal map.'],
    ['Evidence boundary','One fixed, non-random BOSS snapshot, collected in October 2026; not a time series or whole-market estimate.'],
    ['Next evidence needed','Refresh data in repeated batches, test the experience with EEE students and review pathways with educators.'],
  ];
  points.forEach((r,i)=>{
    const y=3.78+i*.87;
    text(s,r[0],.7,y,7.32,.27,13.5,[C.mint,C.orange,C.lavender][i],true);
    text(s,r[1],.7,y+.34,7.18,.46,11.8,'D1D8E5',false,{valign:'top'});
  });
  note(s,'Data: team-provided BOSS snapshot (Oct 2026). UN definitions: sdgs.un.org/goals. Photo credits: Unsplash, Pexels (6209565, 163125) and Cal Poly Engineering.',true);
}

// 10 — Close on the testable next milestone.
{
  const s=base('09 / The next milestone');
  title(s,'First validate the pathway. Then make stronger claims.','A focused EEE student pilot is the next step from a connected prototype to credible evidence.');
  const stages=[
    ['NOW','Use the prototype','Guide EEE students from a role question to an editable learning plan.',C.lavender,C.purple],
    ['TEST','Check usefulness','Collect student feedback and educator review of role fit, sequencing and project evidence.',C.mint,C.teal],
    ['IMPROVE','Strengthen evidence','Refresh job data, revisit forecasting assumptions and report what has—and has not—changed.',C.orange,C.coral],
  ];
  stages.forEach((a,i)=>{
    const x=.65+i*4.13;
    rect(s,x,2.95,3.78,2.66,a[3]);
    text(s,a[0],x+.23,3.2,3.28,.28,10,a[4],true,{charSpacing:1.5});
    text(s,a[1],x+.23,3.76,3.27,.5,19,C.ink,true);
    text(s,a[2],x+.23,4.48,3.27,.91,13,C.ink,false,{valign:'top'});
  });
  photo(s,'solar',9.08,5.91,3.6,.61);
  text(s,'Clarity about where to go. A plan for what to learn. A reason to build.',.67,5.98,8.08,.49,17,C.navy,true);
  note(s,'NEXTEP  /  ENGINEER YOUR FUTURE  /  Built exclusively for Electrical & Electronic Engineering.');
}

fs.mkdirSync('outputs',{recursive:true});
p.writeFile({fileName:'outputs/NEXTEP_Roadshow_Pitch_EN.pptx'})
  .then(()=>console.log(`Created ${page} English NEXTEP roadshow slides.`))
  .catch(error=>{console.error(error);process.exitCode=1;});
