const port = Number(process.env.PORT || 5000);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error("PORT must be an integer between 1 and 65535.");
}
process.env.NODE_ENV = "production";
const { startProdServer } = await import("vinext/server/prod-server");
await startProdServer({ port, host: "0.0.0.0" });
