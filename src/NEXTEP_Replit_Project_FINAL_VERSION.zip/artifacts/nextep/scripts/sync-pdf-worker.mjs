import { copyFile, mkdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";

// PDF.js rejects a worker from a different release. Serve the worker from the
// installed, security-updated package rather than maintaining a stale copy.
const root = new URL("../", import.meta.url);
await mkdir(new URL("public/", root), { recursive: true });
await copyFile(
  fileURLToPath(new URL("node_modules/pdfjs-dist/build/pdf.worker.min.mjs", root)),
  fileURLToPath(new URL("public/pdf.worker.min.mjs", root)),
);
console.log("PDF.js worker synchronized with the installed pdfjs-dist release.");
