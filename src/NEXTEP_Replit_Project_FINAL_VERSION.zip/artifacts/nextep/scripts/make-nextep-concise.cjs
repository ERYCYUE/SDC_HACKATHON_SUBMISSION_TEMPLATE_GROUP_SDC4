// Shorter, self-contained English reading edition. Preserve the earlier
// navy/cream palette, editable text and photography without repeating caveats.
const P = require('pptxgenjs');
const fs = require('fs');
const path = require('path');
const p = new P();
p.layout = 'LAYOUT_WIDE';
p.author = 'NEXTEP';
p.title = 'NEXTEP — EEE Student Futures';
p.subject = 'Concise English reading edition';
p.lang = 'en-GB';
p.theme = { headFontFace: 'DejaVu Sans', bodyFontFace: 'DejaVu Sans', lang: 'en-GB' };
const C = { navy:'101C35', paper:'F7F6F2', ink:'18243A', muted:'626C7A', purple:'7464EE', lav:'E8E3FF', mint:'B7E4D0', orange:'FFB18B', white:'FFFFFF' };
const sdg = JSON.parse(fs.readFileSync('data/sdg-impact.json'));
let page = 0;
function box(s,x,y,w,h,color) { s.addShape('rect',{x,y,w,h,fill:{color},line:{color,width:0}}); }
function text(s,value,x,y,w,h,size=18,color=C.ink,bold=false,extra={}) {
  s.addText(value,{x,y,w,h,fontFace:'DejaVu Sans',fontSize:size,color,bold,margin:0,valign:'top',breakLine:false,...extra});
}
function photo(s,name,x,y,w,h) {
  s.addImage({path:path.join('outputs/nextep-assets',`${name}.jpg`),x,y,w,h,sizing:{type:'cover',w,h}});
}
function base(section,title,sub='',dark=false) {
  const s=p.addSlide();page++;s.background={color:dark?C.navy:C.paper};
  const ink=dark?C.white:C.ink;
  box(s,.63,.35,.19,.19,dark?C.mint:C.purple);
  text(s,'NEXTEP',.98,.28,2,.35,13,ink,true,{charSpacing:1.5});
  text(s,section.toUpperCase(),7,.31,5.66,.3,9,dark?'BCC6D5':C.muted,false,{align:'right'});
  text(s,title,.65,1.02,12,.93,30,ink,true);
  if(sub)text(s,sub,.67,2.02,11.9,.52,16,dark?'BCC6D5':C.muted);
  s.addShape('line',{x:.65,y:7.02,w:12.02,h:0,line:{color:dark?'34415A':'D9DDE0',width:.7}});
  text(s,'engineer your future',.65,7.13,8,.22,9,dark?'BCC6D5':C.muted);
  text(s,String(page).padStart(2,'0'),12.1,7.1,.56,.26,10,dark?'BCC6D5':C.muted,false,{align:'right'});
  return s;
}
function cards(s,items,{y=2.85,h=3.55,size=18}={}) {
  const gap=.28,w=(12.02-gap*(items.length-1))/items.length;
  items.forEach((item,i)=>{
    const x=.65+i*(w+gap);
    box(s,x,y,w,h,item.color||[C.lav,C.mint,C.orange][i%3]);
    text(s,item.title,x+.25,y+.24,w-.5,.9,21,C.ink,true);
    text(s,item.body,x+.25,y+1.4,w-.5,h-1.62,size);
  });
}
// 01 — one paragraph and a clear audience, not a second executive summary.
{
  const s=base('EEE student futures','Engineer your future.','Career choices, new skills and a reason to build them.',true);
  photo(s,'students',8.12,2.88,4.55,3.66);
  text(s,'For Electrical & Electronic\nEngineering students.',.68,3.02,7.03,1.16,28,C.mint,true);
  text(s,'NEXTEP helps EEE students explore how AI may change their work, choose a direction and plan what to learn next.',.7,4.55,6.65,1.18,20,C.white);
  text(s,'Every pathway can also be explored through the UN’s 17 Sustainable Development Goals.',.7,6.04,6.7,.55,14,'BCC6D5');
}
// 02
{
  const s=base('The student problem','“What should I work towards?”','EEE students need more than a list of job titles.');
  cards(s,[
    {title:'Which direction?',body:'AI is changing engineering tasks. It is hard to tell which changes matter for a future career.'},
    {title:'What should I learn?',body:'A broad degree leaves many options. Students need a realistic next step, not another long resource list.'},
    {title:'Why does it matter?',body:'Students also want to understand how their engineering work could help people and the environment.'}
  ],{size:17});
}
// 03
{
  const s=base('Our focus','Built for EEE. Not every degree.','Our main difference is depth in one discipline.');
  photo(s,'circuit',.65,2.87,4.45,3.72);
  text(s,'EEE roles, EEE skills, EEE projects.',5.5,2.98,6.75,.86,25,C.ink,true);
  text(s,'Students can compare directions such as embedded systems, chip verification, communications and power engineering.',5.52,4.03,6.8,1.12,19);
  box(s,5.49,5.47,7.18,1.13,C.lav);
  text(s,'The learning plan follows the technical foundations these roles actually need.',5.74,5.74,6.63,.68,18);
}
// 04
{
  const s=base('Track and explore','Understand what AI is changing.','Research signals help students ask better questions about EEE work.');
  cards(s,[
    {title:'1. Track technology',body:'Follow AI research and developments relevant to engineering.'},
    {title:'2. Look at the tasks',body:'Explore which tasks could be automated, supported by AI or newly required.'},
    {title:'3. Compare scenarios',body:'See how different assumptions change the outlook for roles and skills.'}
  ],{h:3.1,size:18});
  text(s,'These are career scenarios—not reliable predictions of future vacancies or an individual’s employment.',.69,6.29,11.9,.35,13,C.muted);
}
// 05
{
  const s=base('Match and choose','Choose a direction that fits you.','A promising industry is not automatically the right personal choice.');
  cards(s,[
    {title:'Start with the student',body:'Confirm existing skills, interests and goals. An interest is not treated as a proven skill.',color:C.lav},
    {title:'Compare the options',body:'View personal fit and role outlook separately. Inspect the missing skills, then choose a target.',color:C.mint}
  ],{size:20});
}
// 06
{
  const s=base('Personalised learning','Turn the missing skills into a plan.','The plan should be possible alongside the student’s existing studies.');
  const rows=[
    ['01','Build the foundations','Learn prerequisites before the skills that depend on them.'],
    ['02','Learn for the target role','Focus on gaps that matter for the chosen EEE direction.'],
    ['03','Make something','Use a practical project to apply and demonstrate the learning.'],
    ['04','Fit it into the week','Set available study time, track progress and export the schedule.']
  ];
  rows.forEach((r,i)=>{
    const y=2.83+i*.88;
    box(s,.65,y,.62,.62,[C.purple,'137C72',C.purple,'137C72'][i]);
    text(s,r[0],.73,y+.15,.46,.29,15,C.white,true);
    text(s,r[1],1.52,y+.03,4.2,.53,18,C.ink,true);
    text(s,r[2],5.87,y+.04,6.56,.59,17);
  });
}
// 07 — keep one concrete student example instead of three overlapping pages.
{
  const s=base('A student example','Exploring embedded AI.','Illustrative example—not a recorded student outcome.');
  photo(s,'study',.65,2.87,4.1,3.71);
  const parts=[
    ['Starting point','Circuit fundamentals, basic Python and an interest in efficient devices.'],
    ['What to learn','Embedded C/C++, sensor interfaces and on-device model deployment.'],
    ['What to build','A smart sensor prototype, tested for latency, power use and failure cases.']
  ];
  parts.forEach((r,i)=>{
    const y=2.92+i*1.23;
    text(s,r[0],5.15,y,7.1,.36,16,C.purple,true);
    text(s,r[1],5.15,y+.45,7.13,.69,18);
  });
}
// 08
{
  const s=base('Sustainable development','EEE is the focus. All 17 SDGs are included.','Career preparation can connect to a wider purpose.');
  photo(s,'solar',8.22,2.87,4.45,3.72);
  text(s,'Role → skills → project → relevant SDGs',.68,3.02,7.05,.9,24,C.ink,true);
  text(s,'A student can follow the links to see how a technical project might contribute—and what would need to be measured.',.7,4.23,6.95,1.21,20);
  text(s,'Different roles connect to different goals. We do not claim that every role serves all 17.',.7,5.88,6.94,.68,16,C.muted);
}
// 09–10 — keep the full framework, but use readable rows, not dense tiles.
const examples=[
  'Off-grid lighting and charging','Soil sensing and irrigation','Health and fall-alert sensors',
  'Affordable electronics learning kits','Inclusive engineering workshops','Water-quality monitoring',
  'Energy monitoring and control','Predictive maintenance projects','Open chip verification',
  'Accessible navigation devices','Community air-quality sensing','Repairable electronics',
  'Flood-warning systems','Coastal monitoring buoys','Forest acoustic monitoring',
  'Emergency communication systems','Shared engineering tools and data'
];
for(let group=0;group<2;group++){
  const s=base('The 17 UN Sustainable Development Goals',group?'Goals 10–17: example EEE connections.':'Goals 1–9: example EEE connections.');
  text(s,'UN GOAL',1.45,2.23,4.66,.3,11,C.muted,true);
  text(s,'POSSIBLE EEE PROJECT',6.45,2.23,6.1,.3,11,C.muted,true);
  for(let i=0;i<(group?8:9);i++){
    const n=group*9+i,g=sdg.goals[n],y=2.69+i*.426;
    box(s,.65,y,.51,.34,g.color.replace('#',''));
    text(s,String(g.id),.69,y+.038,.43,.26,12,C.white,true,{align:'center'});
    text(s,g.name.en,1.45,y+.018,4.7,.36,13.7,C.ink,true);
    text(s,examples[n],6.45,y+.018,6.05,.36,14,C.ink);
  }
  text(s,'Examples show possible contributions, not measured impact or UN endorsement.',.68,6.66,11.9,.22,10.5,C.muted);
}
// 11
{
  const s=base('Make the SDG link concrete','What would count as a useful contribution?','A goal label is a starting point. The project still needs evidence.');
  const rows=[
    ['Solar lighting','SDGs 1 + 7','Build a safe, affordable light. Test runtime, cost and usefulness for the intended users.'],
    ['Smart irrigation','SDGs 2 + 6','Use sensing and control to reduce unnecessary watering. Compare water use with a baseline.'],
    ['Repairable electronics','SDG 12','Design for repair and reuse. Record what was repaired, reused and safely handled.']
  ];
  rows.forEach((r,i)=>{
    const y=2.85+i*1.17;
    box(s,.65,y,12.02,1.01,[C.lav,C.mint,'F4E0D4'][i]);
    text(s,r[0],.87,y+.18,3.0,.65,19,C.ink,true);
    text(s,r[1],4.0,y+.2,1.65,.54,16,C.purple,true);
    text(s,r[2],5.9,y+.17,6.5,.72,16);
  });
}
// 12
{
  const s=base('Current evidence','A starting point: 1,998 recruitment records.','Team-provided BOSS recruitment sample · Beijing, Shanghai and Shenzhen');
  const stats=[['1,998','job records'],['25','EEE-related directions'],['3','cities']];
  stats.forEach((r,i)=>{
    const x=.65+i*4.1;
    box(s,x,2.87,3.82,1.57,[C.lav,C.mint,C.orange][i]);
    text(s,r[0],x+.22,3.03,3.37,.65,36,C.ink,true);
    text(s,r[1],x+.23,3.91,3.35,.3,14);
  });
  text(s,'Students can compare advertised salaries, education requirements and experience across the sample.',.7,4.92,11.88,.85,22);
  text(s,'This is one non-random snapshot collected in October 2026. It does not show job growth over time or represent the whole market.',.7,6.02,11.85,.64,15,C.muted);
}
// 13
{
  const s=base('Where the project stands','What students can do today.','The prototype brings the main steps into one EEE-focused workspace.');
  cards(s,[
    {title:'Explore',body:'Compare EEE roles, technology scenarios and the available recruitment evidence.'},
    {title:'Plan',body:'Confirm a profile, inspect skill gaps and create an exportable learning pathway.'},
    {title:'Connect',body:'Relate a role or project to relevant SDGs and consider the trade-offs.'}
  ],{size:18});
  text(s,'Next: test the pathways with EEE students and educators, and collect repeated recruitment batches.',.69,6.65,11.95,.26,11.5,C.muted);
}
// 14 — concise reference and limitation note, instead of repeated disclaimers.
{
  const s=base('Sources and notes','What this version is based on.');
  const notes=[
    ['Project','Current NEXTEP prototype, EEE role catalog, learning modules and SDG mappings.'],
    ['Recruitment','Team-provided BOSS search sample: 25 directions, three cities, 1,998 records.'],
    ['UN goals','Official goal definitions: sdgs.un.org/goals. Project-to-goal links are authored by the team.'],
    ['Interpretation','Career scenarios and student examples support exploration; they are not hiring guarantees or validated outcomes.'],
    ['Photography','Existing deck assets: Unsplash; Pexels (6209565, 163125); Cal Poly engineering lab.']
  ];
  notes.forEach((r,i)=>{
    const y=2.54+i*.7;
    text(s,r[0],.68,y,2.24,.38,15,C.purple,true);
    text(s,r[1],3.03,y,9.32,.55,15);
  });
  box(s,.65,6.29,12.02,.48,C.navy);
  text(s,'Our aim: help EEE students decide what to work towards, what to learn and why it matters.',.89,6.41,11.53,.26,12,C.white);
}
fs.mkdirSync('outputs',{recursive:true});
p.writeFile({fileName:'outputs/NEXTEP_Concise_Reading_EN.pptx'})
  .then(()=>console.log(`Created ${page} concise English slides.`));
