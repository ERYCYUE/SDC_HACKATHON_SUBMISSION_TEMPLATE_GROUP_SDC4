// Supplemental slides: native editable shapes, matching the existing visual deck.
const P=require('pptxgenjs'),fs=require('fs');
const p=new P();p.layout='LAYOUT_WIDE';p.author='NEXTEP';
p.title='NEXTEP — EEE and all 17 UN SDGs';
p.theme={headFontFace:'DejaVu Sans',bodyFontFace:'DejaVu Sans',lang:'en-GB'};
const C={navy:'101C35',paper:'F7F6F2',ink:'18243A',muted:'626C7A',purple:'7464EE',mint:'B7E4D0',orange:'FFB18B'};
const goals=JSON.parse(fs.readFileSync('data/sdg-impact.json')).goals;
const examples=[
  'Off-grid solar access','Smart irrigation','Wearable health sensing',
  'Affordable electronics labs','Inclusive embedded workshops','Water-quality monitoring',
  'Energy monitoring & scheduling','Safer machine maintenance','Open RISC-V verification',
  'Accessible navigation aids','Community air-quality sensing','Repairable electronics',
  'Flood-warning systems','Coastal monitoring buoys','Forest acoustic monitoring',
  'Emergency communications','Open engineering & shared data'
];
function box(s,x,y,w,h,c){s.addShape('rect',{x,y,w,h,fill:{color:c},line:{color:c,width:0}});}
function t(s,v,x,y,w,h,size=12,color=C.ink,bold=false,extra={}){
  s.addText(v,{x,y,w,h,fontFace:'DejaVu Sans',fontSize:size,color,bold,margin:0,valign:'mid',...extra});
}
function base(section,num){
 const s=p.addSlide();s.background={color:C.paper};
 box(s,.6,.35,.2,.2,C.purple);t(s,'NEXTEP',.94,.28,2,.34,13,C.ink,true,{charSpacing:1.9});
 t(s,section,7,.3,5.7,.28,9,C.muted,false,{align:'right',charSpacing:1.2});
 s.addShape('line',{x:.58,y:7.04,w:12.16,h:0,line:{color:'D9DDE0',width:.7}});
 t(s,'engineer your future',.58,7.13,5,.17,8,C.muted);
 t(s,num,12.18,7.1,.56,.22,9,C.muted,false,{align:'right'});
 return s;
}
for(let group=0;group<2;group++){
 const s=base('07 / EEE × ALL 17 UN SDGs',group?'09':'08');
 t(s,group?'All 17 goals. Different EEE connections.':'EEE is our discipline. All 17 SDGs are our framework.',.65,1,12,1.05,29,C.ink,true);
 t(s,group?'Goals 10–17: inclusion, resilience, ecosystems and collaboration.':'Goals 1–9: access, wellbeing, learning and engineering infrastructure.',.65,2.12,12,.37,13,C.muted);
 for(let i=0;i<9;i++){
  const n=group*9+i,x=.65+(i%3)*4.15,y=2.79+Math.floor(i/3)*1.19;
  if(n>=17){
   box(s,x,y,3.78,1.02,C.navy);
   t(s,'One discipline. Shared global goals.',x+.18,y+.14,3.42,.3,12,'FFFFFF',true);
   t(s,'Connections vary by role and project.',x+.18,y+.58,3.42,.25,10,C.mint);
   continue;
  }
  const g=goals[n],color=g.color.replace('#','');
  box(s,x,y,3.78,1.02,'FFFFFF');box(s,x,y,.74,1.02,color);
  t(s,String(g.id),x+.04,y+.22,.66,.51,27,'FFFFFF',true,{align:'center'});
  t(s,g.name.en,x+.94,y+.09,2.66,.43,11.2,C.ink,true);
  t(s,examples[n],x+.94,y+.64,2.66,.29,9,C.muted);
 }
 t(s,'Illustrative links from the NEXTEP project catalog — not certified impact or a claim that each EEE role serves all 17 goals.',.65,6.62,12,.24,8.5,C.muted);
 s.addNotes('All 17 names and goal colours come from the project SDG catalog. Examples are team-authored project ideas, not outcomes or official UN endorsements. UN framework: https://sdgs.un.org/goals');
}
{
 const s=base('07 / HOW THE SDG CONNECTION WORKS','11');
 t(s,'From an EEE career goal to a specific SDG target.',.65,1,12,1.05,29,C.ink,true);
 t(s,'The SDG connection is part of the learning pathway — not an extra label added at the end.',.65,2.12,12,.4,13,C.muted);
 const cards=[
  ['ROLE','Power electronics','Explore an EEE career direction.','E8E3FF'],
  ['SKILLS','Circuits + power + MCU','Identify the capabilities to build.','B7E4D0'],
  ['PROJECT','Off-grid solar lighting','Build a low-voltage prototype.','FFB18B'],
  ['SDG TARGETS','1.4 + 7.b','Access to services and energy.','E8E3FF']
 ];
 cards.forEach((a,i)=>{
  const x=.65+i*3.13;box(s,x,3.01,2.78,2.3,a[3]);
  t(s,a[0],x+.19,3.23,2.4,.27,10,C.purple,true);
  t(s,a[1],x+.19,3.82,2.4,.63,18,C.ink,true);
  t(s,a[2],x+.19,4.64,2.4,.43,10,C.ink);
  if(i<3)t(s,'→',x+2.83,3.94,.27,.4,16,C.muted,true);
 });
 box(s,.65,5.64,12.17,.67,C.navy);
 t(s,'Evidence to collect: efficiency, runtime, cost and protection tests — then assess benefits with intended users.',.9,5.8,11.64,.33,11,'FFFFFF');
 t(s,'Illustrative pathway. Team-authored mapping to targets 1.4 and 7.b; target descriptions are paraphrased. No measured social impact is claimed.',.65,6.62,12,.24,8.3,C.muted);
 s.addNotes('Source: data/sdg-impact.json, solar-access project. Only low-voltage bench work; no mains wiring. Goal 1 target 1.4 and Goal 7 target 7.b are potential connections, not verified development outcomes.');
}
p.writeFile({fileName:'outputs/NEXTEP_SDG_Supplement_EN.pptx'}).then(()=>console.log('Created 3 SDG supplement slides.'));
