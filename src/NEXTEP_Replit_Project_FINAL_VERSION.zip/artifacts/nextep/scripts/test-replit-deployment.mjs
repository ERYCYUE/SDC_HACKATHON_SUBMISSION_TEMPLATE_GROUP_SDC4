import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import net from "node:net";
import { spawn } from "node:child_process";
import { once } from "node:events";

// Exercise the actual built Node server, not the Vite/Worker preview.
const listener = net.createServer();
listener.listen(0, "127.0.0.1");
await once(listener, "listening");
const port = listener.address().port;
await new Promise(resolve => listener.close(resolve));
const child = spawn(process.execPath, ["scripts/start-replit.mjs"], {
  cwd: process.cwd(),
  env: { ...process.env, PORT: String(port), ALLOW_EXTERNAL_AI: "false" },
  stdio: ["ignore", "pipe", "pipe"],
});
let logs = "";
child.stdout.on("data", value => { logs += value; });
child.stderr.on("data", value => { logs += value; });
const base = `http://127.0.0.1:${port}`;
let checks = 0;
function pass(label) { checks++; console.log(`PASS ${label}`); }
try {
  let home;
  const deadline = Date.now() + 30000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`Production server exited: ${logs}`);
    try {
      home = await fetch(base, { signal: AbortSignal.timeout(2500) });
      break;
    } catch {
      await new Promise(resolve => setTimeout(resolve, 150));
    }
  }
  assert(home, `Production server failed to start: ${logs}`);
  assert.equal(home.status, 200);
  const html = await home.text();
  assert.match(html, /NEXTEP/);
  assert(!html.includes("/@vite/client"));
  pass("built Node server serves NEXTEP without the development client");

  const response = await fetch(`${base}/api/market`);
  assert.equal(response.status, 200);
  assert.equal(response.headers.get("x-data-source"), "release-snapshot");
  const bundle = await response.json();
  const seed = JSON.parse(await readFile("data/cn-employment.json", "utf8"));
  assert.deepEqual(bundle, seed);
  assert.equal(bundle.postings.length, 1998);
  assert.equal(response.headers.get("x-data-batch"), seed.meta.id);
  pass("production endpoint serves the exact 1998-record release without D1");

  const internationalResponse = await fetch(`${base}/api/international`);
  assert.equal(internationalResponse.status, 200);
  assert.equal(internationalResponse.headers.get("x-data-source"), "release-snapshot");
  const international = await internationalResponse.json();
  assert.equal(international.snapshots.length, 10);
  for (const id of ["my-lfs", "us-unemployment", "de-vacancies"]) {
    assert(international.snapshots.some(snapshot => snapshot.id === id && snapshot.rows.length > 0), `Missing international source ${id}`);
  }
  assert.equal(international.refreshMode, "packaged-release-snapshot");
  pass("production endpoint serves the checked Malaysia, US, Germany and Singapore snapshots");

  const denied = await fetch(`${base}/api/market`, { method: "POST" });
  assert.equal(denied.status, 405);
  pass("recruitment endpoint rejects writes");

  const status = await fetch(`${base}/api/ai`);
  assert.equal(status.status, 200);
  assert.deepEqual(await status.json(), { configured: false, model: null, reason: "disabled" });
  pass("optional external AI remains explicitly disabled without opt-in");

  const worker = await fetch(`${base}/pdf.worker.min.mjs`);
  assert.equal(worker.status, 200);
  const sha = bytes => createHash("sha256").update(bytes).digest("hex");
  assert.equal(sha(Buffer.from(await worker.arrayBuffer())), sha(await readFile("node_modules/pdfjs-dist/build/pdf.worker.min.mjs")));
  pass("production serves the matching PDF.js worker");

  const assets = [...new Set([...html.matchAll(/(?:src|href)="([^"]+\.(?:css|js)(?:\?[^"]*)?)"/g)].map(match => match[1]))];
  assert(assets.length > 0, "No built CSS/JS assets found");
  for (const asset of assets.slice(0, 4)) {
    const result = await fetch(new URL(asset, base));
    assert.equal(result.status, 200, asset);
    assert(!result.headers.get("content-type")?.includes("text/html"), asset);
  }
  pass("built page styles and JavaScript assets are accessible");
  assert.equal((await fetch(`${base}/not-a-nextep-route`)).status, 404);
  pass("unknown routes return 404");
  console.log(`${checks} Replit production checks passed.`);
} finally {
  if (child.exitCode === null && child.signalCode === null) {
    const closed = once(child, "close");
    child.kill("SIGTERM");
    await closed;
  }
}
