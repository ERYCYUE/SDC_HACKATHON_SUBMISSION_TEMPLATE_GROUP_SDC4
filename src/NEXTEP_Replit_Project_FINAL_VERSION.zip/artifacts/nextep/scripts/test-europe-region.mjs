import assert from 'node:assert/strict';
import {regionOptions,marketRegion,matchesRegion,mentionedRegion} from '../lib/regions.ts';
import {makeDefaultData,initialPerson} from '../lib/model/catalog.ts';
import {defaultContext} from '../lib/model/config.ts';
import {defaultPreferences,buildPathway} from '../lib/model/pathways.ts';
import {importDataset} from '../lib/model/schema.ts';
import {entryStatistics,educationTrend} from '../lib/model/entry-gaps.ts';
import {rankObservedPostings} from '../lib/model/posting-match.ts';
import {roleRequirements} from '../lib/model/scoring.ts';
import {roleForecast} from '../lib/model/forecast.ts';
import {extractPerson} from '../lib/model/profile.ts';
import {publicFeeds} from '../lib/international.ts';
import {buildAIPayload} from '../lib/ai-grounding.ts';

// Controlled test fixture only; never loaded by the website or its database.
const base=makeDefaultData();
const job=(country,id,degree,date)=>({
  job_id:id,title:'IC Verification Engineer · QA fixture',role_id:'ic-verification',
  region:country,skills:['verilog','verification'],source_url:`https://qa.test/jobs/${id}`,
  published_at:'2026-10-18',snapshot_date:date,synthetic:false,source_platform:'other',
  education_min:degree,experience_min_years:0,
});
const d=importDataset({
  ...base,
  jobs:[
    job('DE','de-a','bachelor','2026-10-20'),
    job('FR','fr-a','master','2026-10-23'),
    job('CN','cn-a','bachelor','2026-10-23'),
  ],
  signals:[],
});
const p={...initialPerson,skills:['verilog','verification'],education:'bachelor',workYears:0,goal:'ic-verification',region:'EU'};
const c={...defaultContext,region:'EU'};
let n=0;
const check=(name,fn)=>{fn();n++;console.log('PASS',name);};

check('one Europe entry among exactly five selectable markets',()=>assert.deepEqual(Object.keys(regionOptions),['CN','SG','MY','US','EU']));
check('legacy country selection maps to Europe rather than China',()=>{
  assert.equal(marketRegion('DE'),'EU');assert.equal(marketRegion('FR'),'EU');
  assert.equal(marketRegion('UK'),'EU');assert.equal(marketRegion('XX'),undefined);
});
check('European countries group together and exclude China and the US',()=>{
  assert(matchesRegion('DE','EU'));assert(matchesRegion('NL','EU'));
  assert(!matchesRegion('CN','EU'));assert(!matchesRegion('US','EU'));
});
check('country mentions resolve to Europe without English false positives',()=>{
  assert.equal(mentionedRegion('I have no work experience and want to learn.'),undefined);
  assert.equal(mentionedRegion('I am at university. Please help me.'),undefined);
  assert.equal(mentionedRegion('希望去法国或德国做芯片验证'),'EU');
  assert.equal(extractPerson('I want to work in Germany',initialPerson,base).region,'EU');
  assert.equal(mentionedRegion('Country: NL'),'EU');
});
check('imports retain country provenance and reject unknown codes',()=>{
  assert.equal(d.jobs[0].region,'DE');assert.equal(d.jobs[1].region,'FR');
  assert.throws(()=>importDataset({...base,jobs:[job('XX','bad','bachelor','2026-10-20')],signals:[]}));
});
check('Europe pools each country’s latest batch independently',()=>{
  const s=entryStatistics(d,'ic-verification','EU','bachelor',0,'all');
  assert.equal(s.jobs.length,2);assert.equal(s.n,2);assert.equal(s.current,50);
  assert.deepEqual(s.countrySnapshots,[{country:'DE',date:'2026-10-20',count:1},{country:'FR',date:'2026-10-23',count:1}]);
});
check('the same vacancy URL across countries is counted once',()=>{
  const duplicate={...d.jobs[0],job_id:'duplicate',region:'FR',snapshot_date:'2026-10-23',source_url:d.jobs[0].source_url+'?utm_source=copy'};
  const s=entryStatistics({...d,jobs:[...d.jobs,duplicate]},'ic-verification','EU','bachelor',0,'all');
  assert.equal(s.jobs.length,2);assert.equal(s.duplicates,1);
});
check('changing country coverage does not create a comparable Europe trend',()=>{
  const rows=educationTrend(d,'ic-verification','EU','all');
  assert.equal(rows[0].masterShare,null);assert.equal(rows[1].masterShare,100);
});
check('European posting recommendations do not fall back to China',()=>{
  const ranked=rankObservedPostings(p,c,d);
  assert.equal(ranked.length,2);assert.equal(ranked[0].job.region,'DE');
  assert(ranked.every(x=>x.job.region!=='CN'));
  assert.equal(rankObservedPostings(p,c,{...d,jobs:d.jobs.filter(j=>j.region==='CN')}).length,0);
});
check('role skill requirements pool grouped European postings',()=>{
  const x=roleRequirements(d.roles.find(r=>r.id==='ic-verification'),c,d);
  assert.equal(x.jobs.length,2);
});
check('Germany official data stays visibly country-specific within Europe',()=>{
  const feeds=publicFeeds.filter(f=>matchesRegion(f.region,'EU'));
  assert.equal(feeds.length,1);assert.equal(feeds[0].id,'de-vacancies');
  assert.equal(feeds[0].region,'DE');assert.match(feeds[0].scope[1],/Germany/);
});
check('a German demand index is not silently treated as Europe-wide',()=>{
  const role=d.roles.find(r=>r.id==='ic-verification');
  assert.equal(roleForecast(role,c,{...d,signals:[{...base.signals[0],role_id:role.id,region:'DE',demand_index:100}]}).base,50);
});
check('Europe pathways can use resources tagged to a European country',()=>{
  const x={...d,resources:d.resources.map(r=>({...r,regions:['DE']}))};
  const path=buildPathway('ic-verification',p,c,x,defaultPreferences);
  assert(path.modules.some(m=>m.resources.length>0));
});
check('AI summary follows Europe and pools observed entry requirements',()=>{
  const a=buildAIPayload('analysis','Explain',p,c,d,defaultPreferences,'ic-verification',null,'en');
  assert.equal(a.profile.region,'Europe');assert.equal(a.entry_gap.total,2);
  assert.equal(a.entry_gap.source,'all');assert.equal(a.employment,undefined);
  assert.equal(a.bestPosting.id,'de-a');assert.equal(a.bestPosting.city,'Germany');
});

console.log(`${n} Europe grouping checks passed.`);
