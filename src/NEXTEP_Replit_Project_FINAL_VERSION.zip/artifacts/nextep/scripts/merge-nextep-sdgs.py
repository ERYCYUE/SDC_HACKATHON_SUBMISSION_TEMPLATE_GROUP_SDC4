"""Insert 3 editable SDG slides, preserve existing visual deck and strengthen framing."""
from zipfile import ZipFile
from pathlib import Path
import re
import html
import xml.etree.ElementTree as ET

SOURCE=Path('outputs/NEXTEP_EEE_Focused_EN.pptx')
EXTRA=Path('outputs/NEXTEP_SDG_Supplement_EN.pptx')
OUT=Path('outputs/NEXTEP_EEE_UN17_SDG_EN.pptx')
NS={'p':'http://schemas.openxmlformats.org/presentationml/2006/main',
    'a':'http://schemas.openxmlformats.org/drawingml/2006/main'}

def edit_texts(blob,edits):
    xml=blob.decode()
    for old,new in edits.items():
        old_tag='<a:t>'+html.escape(old,quote=False)+'</a:t>'
        assert old_tag in xml,old
        xml=xml.replace(old_tag,'<a:t>'+html.escape(new,quote=False)+'</a:t>')
    return xml.encode()

EDITS={
 1:{'AI readiness × purposeful EEE careers':'EEE careers × all 17 UN SDGs',
    'Exclusively for Electrical & Electronic':'EEE-only career guidance, connected to',
    'Engineering (EEE) students.':'all 17 UN Sustainable Development Goals.'},
 3:{'EEE-specific roles, skills and learning pathways — not a platform for every major.':
    'EEE-only roles and learning pathways, connected to all 17 UN SDGs — not a platform for every major.',
    'projects with clear SDG links.':'projects linked to the 17 SDGs.'},
 8:{'EEE skills. Real-world purpose.':'17 goals. Here are three EEE examples.',
    'NEXTEP links EEE roles, skills and projects to the UN’s 17 Sustainable Development Goals.':
    'These examples illustrate three goals within the full 17-goal framework — they are not the whole scope.'},
 10:{'EEE is our only discipline: from AI change and role matching to reskilling and SDG links.':
     'EEE is our only discipline; all 17 UN SDGs frame its connections to sustainable development.'},
 11:{'EEE students. EEE futures.':'EEE futures. All 17 UN SDGs.',
     'Connect EEE to impact.':'Connect EEE to the 17 SDGs.'}
}

# Keep part filenames intact; change presentation order instead of renaming old parts.
order=list(range(1,8))+[13,14,8,15]+list(range(9,13))
page_for={part:page for page,part in enumerate(order,1)}

def update_footer(data,page):
    xml=data.decode()
    def shape(m):
        text=re.findall(r'<a:t>(.*?)</a:t>',m[0],re.S)
        if len(text)==1 and re.fullmatch(r'\d{2}',text[0]):
            # Footer is positioned near the bottom right, unlike card indices.
            tree=ET.fromstring(m[0].replace('<p:sp>','<p:sp xmlns:p="'+NS['p']+'" xmlns:a="'+NS['a']+'">',1))
            off=tree.find('.//a:xfrm/a:off',NS)
            if off is not None and int(off.attrib['y'])>6400000:
                return m[0].replace('<a:t>'+text[0]+'</a:t>',f'<a:t>{page:02}</a:t>')
        return m[0]
    return re.sub(r'<p:sp>.*?</p:sp>',shape,xml,flags=re.S).encode()

with ZipFile(SOURCE) as src,ZipFile(EXTRA) as add,ZipFile(OUT,'w') as dst:
    presentation=src.read('ppt/presentation.xml').decode()
    section=re.search(r'<p:sldIdLst>(.*?)</p:sldIdLst>',presentation,re.S)
    ids=re.findall(r'<p:sldId\b[^>]*/>',section[1])
    assert len(ids)==12
    maxid=max(int(re.search(r'\bid="(\d+)"',x)[1]) for x in ids)
    for i in range(3):
        ids.append(f'<p:sldId id="{maxid+i+1}" r:id="rIdSdgExtra{i+1}"/>')
    ordered=''.join(ids[i-1] for i in order)
    presentation=presentation[:section.start(1)]+ordered+presentation[section.end(1):]
    rels=src.read('ppt/_rels/presentation.xml.rels').decode()
    newrels=''.join(f'<Relationship Id="rIdSdgExtra{i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide{13+i}.xml"/>' for i in range(3))
    rels=rels.replace('</Relationships>',newrels+'</Relationships>')
    types=src.read('[Content_Types].xml').decode()
    overrides=''.join(f'<Override PartName="/ppt/slides/slide{13+i}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>' for i in range(3))
    types=types.replace('</Types>',overrides+'</Types>')
    for info in src.infolist():
        name=info.filename;data=src.read(name)
        if name=='ppt/presentation.xml':data=presentation.encode()
        elif name=='ppt/_rels/presentation.xml.rels':data=rels.encode()
        elif name=='[Content_Types].xml':data=types.encode()
        elif name=='docProps/app.xml':
            data=re.sub(rb'<Slides>\d+</Slides>',b'<Slides>15</Slides>',data)
        else:
            match=re.fullmatch(r'ppt/slides/slide(\d+)\.xml',name)
            if match:
                part=int(match[1])
                if part in EDITS:data=edit_texts(data,EDITS[part])
                data=update_footer(data,page_for[part])
        dst.writestr(info,data)
    for i in range(3):
        content=add.read(f'ppt/slides/slide{i+1}.xml')
        dst.writestr(f'ppt/slides/slide{i+13}.xml',content)
        # New slides have native shapes only; reuse the existing blank layout.
        dst.writestr(f'ppt/slides/_rels/slide{i+13}.xml.rels',
           '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
           '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>'
           '</Relationships>')
print(f'Created {OUT}: 15 slides, including 17-goal overview and role–skill–project–SDG pathway.')
