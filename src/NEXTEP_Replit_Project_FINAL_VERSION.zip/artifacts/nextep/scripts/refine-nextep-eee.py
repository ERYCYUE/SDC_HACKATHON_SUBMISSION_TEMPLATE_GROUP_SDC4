"""Refine the user's uploaded PPTX at the XML text level.

Preserve visuals; repair one existing cover-photo overlap by cropping right.
"""
from pathlib import Path
from zipfile import ZipFile
import re
import html
import xml.etree.ElementTree as ET

SOURCE = Path("attached_assets/NEXTEP_Student_Futures_Visual_EN_1792764463874.pptx")
OUTPUT = Path("outputs/NEXTEP_EEE_Focused_EN.pptx")
# Tuples explicitly retain the existing text runs and line breaks.
EDITS = {
    1: {
        ("STUDENT FUTURES / PROJECT OVERVIEW",): ("EEE STUDENT FUTURES / PROJECT OVERVIEW",),
        ("FOR STUDENTS. FOR WHAT’S NEXT.",): ("EEE STUDENTS. EEE CAREERS.",),
        ("AI readiness × purposeful careers",): ("AI readiness × purposeful EEE careers",),
        ("A CAREER COMPASS FOR STUDENTS",): ("A CAREER COMPASS FOR EEE STUDENTS",),
        ("NEXTEP connects AI change, personal learning", "and sustainable engineering careers."):
            ("Exclusively for Electrical & Electronic", "Engineering (EEE) students."),
    },
    2: {
        ("The future of work is changing.", "Students need a direction, not more anxiety."):
            ("AI is changing EEE work.", "Students need a direction, not more anxiety."),
        ("AI can reshape tasks within a role — not just replace whole job titles.",):
            ("AI is reshaping EEE tasks, from circuit design to embedded-system testing.",),
        ("Students must choose modules, projects and new tools before the future is certain.",):
            ("EEE students must choose modules, projects and new tools as their field changes.",),
        ("Career decisions should connect personal strengths with real-world problems.",):
            ("Connect EEE strengths to real problems in energy, electronics and infrastructure.",),
    },
    3: {
        ("02 / THE NEXTEP APPROACH",): ("02 / OUR DIFFERENCE: EEE ONLY",),
        ("One connected journey.", "Three questions students can act on."):
            ("Our difference: EEE only.", "Depth in one discipline, not every major."),
        ("From understanding change to choosing a direction and building evidence of ability.",):
            ("EEE-specific roles, skills and learning pathways — not a platform for every major.",),
        ("UNDERSTAND",): ("EEE INSIGHT",),
        ("What is changing?",): ("See EEE change",),
        ("Track AI progress and explore", "emerging or shifting roles."):
            ("Track how AI reshapes tasks", "and roles within EEE."),
        ("CHOOSE",): ("EEE MATCHING",),
        ("Where could I go?",): ("Find your EEE fit",),
        ("Match interests and current skills", "to possible future roles."):
            ("Compare EEE interests and skills", "with relevant engineering roles."),
        ("BUILD",): ("EEE PATHWAYS",),
        ("What do I learn next?",): ("Learn the next skill",),
        ("Follow a personalised reskilling", "pathway linked to SDG impact."):
            ("Close EEE skill gaps through", "projects with clear SDG links."),
    },
    4: {
        ("Turn AI developments into", "better learning decisions."):
            ("Track AI change in EEE.", "Decide what to learn next."),
        ("Explore embedded AI,", "validation and efficiency"):
            ("Learn embedded AI,", "validation and power efficiency"),
    },
    5: {
        ("Do not chase one “AI-proof” job.", "Build a direction you can keep adapting."):
            ("Do not chase one “AI-proof” job.", "Build an adaptable EEE foundation."),
        ("Circuit fundamentals • coding", "measurement • systems thinking"):
            ("Circuits • signals • control", "measurement • systems thinking"),
        ("AI-assisted workflows • testing", "critical evaluation • continuous learning"):
            ("AI-assisted EEE design • testing", "critical evaluation • lifelong learning"),
        ("Energy access • resilient infrastructure", "responsible resource use"):
            ("Clean energy • reliable electronics", "responsible resource use"),
    },
    6: {
        ("From “I like electronics”", "to a role worth exploring."):
            ("From EEE strengths", "to a specialised career direction."),
        ("Combines software + hardware + real-world sensing.", "Compare fit, skill gaps and outlook before committing."):
            ("An EEE direction combining hardware, code and sensing.", "Compare fit, EEE skill gaps and outlook before committing."),
    },
    7: {
        ("A pathway, not a pile of course links.",): ("An EEE pathway, not generic course links.",),
        ("Example destination: build and evaluate an energy-aware edge-AI sensor.",):
            ("Example EEE destination: build and evaluate an energy-aware edge-AI sensor.",),
        ("Strengthen the basics",): ("Build EEE foundations",),
    },
    8: {
        ("Your next skill can serve a bigger goal.",): ("EEE skills. Real-world purpose.",),
        ("NEXTEP connects career and learning choices to the UN’s 17 Sustainable Development Goals.",):
            ("NEXTEP links EEE roles, skills and projects to the UN’s 17 Sustainable Development Goals.",),
    },
    9: {
        ("Make the future tangible.", "Build something you can explain."):
            ("Make EEE learning tangible.", "Build something you can explain."),
    },
    10: {
        ("A repeatable loop for an uncertain future.",): ("An EEE career journey you can revisit.",),
        ("NEXTEP supports a next decision — not a one-time prediction of an entire career.",):
            ("EEE is our only discipline: from AI change and role matching to reskilling and SDG links.",),
        ("See what AI is changing.",): ("See AI changes in EEE.",),
        ("Inspect roles and fit.",): ("Compare EEE roles and fit.",),
        ("Choose one learning goal.",): ("Choose an EEE skill goal.",),
    },
    11: {
        ("Not a promise of a perfect future.", "A better way to prepare for it."):
            ("One discipline. Deeper guidance.", "EEE students. EEE futures."),
        ("Know what to aim for.",): ("Choose an EEE direction.",),
        ("Know what to learn next.",): ("Build relevant EEE skills.",),
        ("Know why it matters.",): ("Connect EEE to impact.",),
    },
}

def replace_slide(blob, replacements):
    """Change only escaped text content, preserving every surrounding XML byte."""
    xml = blob.decode("utf-8")
    found = set()

    def shape(match):
        original = match.group(0)
        runs = re.findall(r"<a:t(?:\s[^>]*)?>(.*?)</a:t>", original, flags=re.S)
        key = tuple(html.unescape(t) for t in runs)
        if key not in replacements:
            return original
        replacement = replacements[key]
        assert len(replacement) == len(runs), key
        found.add(key)
        it = iter(replacement)
        return re.sub(
            r"(<a:t(?:\s[^>]*)?>)(.*?)(</a:t>)",
            lambda m: m[1] + html.escape(next(it), quote=False) + m[3],
            original,
            flags=re.S,
        )

    result = re.sub(r"<p:sp(?:\s[^>]*)?>.*?</p:sp>", shape, xml, flags=re.S)
    missing = set(replacements) - found
    if missing:
        raise ValueError(f"Expected text not found: {missing}")
    ET.fromstring(result)
    return result.encode("utf-8"), len(found)

OUTPUT.parent.mkdir(parents=True, exist_ok=True)
changed = 0
with ZipFile(SOURCE) as src, ZipFile(OUTPUT, "w") as dst:
    for item in src.infolist():
        content = src.read(item.filename)
        match = re.fullmatch(r"ppt/slides/slide(\d+)\.xml", item.filename)
        if match and int(match[1]) in EDITS:
            content, count = replace_slide(content, EDITS[int(match[1])])
            changed += count
        if item.filename == "ppt/slides/slide1.xml":
            cover = content.decode("utf-8")
            old_image = re.search(r"<p:pic>.*?</p:pic>", cover, re.S).group(0)
            new_image = old_image.replace(
                '<a:srcRect/>', '<a:srcRect l="19700" r="19700"/>'
            ).replace(
                '<a:off x="3200400" y="813816"/>',
                '<a:off x="6519672" y="813816"/>'
            ).replace(
                '<a:ext cx="8439912" cy="5431536"/>',
                '<a:ext cx="5120640" cy="5431536"/>'
            )
            assert old_image != new_image
            content = cover.replace(old_image, new_image, 1).encode("utf-8")
        dst.writestr(item, content)
print(f"Updated {changed} text shapes and repaired cover-photo overlap: {OUTPUT}")
