import assert from 'node:assert/strict';
import {spreadOverlappingPoints} from '../lib/model/chart-layout.ts';

const bounds={left:55,right:715,top:20,bottom:300};
const dense=Array.from({length:21},(_,i)=>({id:String(i),x:170+(i%3)*.2,y:230+(i%4)*.2,radius:i===0?12:9}));
const layout=spreadOverlappingPoints(dense,bounds);
assert.equal(layout.length,dense.length);
for(const point of layout){
  assert(point.x>=bounds.left+point.radius&&point.x<=bounds.right-point.radius);
  assert(point.y>=bounds.top+point.radius&&point.y<=bounds.bottom-point.radius);
  const original=dense.find(x=>x.id===point.id);
  assert.equal(point.rawX,original.x);assert.equal(point.rawY,original.y);
}
for(let i=0;i<layout.length;i++)for(let j=i+1;j<layout.length;j++){
  assert(Math.hypot(layout[i].x-layout[j].x,layout[i].y-layout[j].y)>=layout[i].radius+layout[j].radius+4.99);
}
assert.deepEqual(layout,spreadOverlappingPoints(dense,bounds));
console.log('PASS 21 clustered chart markers stay distinct, within bounds, tethered to original scores and deterministic.');
