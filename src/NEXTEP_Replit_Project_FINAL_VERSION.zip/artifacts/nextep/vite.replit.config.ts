import { defineConfig } from "vite";
import vinext from "vinext";

// Replit runs a Node HTTP server, not a Cloudflare Worker. Keep the original
// Worker/D1 development build in vite.config.ts unchanged.
export default defineConfig({
  plugins: [vinext()],
  server: {
    host: "0.0.0.0",
    port: Number(process.env.PORT),
    strictPort: true,
    allowedHosts: true,
  },
});
