import {handleMarketSnapshot} from '@/lib/market-snapshot';
export const dynamic='force-dynamic';
// Worker deployments intercept this endpoint in worker/index.ts and still use
// D1. Replit's Node server serves the identical read-only release batch.
export const GET=(request:Request)=>handleMarketSnapshot(request);
