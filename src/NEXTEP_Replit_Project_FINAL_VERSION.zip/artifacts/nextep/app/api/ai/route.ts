import {handleAI,type AIEnv} from '@/lib/ai-server';
export const dynamic='force-dynamic';
function nodeAIEnv():AIEnv{return{AI_ENDPOINT:process.env.AI_ENDPOINT,AI_MODEL:process.env.AI_MODEL,AI_API_KEY:process.env.AI_API_KEY,ALLOW_EXTERNAL_AI:process.env.ALLOW_EXTERNAL_AI};}
// The Worker entry supplies its own bindings; only the Node host uses these
// explicitly allowlisted server-side environment variables.
export const GET=(request:Request)=>handleAI(request,nodeAIEnv());
export const POST=(request:Request)=>handleAI(request,nodeAIEnv());
