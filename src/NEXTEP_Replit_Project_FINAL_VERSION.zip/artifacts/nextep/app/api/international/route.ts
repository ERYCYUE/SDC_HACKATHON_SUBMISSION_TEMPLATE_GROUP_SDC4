import snapshots from "@/data/international-employment.json";
import type { FeedSnapshot } from "@/lib/international";

export const dynamic = "force-dynamic";

export function GET() {
  return Response.json(
    {
      snapshots: snapshots as FeedSnapshot[],
      refreshMode: "packaged-release-snapshot",
      staleAfterHours: 48,
    },
    {
      headers: {
        "Cache-Control": "public, max-age=120",
        "X-Data-Source": "release-snapshot",
      },
    },
  );
}
