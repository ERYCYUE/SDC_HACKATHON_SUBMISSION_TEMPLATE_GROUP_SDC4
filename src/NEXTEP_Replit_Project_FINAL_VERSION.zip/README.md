# NEXTEP — Replit 项目源码

此压缩包包含当前 NEXTEP 网站、配套 API 服务、共享工作区包，以及 Replit 运行配置。没有包含 `node_modules`、构建缓存、`.env` 文件或任何密钥。

## 导入 Replit

将 ZIP 导入或解压到 Replit 项目根目录，保持根目录中的 `package.json`、`pnpm-workspace.yaml`、`.replit` 和 `artifacts/` 目录结构。项目使用 Node.js 24 与 pnpm；安装依赖：

```bash
pnpm install --frozen-lockfile
```

根目录的 Replit 配置及两个 `.replit-artifact/artifact.toml` 文件保留了网页和 API 的原有运行命令。正常情况下，Replit 会根据这些配置启动两个服务。

## 手动运行

如需在 Shell 中分别启动服务，请使用两个终端：

```bash
PORT=8080 pnpm --filter @workspace/api-server run dev
```

```bash
PORT=18579 BASE_PATH=/ pnpm --filter @workspace/nextep run dev
```

网页运行命令仍为 `pnpm --filter @workspace/nextep run dev`；API 运行命令仍为 `pnpm --filter @workspace/api-server run dev`。Replit 服务配置会注入对应的端口变量。

## 构建

```bash
pnpm --filter @workspace/api-server run build
pnpm --filter @workspace/nextep run build:replit
```

## Next.js 运行说明

项目使用 Next.js App Router 源码与 Next 依赖，同时通过 Vinext、Vite 和 Cloudflare 插件适配当前 Replit 运行环境。因此，请使用上面的 pnpm/Replit 命令，不要改成 `next dev`，否则会绕过现有 Replit 端口和运行时适配。

## 可选 AI 功能

AI 助手可在未配置 API 密钥时使用本地规则分析。若要启用 DeepSeek API，请在 Replit Secrets 中添加 `AI_API_KEY`；不要把密钥写进源码或提交到 Git。压缩包不包含任何凭据。
