# NEXTEP

Bilingual electronic and information engineering career explorer. Preserve the
existing product's visual design, data provenance, local storage, and behavior.

## Run

Use the managed workflows:

- `artifacts/nextep: web` — existing NEXTEP website, at `/`.
- `artifacts/api-server: API Server` — shared backend, at `/api`.
- The pre-existing mockup sandbox remains separate.

The website retains its Vinext/React pages and Node production server. It is not
a static SPA: its artifact must use `start:replit`, not static file serving.
The managed workflow supplies `PORT`; do not run the root `pnpm dev`.

## Code and data

- `artifacts/nextep/app`, `components`, `lib`: unchanged website source and styles.
- `artifacts/api-server/src/nextep`: original AI and release-snapshot handlers.
- `artifacts/api-server/src/routes/nextep.ts`: Express/Web Request adapter.
- Browser fetch URLs remain `/api/market`, `/api/international` and `/api/ai`.
- The original custom fetch layer is retained rather than replacing it with
  generated hooks during the migration.
- The Node backend serves the exact validated, read-only recruitment release in
  `data/cn-employment.json` (1,998 postings). It reports `release-snapshot`.
- International official data is a validated, GET-only release snapshot with
  original capture timestamps, source hashes and optional request URLs; it does
  not refresh official sources live. Source definitions remain in the website.
- API builds synchronize an explicit allowlist from the website using
  `artifacts/api-server/sync-nextep.mjs`. Update the canonical website AI
  contract/handler rather than editing generated backend copies. Node release
  adapters and backend-specific market filters are intentionally not overwritten.
- Original Cloudflare D1 schema is preserved in the website's `db/` directory.
  Do not convert it to PostgreSQL or push it through the scaffold DB package.
  Replit's Node runtime does not depend on local D1 state.

Core exploration works without external services. External AI stays disabled
unless explicitly configured and opted into. Preserve the server-only allowlist
`AI_ENDPOINT`, `AI_MODEL`, `AI_API_KEY`, `ALLOW_EXTERNAL_AI`; never expose secrets
to browser code. See `artifacts/nextep/docs/DEEPSEEK_SETUP.md`.

## Existing checks

`pnpm --filter @workspace/api-server run test:nextep --proxy` checks source
parity, malformed releases, current webpage-built AI payloads with a mocked
provider, and shared-proxy GET/write rejection. Live AI POST checks deliberately
use a foreign origin to guarantee no paid provider call, regardless of server
configuration. Run the API workflow first; no real secrets are used by the test.
For a full successful AI round-trip through the proxy without paid calls, stop
the API workflow, run the same test with `--mock-proxy-port=<API service port>`,
then restart the managed workflow. This temporary server uses the real router
with injected mock configuration/provider; the app has no public test bypass.
The test-only TypeScript import hook uses Node's `registerHooks` API (Node 22.15+
or Node 24). Production commands are unchanged.

Run from `artifacts/nextep` with `node --experimental-strip-types scripts/<name>`:
`test-career.mjs`, `test-v2.mjs`, `test-tracking.mjs`,
`test-entry-gaps.mjs`, `test-ai.mjs`, `test-cn-market.mjs`,
`test-entry-design.mjs`. The last test writes a controlled fixture to its parent
directory; remove that generated fixture after running it.

## Scope

The requested presentation must be a separate app, not a page or feature inside
the NEXTEP website. Do not change the existing website's identity or appearance
to accommodate it.
