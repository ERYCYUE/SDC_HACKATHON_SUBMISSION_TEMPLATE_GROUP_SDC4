import {sqliteTable,text,integer,primaryKey,index} from 'drizzle-orm/sqlite-core';
export const employmentBatches=sqliteTable('employment_batches',{id:text('id').primaryKey(),meta:text('meta').notNull(),rowCount:integer('row_count').notNull()});
export const employmentPostings=sqliteTable('employment_postings',{id:text('id').notNull(),batchId:text('batch_id').notNull(),roleId:text('role_id').notNull(),payload:text('payload').notNull()},t=>[primaryKey({columns:[t.id,t.batchId]}),index('employment_batch_idx').on(t.batchId),index('employment_role_idx').on(t.roleId)]);
