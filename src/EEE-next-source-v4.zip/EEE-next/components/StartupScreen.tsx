'use client';

import {useEffect,useRef,useState} from 'react';
import {ArrowRight,ArrowUpRight,Cpu,Globe2,MoveUpRight} from 'lucide-react';
import SDGOrbit from './SDGOrbit';
import {branches,regions,type Lang} from '@/lib/career';
import './boot-space.css';

type Props={lang:Lang;onLanguageChange:()=>void;onTransitionStart?:()=>void;onComplete:(destination?:string)=>void};
type Star={x:number;y:number;size:number;speed:number;phase:number};

function Constellation(){
 const canvas=useRef<HTMLCanvasElement>(null);
 useEffect(()=>{
  const el=canvas.current;if(!el)return;const ctx=el.getContext('2d');if(!ctx)return;
  const media=matchMedia('(prefers-reduced-motion: reduce)');let stars:Star[]=[];let width=0,height=0,frame=0,last=0,disposed=false;
  function draw(time:number){
   if(!ctx)return;ctx.clearRect(0,0,width,height);
   for(let i=0;i<stars.length;i++){
    const a=stars[i];if(!media.matches){a.y-=a.speed;if(a.y < -10)a.y=height+10;}
    const opacity=media.matches ? .38 : .22+(Math.sin(time/2500+a.phase)+1)*.17;
    ctx.fillStyle=`rgba(174,157,255,${opacity})`;ctx.beginPath();ctx.arc(a.x,a.y,a.size,0,Math.PI*2);ctx.fill();
    for(let j=i+1;j<stars.length;j++){const b=stars[j],distance=Math.hypot(a.x-b.x,a.y-b.y);if(distance<105){ctx.strokeStyle=`rgba(111,125,236,${(1-distance/105)*.13})`;ctx.lineWidth=.6;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();}}
   }
  }
  function resize(){
   if(!el||!ctx)return;width=el.clientWidth;height=el.clientHeight;const scale=Math.min(devicePixelRatio||1,1.5);el.width=Math.round(width*scale);el.height=Math.round(height*scale);ctx.setTransform(scale,0,0,scale,0,0);
   stars=Array.from({length:Math.min(56,Math.max(20,Math.floor(width*height/23000)))},()=>({x:Math.random()*width,y:Math.random()*height,size:.6+Math.random()*.8,speed:.08+Math.random()*.14,phase:Math.random()*8}));draw(0);
  }
  function tick(time:number){if(disposed||media.matches||document.hidden)return;if(time-last>32){draw(time);last=time;}frame=requestAnimationFrame(tick);}
  function restart(){cancelAnimationFrame(frame);last=0;if(!media.matches&&!document.hidden)frame=requestAnimationFrame(tick);else draw(0);}
  const observer=new ResizeObserver(resize);observer.observe(el);resize();restart();document.addEventListener('visibilitychange',restart);media.addEventListener('change',restart);
  return()=>{disposed=true;cancelAnimationFrame(frame);observer.disconnect();document.removeEventListener('visibilitychange',restart);media.removeEventListener('change',restart);};
 },[]);
 return <canvas ref={canvas} className="boot-constellation" aria-hidden="true"/>;
}

export default function StartupScreen({lang,onLanguageChange,onTransitionStart,onComplete}:Props){
 const root=useRef<HTMLElement>(null),enter=useRef<HTMLButtonElement>(null),timeout=useRef<ReturnType<typeof setTimeout>|null>(null);
 const [leaving,setLeaving]=useState(false);const t=(zh:string,en:string)=>lang==='zh'?zh:en;
 const finish=(destination='overview')=>{if(leaving)return;setLeaving(true);onTransitionStart?.();const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;timeout.current=setTimeout(()=>onComplete(destination),reduced?0:850);};
 useEffect(()=>{const original=document.body.style.overflow;document.body.style.overflow='hidden';enter.current?.focus({preventScroll:true});return()=>{document.body.style.overflow=original;if(timeout.current)clearTimeout(timeout.current);};},[]);
 return <section ref={root} className={'boot-screen'+(leaving?' boot-leaving':'')} role="dialog" aria-modal="true" aria-labelledby="boot-title" aria-describedby="boot-description" onPointerMove={e=>{if(e.pointerType!=='mouse'||matchMedia('(prefers-reduced-motion: reduce)').matches)return;const bounds=e.currentTarget.getBoundingClientRect();e.currentTarget.style.setProperty('--pointer-x',`${(e.clientX-bounds.width/2)/bounds.width*13}px`);e.currentTarget.style.setProperty('--pointer-y',`${(e.clientY-bounds.height/2)/bounds.height*13}px`);}} onPointerLeave={e=>{e.currentTarget.style.setProperty('--pointer-x','0px');e.currentTarget.style.setProperty('--pointer-y','0px');}} onKeyDown={e=>{
  if(e.key==='Escape'){e.preventDefault();finish();}
  if(e.key==='Tab'){const buttons=root.current?.querySelectorAll<HTMLButtonElement>('button:not(:disabled)');if(!buttons?.length)return;const first=buttons[0],last=buttons[buttons.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}
 }}>
  <Constellation/><div className="boot-grid" aria-hidden="true"/><div className="boot-noise" aria-hidden="true"/><div className="boot-light boot-light-one" aria-hidden="true"/><div className="boot-light boot-light-two" aria-hidden="true"/>
  <div className="boot-layout"><header className="boot-header"><div className="boot-brand"><span className="boot-brand-icon"><Cpu size={22}/></span><span>EEE<span>next</span></span><i/></div><div className="boot-header-actions"><button onClick={onLanguageChange} disabled={leaving} aria-label={t('切换语言','Switch language')}><Globe2 size={14}/>{lang==='zh'?'English':'中文'}</button><span/><button className="boot-skip" onClick={()=>finish()} disabled={leaving}>{t('跳过开场','Skip intro')}<ArrowUpRight size={14}/></button></div></header>
   <div className="boot-main"><div className="boot-copy"><div className="boot-kicker"><i/>AIVERSECITY / FUTURE-READY WORKFORCE</div><div className="boot-title-mask"><h1 id="boot-title">{lang==='zh'?<>让你的下一程，<br/><span>连接更好的世界。</span></>:<>Your next chapter.<br/><span>A better shared future.</span></>}</h1></div><p id="boot-description">{t('以电子信息工程为起点，发现你的职业可能，让每一次成长连接联合国 17 项可持续发展目标。','Explore your next role in electronic and information engineering. Connect your strengths and learning with the 17 UN Sustainable Development Goals.')}</p><div className="boot-cta-row"><button ref={enter} className="boot-enter" onClick={()=>finish()} disabled={leaving}>{t('开启探索','Explore my next')}<span><ArrowRight size={18}/></span></button><span className="boot-cta-note">{t('让未来，由你定义。','A future shaped by you.')}</span></div><div className="boot-goal-links"><button onClick={()=>finish('chat')} disabled={leaving}><span>01</span>{t('认识我的能力','MY STRENGTHS')}<ArrowUpRight size={12}/></button><button onClick={()=>finish('roles')} disabled={leaving}><span>02</span>{t('职业与学习路径','CAREER PATHWAYS')}<ArrowUpRight size={12}/></button><button onClick={()=>finish('overview')} disabled={leaving}><span>03</span>{t('17 项可持续目标','17 SUSTAINABLE GOALS')}<ArrowUpRight size={12}/></button></div><div className="boot-topics"><span>{t('芯片与系统','CHIPS & SYSTEMS')}</span><i/><span>{t('智能与感知','INTELLIGENCE & SENSING')}</span><i/><span>{t('连接与创新','CONNECTION & INNOVATION')}</span></div></div><div className="boot-art"><SDGOrbit/></div></div>
   <div className="boot-bottom"><div className="boot-bottom-line"><span>DESIGNED FOR WHAT COMES NEXT</span><i/><MoveUpRight size={17}/></div><div className="boot-bottom-meta"><div className="boot-sdg-count"><span>17</span>{t('可持续发展目标','SUSTAINABLE GOALS')}</div><div><span>{String(Object.keys(branches).length).padStart(2,'0')}</span>{t('专业方向','ENGINEERING SPECIALIZATIONS')}</div><div><span>{String(Object.keys(regions).length).padStart(2,'0')}</span>{t('目标地区','TARGET REGIONS')}</div><div className="boot-human"><i/>{t('以人为中心，面向未来','HUMAN-CENTERED. FUTURE-READY.')}</div><small>EEE NEXT · 2026</small></div></div>
  </div><div className="boot-exit-flash" aria-hidden="true"/>
 </section>;
}
